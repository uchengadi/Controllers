<?php

class StateController extends Controller
{
	
        private $_id;
        /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'. 'listallstates'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update', 'ListAllStatesInCountry', 'ListCountryForStateScheduling','ListAllStatesInNigeria'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('listallstates','deleteonestate'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new State;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		$model->name = $_POST['name'];
                $model->country_id = $_POST['country_id'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                 if(isset($_POST['state_code'])){
                   $model->state_code = $_POST['state_code']; 
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created new state/region';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'New state/region creation was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate()
	{
            //get the country id
            $country= $_POST['country_id'];
         
            $_id = $_POST['id'];
            
            $model=State::model()->findByPk($_id);
            $model->name = $_POST['name'];
            if(is_numeric($country)){
                $model->country_id = $country;
                
            }else{
                $criteria = new CDbCriteria();
                $criteria->select = 'id';
                $criteria->condition='name=:id';
                $criteria->params = array(':id'=>$country);
                $country_name = Country::model()->find($criteria); 
                $model->country_id = $country_name->id;
                
                
            }
           
           if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                 if(isset($_POST['state_code'])){
                   $model->state_code = $_POST['state_code']; 
                }
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
            if($model->save()){
                       // $data['success'] = 'true';
                        $msg = 'State information successfully updated';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                   // $data['success'] = 'false';
                    $msg = 'State information update was unsuccessful';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                }
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneState()
	{
            
            $_id = $_POST['id'];
            $model=State::model()->findByPk($_id);
            
            //get the state name
            $state_name = $this->getTheStateName($_id);
            
            //get the state country name
            $state_country = $this->getTheStateCountryName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$state_name' state/province in '$state_country' was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        /**
         * This is the function that gets a state name
         */
        public function getTheStateName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $state = State::model()->find($criteria); 
            
            return $state['name'];
        }

        
        /**
         * This is the function that gets a state country name
         */
        public function getTheStateCountryName($state_id){
            //get the country id of this state
            $country_id = $this->getCountryIdOfState($state_id);
            
            //get the country name 
            $country_name = $this->getTheCountryNameOfThisCountryId($country_id);
            
            return $country_name;
            
        }
        
        /**
         * This is the function that gets the country id given the state id
         */
        public function getCountryIdOfState($state_id){
          
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$state_id);
            $state = State::model()->find($criteria); 
            
            return $state['country_id'];
            
        }
        
        
        /**
         * This is the function that gets the country name given its id
         */
        public function getTheCountryNameOfThisCountryId($country_id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$country_id);
            $country = Country::model()->find($criteria); 
            
            return $country['name'];
            
        }
	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('State');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionListAllStates()
	{
		$state = State::model()->findAll();
                if($state===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "state" => $state,
                                   
                    
                            ));
                       
                }
	}
        
        
        /**
	 * List all the states that belong to a particular country
	 */
	public function actionListAllStatesInCountry()
	{
		
                $_id = $_REQUEST['id'];
                //$_id = 1;
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='country_id=:id';
                $criteria->params = array(':id'=>$_id);
                $state= State::model()->findAll($criteria);
                if($state===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "state" => $state,
                                   
                    
                            ));
                       
                       
                }
	}
        
        
        
         /**
	 * get a country name  given a country id
	 */
	public function actionListCountryForStateScheduling()
	{
		
             $country_id = $_REQUEST['country_id'];
             //$_id = 1;
            
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$country_id);
             $country = Country::model()->findAll($criteria);   
             
             
               
                if($country===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "country" => $country)
                       );
                       
                } 
               
               
	}

	 /**
	 * List all the states that belong to a Nigeria
	 */
	public function actionListAllStatesInNigeria()
	{
		$model = new Country;
                $id = $model->getTheCountryIdGivenItsCode("NGR");
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='country_id=:id';
                $criteria->params = array(':id'=>$id);
                $state= State::model()->findAll($criteria);
                if($state===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "state" => $state,
                                   
                    
                            ));
                       
                       
                }
        }
}
