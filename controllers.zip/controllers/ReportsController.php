<?php

class ReportsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddNewReport','DeleteOneReport','ListAllReports','UpdateReport',
                                    'SpecificReportsByType','getDomainAndTodayDateReportParameters','getDomainAndTodayDateReportParameters',
                                    'getODR0001ReportContent','getODR0002ReportContent','getODR0003ReportContent','getODR0004ReportContent',
                                    'getODR0005ReportContent','getODR0006ReportContent','getODR0007ReportContent','getODR0008ReportContent',
                                    'getODR0009ReportContent','getODR0010ReportContent','getODR0011ReportContent','getODR0012ReportContent',
                                    'getODR0013ReportContent','getODR0014ReportContent','getODR0015ReportContent','getODR0016ReportContent',
                                    'getODR0017ReportContent','getODR0018ReportContent','getODR0019ReportContent','getODR0020ReportContent',
                                    'getODR0021ReportContent','getODR0022ReportContent','getODR0023ReportContent','getODR0024ReportContent',
                                    'getODR0025ReportContent','getODR0026ReportContent','getODR0027ReportContent','getODR0028ReportContent',
                                    'getODR0029ReportContent','getODR0030ReportContent','getODR0031ReportContent','getDDR0001ReportContent',
                                    'getDDR0002ReportContent','getDDR0003ReportContent','getDDR0004ReportContent','getDDR0005ReportContent',
                                    'getDDR0006ReportContent','getDDR0007ReportContent','getDDR0008ReportContent','getDDR0009ReportContent',
                                    'getDDR0010ReportContent','getDDR0011ReportContent','getDDR0012ReportContent','isThisKeywordInAProgramConsumedByThisDomain'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function to create/add new report
         */
        public function actionAddNewReport(){
            $model = new Reports;
            
            $model->name = $_POST['name'];
            
            $model->description = $_POST['description'];
            
            $model->type = strtolower($_POST['type']);
            $model->code = $_POST['code'];
            
            //get the last id number
          /**  
            $id_number = $this->getTheLastReportIdNumber();
            if($model->type == 'own_domain_report'){
                if((int)$id_number < 10){
                   $model->code = 'ODR'.'000'. ($id_number + 1);
                }else if((int)$id_number >9 and ((int)$id_number) <100){
                    $model->code = 'ODR'.'00'. ($id_number + 1);
                }else if((int)$id_number >99 and ((int)$id_number) < 1000){
                    $model->code = 'ODR'.'0'. ($id_number + 1);
                }else if((int)$id_number >1000){
                    $model->code = 'ODR'. ($id_number + 1);
                }
                 
            }else if($model->type == 'other_domain_report'){
                if((int)$id_number < 10){
                   $model->code = 'DDR'.'000'. ($id_number + 1);
                }else if((int)$id_number >9 and (int)$id_number <100){
                    $model->code = 'DDR'.'00'. ($id_number + 1);
                }else if((int)$id_number >99 and (int)$id_number < 1000){
                    $model->code = 'DDR'.'0'. ($id_number + 1);
                }else if((int)$id_number >1000){
                    $model->code = 'DDR'. ($id_number + 1);
                }
            }else if($model->type == 'sales_performance_report'){
                if((int)$id_number < 10){
                   $model->code = 'SPR'.'000'. ($id_number+1);
                }else if((int)$id_number >9 and (int)$id_number <100){
                    $model->code = 'SPR'.'00'. ($id_number + 1);
                }else if((int)$id_number >99 and (int)$id_number < 1000){
                    $model->code = 'SPR'.'0'. ($id_number + 1);
                }else if((int)$id_number >1000){
                    $model->code = 'SPR'. ($id_number + 1);
                }
            }
           * 
           */
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
            //confirm if this code already exist
            
            if($this->isCodeNotAlreadyExisting($model->code)){
                if($model->save()){
               $msg = "Successful creation of '$model->name' report";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' report could not be created";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           }
            }else {
                $msg = "'$model->name' report could not be created as the provided code is already in use in another report";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
            }
            
            
        }
        
        
       
        /**
         * This is the function that updates report information
         */
        public function actionUpdateReport(){
            
            $_id = $_POST['id'];
            $model=Reports::model()->findByPk($_id);
             
            $model->name = $_POST['name'];
            
            $model->description = $_POST['description'];
            
            $model->type = strtolower($_POST['type']);
            
            $model->code = $_POST['code'];
            //get the last id number
            
       /**     $id_number = $this->getTheLastReportIdNumber();
            //get the current report code
            $current_code = $this->getTheCurrentCodeOfThisReport($_id);
            
            //get the current report type
            $current_type = $this->getTheCurrentReportType($_id);
        if($current_type == $model->type){
                $model->code = $current_code;
                $model->update_time = new CDbExpression('NOW()');;
                $model->update_user_id = Yii::app()->user->id;
            
            if($model->save()){
               $msg = "Successful update of '$model->name' report";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' report could not be updated";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           }
         }else{
              if($model->type == 'own_domain_report'){
                if((int)$id_number < 10){
                   $model->code = 'ODR'.'000'. ($id_number);
                }else if((int)$id_number >9 and ((int)$id_number) <100){
                    $model->code = 'ODR'.'00'. ($id_number);
                }else if((int)$id_number >99 and ((int)$id_number) < 1000){
                    $model->code = 'ODR'.'0'. ($id_number);
                }else if((int)$id_number >1000){
                    $model->code = 'ODR'. ($id_number);
                }
                 
            }else if($model->type == 'other_domain_report'){
                if((int)$id_number < 10){
                   $model->code = 'DDR'.'000'. ($id_number);
                }else if((int)$id_number >9 and (int)$id_number <100){
                    $model->code = 'DDR'.'00'. ($id_number);
                }else if((int)$id_number >99 and (int)$id_number < 1000){
                    $model->code = 'DDR'.'0'. ($id_number);
                }else if((int)$id_number >1000){
                    $model->code = 'DDR'. ($id_number);
                }
            }else if($model->type == 'sales_performance_report'){
                if((int)$id_number < 10){
                   $model->code = 'SPR'.'000'. ($id_number);
                }else if((int)$id_number >9 and (int)$id_number <100){
                    $model->code = 'SPR'.'00'. ($id_number);
                }else if((int)$id_number >99 and (int)$id_number < 1000){
                    $model->code = 'SPR'.'0'. ($id_number);
                }else if((int)$id_number >1000){
                    $model->code = 'SPR'. ($id_number);
                }
            } 
        
            $model->update_time = new CDbExpression('NOW()');;
                $model->update_user_id = Yii::app()->user->id;
            
            if($model->save()){
               $msg = "Successful update of '$model->name' report";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' report could not be updated";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           }
                
            }// this one
      * 
      */
            $model->update_time = new CDbExpression('NOW()');
            $model->update_user_id = Yii::app()->user->id;
           if($this->isThisCodeUsableForThisReport($_id,$model->code)){
               if($model->save()){
               $msg = "Successful update of '$model->name' report";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() == 0,
                       "msg" => $msg
                       ));
           }else{
                $msg = "'$model->name' report could not be updated";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           }  
           }else{
              $msg = "'$model->name' report could not be updated as the provided code is already in use";
               header('Content-Type: application/json');
               echo CJSON::encode(array(
                      "success" => mysql_errno() != 0,
                       "msg" => $msg
                       ));
           }
           
               
              
           
            
            
        }
        
        
        
        /**
         * This is the function that delete one report from the platform
         */
        public function actionDeleteOneReport(){
            
            $_id = $_POST['id'];
            //get the name of this designation
            $report = $this->getThisReportName($_id);
            $model=Reports::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = "'$report' report was successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = "'$report' report was not deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
        }
        
        
        /**
         * This is the function that list all report on the platform
         */
        public function actionListAllReports(){
            
            $user_id = Yii::app()->user->id;
            
            //get this user domain
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $criteria = new CDbCriteria();
               $criteria->select = '*';
              // $criteria->condition='domain_id!=:domainid';
               //$criteria->params = array(':domainid'=>$domain_id);
               $reports = Reports::model()->findAll($criteria);
                 
            if($reports===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $reports
            
                       ));
                       
                }
     
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        /**
                 * This is the function that retrieves a report name
                 */
                public function getThisReportName($id){
                    
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$id);
                    $report = Reports::model()->find($criteria);   
            
                    return $report['name'];
                }
                
                
            /**
             * This is the function that confirms the last id number on the report platform
             */    
             public function getTheLastReportIdNumber(){
                 
                 if($this->isReportTablePopulated()){
                     
                     //get all report ids
                     $ids = $this->getAllReportIds();
                     $last_id = 0;
                     foreach($ids as $id){
                         if((int)$id > $last_id){
                             $last_id = $id;
                         }
                     }
                     return $last_id;
                 }else{
                     return 0;
                 }
             }  
             
             
             /**
              * This is the function that gets all ids in the report table
              */
             public function getAllReportIds(){
                 
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                   // $criteria->condition='id=:id';
                    //$criteria->params = array(':id'=>$id);
                    $reports = Reports::model()->findAll($criteria); 
                    
                    $all_ids = [];
                    foreach($reports as $report){
                        $all_ids[] = $report['id'];
                    }
                 
                    return $all_ids;
             }
             
             
             /**
              * This  is the function that confirms if the report table is populated
              */
             public function isReportTablePopulated(){
                 
               $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('reports');
                   
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
                 
             }
             
             
             /**
              * This is the function that gets a code given the report id
              */
             public function getTheCurrentCodeOfThisReport($id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$id);
                    $report = Reports::model()->find($criteria);   
            
                    return $report['code'];
                 
             }
             
             
             /**
              * This is the function that gets the type of a report
              */
             public function getTheCurrentReportType($id){
                 $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$id);
                    $report = Reports::model()->find($criteria);   
            
                    return $report['type'];
                 
             }
             
             
             
             /**
              * This is the function that list reports by type
              */
             public function actionSpecificReportsByType(){
                 
                
                //get the report type
                 $type = $_REQUEST['type'];
                 
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='type =:type';
               $criteria->params = array(':type'=>"$type");
               $reports = Reports::model()->findAll($criteria);
                 
                if($reports===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $reports
            
                       ));
                       
                } 
                 
             }
             
             
             /**
              * This is the function that determines if a code already exist
              */
             public function isCodeNotAlreadyExisting($code){
                 
             $cmd =Yii::app()->db->createCommand();
             $cmd->select('COUNT(*)')
                    ->from('reports')
                    ->where("code = '$code'");
             $result = $cmd->queryScalar();
                
             if($result <= 0){
                   return true;
             }else{
                   return false;
             }
             }
             
             
             /**
              * This is the function that determines if a code is usable during a report update
              */
             public function isThisCodeUsableForThisReport($id, $code){
                 
                 //get the current code  for this report
                 $report_code = $this->getTheCurrentCodeOfThisReport($id);
                 
                 if($this->isCodeNotAlreadyExisting($code)){
                     return true;
                     
                 }else{
                     if("$report_code" == "$code"){
                         return true;
                     }else{
                         return false;
                     }
                 }
                 
             }
             
             
             /**
              * This is th function that gets the domain name and todays date for a report
              */
             public function actiongetDomainAndTodayDateReportParameters(){
                 
                 //get the logged in user
                 $user_id = Yii::app()->user->id;
                 
                 //get the domain id of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
                 
                 //get the domain name
                 
                 $domain_name = $this->getThisDomainName($domain_id);
                 
                 $today = $this->getTodaysDate();
                 
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "domain" => $domain_name,
                           "today"=>$today
            
                       ));
                 
                 
                 
                 
             }
             
             
             /**
              * This is the function that gets a domain name
              */
             public function getThisDomainName($id){
                 
                 $criteria1 = new CDbCriteria();
                 $criteria1->select = '*';
                 $criteria1->condition='id=:id';
                 $criteria1->params = array(':id'=>$id);
                 $name= Resourcegroupcategory::model()->find($criteria1);
            
                return $name['name'];
             }
             
             
             /**
              * This is the function that gets today's date
              */
             public function getTodaysDate(){
                 
                 $today = date("d/m/Y",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
                 
                 return $today;
             }
             
             
             /**
              * This is the function that gets the odr0001 report content
              */
             public function actiongetODR0001ReportContent(){
                 
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "start_date"=>$start_date,
                           "end_date"=>$end_date,
                           "start"=>$_REQUEST['start_date'],
                           "end"=>$_REQUEST['end_date']
            
                       ));
                       
                } 
          
                 
             }
             
             
             /**
              * This is the function that gets the programs & events for a report given the time range
              */
             public function getAllThisDomainProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date){
                 
                 
                    $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id';
                      $criteria1->params = array(':id'=>$domain_id);
                      $items= Resourcegroup::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                 
             }
             
             
             
             /**
              * This is the function that determines if an item is within a date range
              */
             public function isMediaItemWithinTheDateRange($create_time,$start_date,$end_date){
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                $item_create_time = getdate($create_time);
                $date_start = getdate($start_date);
                $date_end = getdate($end_date);
                
                 if(($start_date === 0) && ($end_date === $today)){
                     return true;
                 }else if($start_date === 0 && $end_date !==$today){
                     if($this->isItemCreatedDateLowerThanTheSpecifiedEndDate($end_date,$create_time)){
                         return true;
                     }else if($this->isItemCreatedDateHigherThanTheSpecifiedEndDate($end_date,$create_time)){
                        return false;
                        
                     }else{
                         return true;
                     }
                 }else if($start_date != 0 && $end_date === $today){
                     if($this->isItemCreatedDateHigherThanTheSpecifiedStartDate($start_date,$create_time)){
                         if($this->isItemCreatedDateLowerThanTheSpecifiedEndDate($end_date,$create_time)){
                         return true;
                     }else if($this->isItemCreatedDateHigherThanTheSpecifiedEndDate($end_date,$create_time)){
                        return false;
                        
                     }else{
                         return true;
                     }
                         
                     }else{
                         return false;
                     }
                 }else if($start_date != 0 && $end_date !== $today){
                     if($this->isItemCreatedDateHigherThanTheSpecifiedStartDate($start_date,$create_time)){
                         if($this->isItemCreatedDateLowerThanTheSpecifiedEndDate($end_date,$create_time)){
                         return true;
                     }else if($this->isItemCreatedDateHigherThanTheSpecifiedEndDate($end_date,$create_time)){
                        return false;
                        
                     }else{
                         return true;
                     }
                         
                     }else{
                         return false;
                     }
                     
                 }
                 
                 
             }
             
             
             /**
              * This is the function that determines if an item is created before the end date
              */
             public function isItemCreatedDateLowerThanTheSpecifiedEndDate($end_date,$create_time){
                
                  $item_create_time = getdate($create_time);
                  $date_end = getdate($end_date);
                  
                  if(($item_create_time['year']  - $date_end['year'])>0){
                      return false;
                  }else if(($item_create_time['year']  - $date_end['year'])===0){
                      if(($item_create_time['mon']  - $date_end['mon'])>0){
                          return false;
                      }else if(($item_create_time['mon']  - $date_end['mon'])===0){
                          if(($item_create_time['mday']  - $date_end['mon'])>0){
                              return false;
                          }else{
                              return true;
                          }
                      }else{
                          return true;
                      }
                  }else{
                      return true;
                  }
                 
             }
             
            
             /**
              * This is the function that determines if items create time is at least equal to the specified end date
              */
             public function isItemCreatedDateEqualToTheSpecifiedEndDate($end_date,$create_time){
                 
                 $item_create_time = getdate($create_time);
                  $date_end = getdate($end_date);
                  
                  if(($item_create_time['year']  - $date_end['year'])>0){
                      return false;
                  }else if(($item_create_time['year']  - $date_end['year'])===0){
                      if(($item_create_time['mon']  - $date_end['mon'])>0){
                          return false;
                      }else if(($item_create_time['mon']  - $date_end['mon'])===0){
                          if(($item_create_time['mday']  - $date_end['mon'])>0){
                              return false;
                          }else{
                              return true;
                          }
                      }else{
                          return true;
                      }
                  }else{
                      return true;
                  }
                  
                 
             }
             
             
             /**
              * This is the function that determines if item's create time is higher than the specified end time
              */
             public function isItemCreatedDateHigherThanTheSpecifiedEndDate($end_date,$create_time){
                 
                 $item_create_time = getdate($create_time);
                  $date_end = getdate($end_date);
                  
                  if(($item_create_time['year'] - $date_end['year'])>0){
                      return true;
                  }else if(($item_create_time['year'] - $date_end['year']) ===0){
                      if(($item_create_time['mon'] - $date_end['mon']) > 0){
                          return true;
                      }else if(($item_create_time['mon'] - $date_end['mon']) === 0){
                          if(($item_create_time['mday'] - $date_end['mday']) > 0){
                              return true;
                          }else{
                              return false;
                          }
                      }else{
                          return false;
                      }
                  }else{
                      return false;
                  }
                     
                 
             }
             
             
                          
             
             /**
              * This is the function that determines if the item created date is higher than the specified start date
              */
             public function isItemCreatedDateHigherThanTheSpecifiedStartDate($start_date,$create_time){
                 
                 $item_create_time = getdate($create_time);
                 $date_start = getdate($start_date);
                 
                  if(($item_create_time['year'] - $date_start['year'])>0){
                      return true;
                  }else if(($item_create_time['year'] - $date_start['year'])===0){
                      if(($item_create_time['mon'] - $date_start['mon']) > 0){
                          return true;
                      }else if(($item_create_time['mon'] - $date_start['mon'])===0){
                          if(($item_create_time['mday'] - $date_start['mday'])>=0){
                              return true;
                          }else{
                              return false;
                          }
                      }else{
                          return false;
                      }
                      
                  }else{
                      return false;
                  }
                      
                 
             }
             
                                      
             
             /**
              * This is the function of generates the odr0003 report
              */
             public function actiongetODR0003ReportContent(){
                 
                  $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainPrivateProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
          
                 
             }
             
             
             /**
              * This is the function that spools all the domains private programs and events within a range
              */
             public function getAllThisDomainPrivateProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date){
                 
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id and visibility=:visibility';
                      $criteria1->params = array(':id'=>$domain_id, ':visibility'=>'private');
                      $items= Resourcegroup::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                 
             }
             
             
             
             /**
              * This is the function that generates the odr0004 report
              */
             public function actiongetODR0004ReportContent(){
                 
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainPublicProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
                 
             }
             
             
             
             /**
              * This is the function that generates a domains public programs & events within a specified period 
              */
             public function getAllThisDomainPublicProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date){
                 
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id and visibility=:visibility';
                      $criteria1->params = array(':id'=>$domain_id, ':visibility'=>'public');
                      $items= Resourcegroup::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                 
             }
             
             
             /**
              * This is the function that generates the odr0005 report
              */
             public function actiongetODR0005ReportContent(){
                 
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainPublicPrivateProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
                 
             }
             
             
             /**
              * This is the function that will spool a domains private/public programs & events within a period
              */
             public function getAllThisDomainPublicPrivateProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date){
                 
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id and visibility=:visibility';
                      $criteria1->params = array(':id'=>$domain_id, ':visibility'=>'private & public');
                      $items= Resourcegroup::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                 
             }
             
             
             /**
              * This is the function that will generate the odr0006 report
              */
             public function actiongetODR0006ReportContent(){
                 
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainReservedProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
                 
             }
             
             
             /**
              * This is the function  the spools a domains reserved programs & events  within a period
              */
             public function getAllThisDomainReservedProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date){
                 
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id and visibility=:visibility';
                      $criteria1->params = array(':id'=>$domain_id, ':visibility'=>'reserved');
                      $items= Resourcegroup::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                 
             }
             
             
             
             /**
              * This is the function that generates the odr0007 report
              */
             public function actiongetODR0007ReportContent(){
                 
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainRestrictedPublicProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
                 
             }
             
             
             
             /**
              * This is the function that spools the domains restricted public programs & events within a period
              */
             public function getAllThisDomainRestrictedPublicProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date){
                 
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id and visibility=:visibility';
                      $criteria1->params = array(':id'=>$domain_id, ':visibility'=>'restricted_public');
                      $items= Resourcegroup::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                 
             }
             
             
             /**
              * This is the function that generates the odr0008 report
              */
             public function actiongetODR0008ReportContent(){
                 
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainPrivateRestrictedPublicProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
                 
             }
             
           
             
             
          /**
           * This is the function that spools a domains private/restricted public programs & events within a range
           */   
            public function getAllThisDomainPrivateRestrictedPublicProgramsAndEventsWithinThisDateRange($domain_id,$start_date,$end_date){
                
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id and visibility=:visibility';
                      $criteria1->params = array(':id'=>$domain_id, ':visibility'=>'private & restricted_public');
                      $items= Resourcegroup::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                
            }
             
            
            /**
             * This is the function that generates the odr0002 report
             */
            public function actiongetODR0002ReportContent(){
                
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSessionsWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resources::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
                
            }
                
                
                /**
                 * This is the function that spools all the media sessions for a domain within a period
                 */
                public function getAllThisDomainMediaSessionsWithinThisDateRange($domain_id,$start_date,$end_date){
                    
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id and parent_id is null';
                      $criteria1->params = array(':id'=>$domain_id);
                      $items= Resources::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                    
                }
                
            
            
                
                /**
                 * This is the function that generates the odr0008 report
                 */
                public function actiongetODR0009ReportContent(){
                    
                    $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllDomainsConsumingThisDomainMediaServices($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= ResourceGroupCategory::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "contents"=>$contents
                           
                       ));
                       
                } 
                    
                }
            
         
                /**
                 * This is the function that gets all the domains consuming a domains media services within a period
                 */
                public function getAllDomainsConsumingThisDomainMediaServices($domain_id,$start_date,$end_date){
                    
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='category_id!=:id and toolbox_status=:status';
                      $criteria1->params = array(':id'=>$domain_id, ':status'=>'active');
                      $items= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemOwnedByThisDomain($domain_id,$item['resourcegroup_id'])===false){
                            if($this->isMediaItemWithinTheDateRange(strtotime($item['end_date']),$start_date,$end_date)){
                              $all_media[] = $item['category_id'];
                            }
                          }
                          
                      }
                      
                      return array_unique($all_media);
                    
                }
                
                
                /**
                 * This is the function that verifies if a media item/program belongs to a domain
                 */
            public function isMediaItemOwnedByThisDomain($domain_id,$media_program_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("domain_id = $domain_id && id =$media_program_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
                
            }
            
            
            
            /**
             * This is the function that generates the odr0010 report
             */
            public function actiongetODR0010ReportContent(){
                
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all countries where domain resources are consumed
                 
                 $contents = $this->getAllCountriesWhereDomainMediaServicesConsumed($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports=Country::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
                
                
            }
            
            
            /**
             * This is the function that gets the countries where domains that consumed this domain media services are operating from
             */
            public function getAllCountriesWhereDomainMediaServicesConsumed($domain_id,$start_date,$end_date){
                
                //get all the resources consumed by other domains
                
                $all_consumer_domains = $this->getAllDomainsConsumingThisDomainMediaServices($domain_id,$start_date,$end_date);
                
                $all_countries = [];
                
                foreach($all_consumer_domains as $consumer){
                    
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$consumer);
                      $domain= ResourceGroupCategory::model()->find($criteria1);
                      
                      $all_countries[] = $domain['country_id'];
              
                }
                
                return array_unique($all_countries);
                
               
            }
            
          
            /**
             * This is the functin that generates the odr0011 report
             **/
            public function actiongetODR0011ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRange($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resources::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           
                       ));
                       
                } 
                
            }
            
            
            
            /**
             * This is the function that spools a domain media slots within a given period
             */
            public function getAllThisDomainMediaSlotWithinThisDateRange($domain_id,$start_date,$end_date){
                
                     $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id and parent_id is not null';
                      $criteria1->params = array(':id'=>$domain_id);
                      $items= Resources::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                          if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                      }
                      
                      return $all_media;
                
            }
            
            
            
            /**
             * This is the function that generates the odr0012 report
             */
            public function actiongetODR0012ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeCurrentlyUnderPreview($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= PreviewTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
            }
            
            
            /**
             * This is the function that gets a domains media slot that are currently been previewed
             **/
            public function getAllThisDomainMediaSlotWithinThisDateRangeCurrentlyUnderPreview($domain_id,$start_date,$end_date){
                
                      $all_media = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                     $criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= PreviewTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
                
                
            }
            
            
            
            /**
             * This is the function that confirms if a domain is the owner of a media slot
             */
            public function isThisDomainTheOwnerOfThisMedia($media_id,$domain_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resources')
                    ->where("domain_id = $domain_id && id =$media_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            /**
             * This is the function that generates the odr0013 report
             */
            public function actiongetODR0013ReportContent(){
                
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeCurrentlyPlaying($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= PlayerTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
            }
            
            
            /**
             * This is the function that spools all the surrently playing media
             */
            public function getAllThisDomainMediaSlotWithinThisDateRangeCurrentlyPlaying($domain_id,$start_date,$end_date){
                
                    $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                     $criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= PlayerTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            
            /**
             * This is the function that generates the odr0014 report
             */
            public function actiongetODR0014ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeThatHadBeenPreviewedOrUndergoingPreviews($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= PreviewTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
            }
            
            
           
            /**
             * This is the function that gets all users that had previewed or currently previewing a domain media 
             */
            public function getAllThisDomainMediaSlotWithinThisDateRangeThatHadBeenPreviewedOrUndergoingPreviews($domain_id,$start_date,$end_date){
                
                 $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                     //$criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= PreviewTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            
            
            
            /**
             * This is the function that generates the odr0015 report
             */
            public function actiongetODR0015ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeThatHadBeenPlayedOrPlaying($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= PlayerTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
                
                
                
            } 
            
            
            
            
            /**
             * This is the function that spools all users that had played or currently playing a domain media
             */
            public function getAllThisDomainMediaSlotWithinThisDateRangeThatHadBeenPlayedOrPlaying($domain_id,$start_date,$end_date){
                
                $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                     //$criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= PlayerTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
                
                
            }
            
            
            /**
             * This is the function that geneerates the odr0017 report
             */
            public function actiongetODR0016ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeThatWasDownloaded($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= FullDownloadTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
                
                
            }
            
            
            
            
            
            /**
             * This is the report that spools all the users that effected download on domain media
             */
            public function getAllThisDomainMediaSlotWithinThisDateRangeThatWasDownloaded($domain_id,$start_date,$end_date){
                
                $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                     //$criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= FullDownloadTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            
            /**
             * This is the function that generates the odr0017 report
             */
            public function actiongetODR0017ReportContent(){
                
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeWithResourceDownloaded($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= ResourceDownloadTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
                
                
            }
            
            
        
            
            
          /**
           * This is the function that spools all users that effected  media resource donwloads
           */
            public function getAllThisDomainMediaSlotWithinThisDateRangeWithResourceDownloaded($domain_id,$start_date,$end_date){
                
                $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                     //$criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= ResourceDownloadTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
                
                
            }
            
            
            
            
            /**
             * This is the function that generates the odr0018 report
             */
            public function actiongetODR0018ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeThatWasDownloadedByDomains($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= PreviewTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
            }
            
            
            
            
            /***
             *This is the function that spools all media downloaded by domains
             */
            public function getAllThisDomainMediaSlotWithinThisDateRangeThatWasDownloadedByDomains($domain_id,$start_date,$end_date){
                
                $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                     //$criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= PreviewTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            
            /**
             * This is the function that generates the odr0019 report
             */
            public function actiongetODR0019ReportContent(){
              
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeThatPreviewedByCountryDomains($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= PreviewTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
                
            }
        
            
           /**
            * This is the function that spools all media previewed by country domains
            **/ 
            public function getAllThisDomainMediaSlotWithinThisDateRangeThatPreviewedByCountryDomains($domain_id,$start_date,$end_date){
                
                
                $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                     //$criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= PreviewTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            
            
            
            /**
             * This is the function that generates the odr0020 report
             */
            public function actiongetODR0020ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getAllThisDomainMediaSlotWithinThisDateRangeThatDownloadsWereEffectedByDomains($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= FullDownloadTrail::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
                
            }
            
            
            
            /**
             * This is the function that spool all domain-base downloads 
             */
            public function getAllThisDomainMediaSlotWithinThisDateRangeThatDownloadsWereEffectedByDomains($domain_id,$start_date,$end_date){
                
                $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                     //$criteria1->condition='stop_time is null';
                      //$criteria1->params = array(':id'=>$domain_id);
                      $items= ResourceDownloadTrail::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                         if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['start_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                         }
                          
                      }
                      
                      return $all_media;
            }
            
            
            
            /**
             * This is the function that generates the odr0021 report
             */
            public function actiongetODR0021ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the resources/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfPartnersOfThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='partner_id=:id and domain_id=:domainid';
                      $criteria1->params = array(':id'=>$content, ':domainid'=>$domain_id);
                      $reports= DomainHasPartners::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
            }
            
            
            /**
             * This is the function that gets the list of domain partners 
             */
            public function getTheListOfPartnersOfThisDomain($domain_id,$start_date,$end_date){
                
                $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='domain_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $items= DomainHasPartners::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        // if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['partner_id'];
                          }
                       //  }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            
            
           /**
            * This is the function that generates the odr0022 report
            */ 
            public function actiongetODR0022ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfNetworksOfThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id and domain_id=:domainid';
                      $criteria1->params = array(':id'=>$content, ':domainid'=>$domain_id);
                      $reports= Network::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                
            }
            
            
            
            
            /**
             * This is the function that spools the list of networks for a domain
             */
            public function getTheListOfNetworksOfThisDomain($domain_id,$start_date,$end_date){
                
                
                $all_network = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='domain_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $items= Network::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        // if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_network[] = $item['id'];
                          }
                       //  }
                          
                      }
                      
                      return $all_network;
                
            }
            
            
            /**
             * This is the function that will generate the odr0023 report
             */
            public function actiongetODR0023ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['network_id'] != ""){
                     $network_id = $_REQUEST['network_id'];
                 }else {
                     $network_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain network
                 $all_networks = $this->getAllDomainNetworks($domain_id);
                 
                 if($network_id == 0){
                     
                     foreach($all_networks as $network_id){
                    $contents = $this->getTheListOfMembersOfThisNetwork($network_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='member_id=:id and network_id=:netid';
                      $criteria1->params = array(':id'=>$content, ':netid'=>$network_id);
                      $reports= NetworkHasMembers::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfMembersOfThisNetwork($network_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='member_id=:id and network_id=:netid';
                      $criteria1->params = array(':id'=>$content, ':netid'=>$network_id);
                      $reports= NetworkHasMembers::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
                
            }
            
            
            /**
             * This is the function that spools the members of a network
             */
            public function getTheListOfMembersOfThisNetwork($network_id,$start_date,$end_date){
                
                    $all_members = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='network_id=:id';
                    $criteria1->params = array(':id'=>$network_id);
                    $items= NetworkHasMembers::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        // if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                             $all_members[] = $item['member_id'];
                          }
                       //  }
                          
                      }
                      
                      return $all_members;
                
            }
            
            
            
            
            
            /**
             * This is the function that generates the odr0024 report
             */
            public function actiongetODR0024ReportContent(){
                
                 $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['network_id'] != ""){
                     $network_id = $_REQUEST['network_id'];
                 }else {
                     $network_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain network
                 $all_networks = $this->getAllDomainNetworks($domain_id);
                 
                 if($network_id == 0){
                     
                     foreach($all_networks as $network_id){
                    $contents = $this->getTheListOfProgramsAndEventsBelongingToThisNetwork($network_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='toolbox_id=:id and domain_id=:domainid';
                      $criteria1->params = array(':id'=>$content, ':domainid'=>$domain_id);
                      $reports= NetworkHasToolboxes::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfProgramsAndEventsBelongingToThisNetwork($network_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='toolbox_id=:id and domain_id=:domainid';
                      $criteria1->params = array(':id'=>$content, ':domainid'=>$domain_id);
                      $reports= NetworkHasToolboxes::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
     
            }
            
            
            /**
             * This is the function that gets all domains network
             */
            public function getAllDomainNetworks($domain_id){
                
                    $all_domain_networks = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='domain_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $networks= Network::model()->findAll($criteria1);
                    
                    foreach($networks as $network){
                        $all_domain_networks[] = $network['id'];
                    }
                return $all_domain_networks;
            }
            
            
            /**
             * This is the function that spools all the reserved media in a network
             */
            public function getTheListOfProgramsAndEventsBelongingToThisNetwork($network_id,$start_date,$end_date){
                
            
                $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='network_id=:id';
                    $criteria1->params = array(':id'=>$network_id);
                    $items= NetworkHasToolboxes::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                      //  if($this->isThisDomainTheOwnerOfThisNetwork($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                             $all_media[] = $item['toolbox_id'];
                          }
                       // }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            /**
             * This is the function that generates the odr0025 report
             */
            public function actiongetODR0025ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfUsersOfThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= User::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                }
                
                
            }
            
            
            
            /**
             * This is the function that gets the list of domain users
             */
            public function getTheListOfUsersOfThisDomain($domain_id,$start_date,$end_date){
                
                
                 $all_users = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='domain_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $items= User::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        // if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_users[] = $item['id'];
                          }
                       //  }
                          
                      }
                      
                      return $all_users;
                
            }
            
            
            
            
            
            
            /**
             * This is the function that generates the odr0026 report
             */
            public function actiongetODR0026ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfActiveUsersOfThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= User::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                }
                
            }
            
            
            
            /**
             * This is the function that spools the active users in a domain
             */
            public function getTheListOfActiveUsersOfThisDomain($domain_id,$start_date,$end_date){
                
                $all_users = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='domain_id=:id and status=:status';
                    $criteria1->params = array(':id'=>$domain_id,':status'=>'active');
                    $items= User::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        // if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_users[] = $item['id'];
                          }
                       //  }
                          
                      }
                      
                      return $all_users;
                
                
            }
            
            
            
            
            
            
             /**
             * This is the function that generates the odr0027 report
             */
            public function actiongetODR0027ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes/users that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfInActiveUsersOfThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= User::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                }
                
            }
            
            
            
            /**
             * This is the function that spools the active users in a domain
             */
            public function getTheListOfInActiveUsersOfThisDomain($domain_id,$start_date,$end_date){
                
                $all_users = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='domain_id=:id and status=:status';
                    $criteria1->params = array(':id'=>$domain_id,':status'=>'inactive');
                    $items= User::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        // if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_users[] = $item['id'];
                          }
                       //  }
                          
                      }
                      
                      return $all_users;
                
                
            }
            
            
            
            
            /**
             * This is the function thaat generates the odr0028 report
             */
            public function actiongetODR0028ReportContent(){
                
                  $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['keyword_id'] != ""){
                     $keyword_id = $_REQUEST['keyword_id'];
                 }else {
                     $keyword_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain keywords
                 $all_keywords = $this->getAllDomainKeywords($domain_id);
                 
                 if($keyword_id == 0){
                     
                     foreach($all_keywords as $key_id){
                    $contents = $this->getTheListOfDomainMediaWithThisKeyword($key_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfDomainMediaWithThisKeyword($keyword_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
                
                
            }
            
            
            
            /**
             * This is the function that spools all the keywords for a domain
             */
            public function getTheListOfDomainMediaWithThisKeyword($key_id,$domain_id,$start_date,$end_date){
                
               $all_keywords= [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='keyword_id=:id';
                    $criteria1->params = array(':id'=>$key_id);
                    $items= MediaHasKeywords::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_keywords[] = $item['id'];
                          }
                       }
                          
                      }
                      
                      return $all_keywords;
                
            }
            
            
            /**
             * This is the function that gets all domain keywords 
             */
            public function getAllDomainKeywords($domain_id){
                $all_keywords = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id';
                      $criteria1->params = array(':id'=>$domain_id);
                      $keywords= Keywords::model()->findAll($criteria1);
                      
                      foreach($keywords as $keyword){
                          $all_keywords[] = $keyword['id'];
                      }
                
                      return $all_keywords;
            }
            
            
            
            
            /**
             * This is the function that generates the odr0029 report
             */
            public function actiongetODR0029ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['actor_id'] != ""){
                     $actor_id = $_REQUEST['actor_id'];
                 }else {
                     $actor_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain keywords
                 $all_actors = $this->getAllDomainActors($domain_id);
                 
                 if($actor_id == 0){
                     
                    foreach($all_actors as $actorid){
                    $contents = $this->getTheListOfDomainMediaWithThisActor($actorid,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfDomainMediaWithThisActor($actor_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                                           
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
                
                
            }
            
            
            
            /**
             * This is the function that spools all media with the specified actor
             */
            public function getTheListOfDomainMediaWithThisActor($actor_id,$domain_id,$start_date,$end_date){
                
                    $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='actor_id=:id';
                    $criteria1->params = array(':id'=>$actor_id);
                    $items= MediaHasKeywords::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                       }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            
            /**
             * This is the function that gets all domain keywords 
             */
            public function getAllDomainActors($domain_id){
                $all_actors = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id';
                      $criteria1->params = array(':id'=>$domain_id);
                      $actors= Actors::model()->findAll($criteria1);
                      
                      foreach($actors as $actor){
                          $all_actors[] = $actor['id'];
                      }
                
                      return $all_actors;
            }
            
            /**
             * This is the funtion that generates the odr0030 report
             */
            public function actiongetODR0030ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['designation_id'] != ""){
                     $designation_id = $_REQUEST['designation_id'];
                 }else {
                     $designation_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain keywords
                 $all_designations = $this->getAllDomainDesignations($domain_id);
                 
                 if($designation_id == 0){
                     
                    foreach($all_designations as $designationid){
                    $contents = $this->getTheListOfDomainMediaWithThisDesignation($designationid,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfDomainMediaWithThisDesignation($designation_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                       $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                                           
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
                
            }
            
            
            
            
            /**
             * This is the function that spools the media with a specified designation
             */
            public function getTheListOfDomainMediaWithThisDesignation($designation_id,$domain_id,$start_date,$end_date){
                
                
                    $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='designation_id=:id';
                    $criteria1->params = array(':id'=>$designation_id);
                    $items= MediaHasKeywords::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                       }
                          
                      }
                      
                      return $all_media;
            }
            
            
            
            /**
             * This is the function that gets all domain keywords 
             */
            public function getAllDomainDesignations($domain_id){
                $all_designations = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id=:id';
                      $criteria1->params = array(':id'=>$domain_id);
                      $designations= Designations::model()->findAll($criteria1);
                      
                      foreach($designations as $designation){
                          $all_designations[] = $designation['id'];
                      }
                
                      return $all_designations;
            }
            
            
            
            
            /**
             * This is the function that generates the odr0031 report
             */
            public function actiongetODR0031ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['context_id'] != ""){
                     $context_id = $_REQUEST['context_id'];
                 }else {
                     $context_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain keywords
                 $all_contexts = $this->getAllPlatformContexts();
                 
                 if($context_id == 0){
                     
                    foreach($all_contexts as $contextid){
                    $contents = $this->getTheListOfPlatformContext($contextid,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfPlatformContext($context_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                       $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                                           
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
                
                
            }
            
            
            /**
             * This is the function that spools all media within a specified context
             */
            public function getTheListOfPlatformContext($context_id,$domain_id,$start_date,$end_date){
                
                    $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='context_id=:id';
                    $criteria1->params = array(':id'=>$context_id);
                    $items= MediaHasKeywords::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id)){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_media[] = $item['id'];
                          }
                       }
                          
                      }
                      
                      return $all_media;
                
            }
            
            
            /**
             * This is the function that gets all contexts in the platform
             */
            public function getAllPlatformContexts(){
                
                $all_contexts = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      //$criteria1->condition='domain_id=:id';
                     // $criteria1->params = array(':id'=>$domain_id);
                      $contexts= Contexts::model()->findAll($criteria1);
                      
                      foreach($contexts as $context){
                          $all_contexts[] = $context['id'];
                      }
                
                      return $all_contexts;
                
            }
            
            
            
            
            
            
            /**
             * This is the function that generates the ddr001 report
             */
            public function  actiongetDDR0001ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes/users that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='resourcegroup_id=:id and category_id=:domainid';
                      $criteria1->params = array(':id'=>$content,':domainid'=>$domain_id);
                      $reports= ResourcegroupHasResourcegroupcategory::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                }
                
                
            }
            
            
            
            /**
             * This is the function that will spool all other domain's programs & events consumed by this domain 
             */
            public function getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date){
                
                    $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='category_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $items= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisProgramAndEvent($item['resourcegroup_id'],$domain_id) === false){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['max_date']),$start_date,$end_date)){
                              $all_media[] = $item['resourcegroup_id'];
                         }
                       }
                          
                      }
                      
                       //get the unigue sessions in this program
                                            
                      return array_unique($all_media);
                
            }
            
            
            /**
             * This is the function that confirms if a program belongs to a domain
             */
            public function isThisDomainTheOwnerOfThisProgramAndEvent($toolbox_id,$domain_id){
                
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("domain_id = $domain_id && id =$toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
           
            
            /**
             * This is the function that will generate the ddr0002 report
             */
            public function  actiongetDDR0002ReportContent(){
                
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes/users that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 
                $all_sessions = [];
                $session_unique = [];
                $dsession = [];
                 
                 foreach($contents as $media_program_id){
                     //get all the sessions that make up this program
                     $all_sessions = $this->getAllSessionsInThisMediaProgram($media_program_id);
                     
                     $dsession[] = $all_sessions;
                   }
                 $session_unique = $this->getOnlyTheUniqueSessions($dsession);
                   //get the slots in each media session
                  $all_slots = [];
                  $dslot = [];
                  $usable_slots = [];
                  foreach($session_unique as $session){
                     $all_slots = $this->getAllMediaSlotsBelongingToThisSession($session);
                     $dslot[] = $all_slots;
                  }
                  $usable_slots = $this->getTheUsableInASingleDimensionalArray($dslot);
                  //get the details of this media slot
                  
                  $all_contents = [];
                  foreach($usable_slots as $slot){
                      
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$slot);
                      $reports= Resources::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                  }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "report" => $all_contents,
                          // "content"=>$contents,
                         // "usable_slots"=>$usable_slots,
                          // "unique_sessions"=>$session_unique,
                          // "all_slot"=>$dslot
                           
                       ));
                       
                }
                
                
                
            }
            
            
            /**
             * This is the function that gets only the unique sessions
             */
            public function getOnlyTheUniqueSessions($dsession){
                
                $all_session = [];
                if(is_array($dsession)){
                    foreach($dsession as $session){
                        if(is_array($session)){
                            foreach($session as $ses){
                               $all_session[] =  $ses;
                            }
                        }else{
                           $all_session[] = $session; 
                        }
                    }
                    return array_unique($all_session);
                }else{
                    return $dsession;
                }
            }
            
            
            /**
             * This is the funation that produces a single dimensional array of the usable slot
             */
            public function getTheUsableInASingleDimensionalArray($usable_slots){
                
                $all_slot = [];
                if(is_array($usable_slots)){
                    foreach($usable_slots as $slots){
                        if(is_array($slots)){
                            foreach($slots as $ses){
                               $all_slot[] =  $ses;
                            }
                        }else{
                           $all_slot[] = $slots; 
                        }
                    }
                    return $all_slot;
                }else{
                    return $usable_slots;
                }
                
            }
            
            
            
            
            /**
             * This is the function that gets all sessions in a program
             */
            public function getAllSessionsInThisMediaProgram($media_program_id){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resourcegroup_id=:id';
                $criteria->params = array(':id'=>$media_program_id);
                $sessions= ResourceHasResourcegroups::model()->findAll($criteria);
                
                $all_sessions = [];
                foreach($sessions as $session){
                     $all_sessions[] = $session['resource_id'];
                }
            
                return $all_sessions;
                
            }
            
            
            /**
             * This is the function to spool all slots in a session
             */
            public function getAllMediaSlotsBelongingToThisSession($session_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='parent_id=:id';  
                    $criteria->params = array(':id'=>$session_id);
                    $resources = Resources::model()->findAll($criteria);
                    
                    $all_slots = [];
                    foreach($resources as $session){
                         $all_slots[] = $session['id'];
                    }
                    return $all_slots;
            }
            
            
            
            /**
             * This is the function that generates the ddr0003 report
             */
            public function actiongetDDR0003ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes/users that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfMembershipToOtherDomainNetwork($domain_id,$start_date,$end_date);
                 
              
                 $all_contents = [];
                  foreach($contents as $content){
                      
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='member_id=:domainid and network_id=:networkid';
                      $criteria1->params = array(':domainid'=>$domain_id,':networkid'=>$content);
                      $reports= NetworkHasMembers::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                  }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                }
            }
            
            
            
            
            
            /**
             * this is the function that spools the networks that this domain is a member
             */
            public function getTheListOfMembershipToOtherDomainNetwork($domain_id,$start_date,$end_date){
                
                $all_network = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='member_id=:domainid';
                    $criteria1->params = array(':domainid'=>$domain_id);
                    $items= NetworkHasMembers::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisNetwork($item['network_id'],$domain_id) === false){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_network[] = $item['network_id'];
                          }
                       }
                          
                      }
                      
                       //get the unigue sessions in this program
                                            
                      return array_unique($all_network);
                
            }
            
            
            
            /**
             * This is the function that confirms that a domain is the owner of a network
             */
            public function isThisDomainTheOwnerOfThisNetwork($network_id,$domain_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network')
                    ->where("domain_id = $domain_id && id =$network_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            
            
            /**
             * This is the function that generates the ddr0004 report
             */
            public function actiongetDDR0004ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 ///get the networks that this network is a member
                 
                 $networks = $this->getTheListOfMembershipToOtherDomainNetwork($domain_id,$start_date,$end_date);
                 
                   
                 $network_programs = [];   
                 $unique_programs = [];
                 foreach($networks as $network){
                   
                     $network_programs = $this->getTheReservedProgramsInThisNetwork($network);
                   
                 }
                 
                 //make the programs unique
                 $unique_programs = array_unique($network_programs);
                 
                 $all_contents = [];
                 //get the detail description of reserved programs in the network
                foreach($unique_programs as $content){
                      
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                  }
                 
                 
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                            "content"=>$networks
                           
                       ));
                       
                }
                
                
            }
            
            
            /**
             * This is the function that list all reserved program in a network
             */
            public function getTheReservedProgramsInThisNetwork($network_id){
                
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='network_id=:id';
                      $criteria1->params = array(':id'=>$network_id);
                      $contents= NetworkHasToolboxes::model()->findAll($criteria1);
                      
                      $all_contents = [];
                      foreach($contents as $content){
                          $all_contents[] = $content['toolbox_id'];
                      }
                
                      return $all_contents;
            }
            
            
            
            /**
             * This is the function that generates the ddr0005 report
             */
            public function actiongetDDR0005ReportContent(){
               
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes/users that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfOtherDomainsPublicProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                }
                
            }
            
            
            /**
             * This is the function that gets the list of public programs consumed by this domain which belongs to other domains
             */
            public function getTheListOfOtherDomainsPublicProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date){
                
                    $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='category_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $items= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisProgramAndEvent($item['resourcegroup_id'],$domain_id) === false){
                           if($this->isTheProgramVisibilityPublic($item['resourcegroup_id'])){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['end_date']),$start_date,$end_date)){
                                $all_media[] = $item['resourcegroup_id'];
                             }
                            }
                             
                       }
                          
                      }
                      
                       //get the unigue program
                                            
                      return array_unique($all_media);
                
            }
            
            
            /**
             * This is the function that determines if a program visibility is public
             */
            public function isTheProgramVisibilityPublic($program_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("id = $program_id && (visibility ='public' || visibility ='private & public' )");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
                
            }
            
            
            
            /**
             * This is the function that generates the ddr0006 report
             */
            public function actiongetDDR0006ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes/users that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfOtherDomainsPrivateProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                }
                
                
            }
            
            
            /**
             * This is the function that spools the private programs of other domains consumed by this domain
             */
            public function getTheListOfOtherDomainsPrivateProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date){
                
                    $all_media = [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='category_id=:id';
                    $criteria1->params = array(':id'=>$domain_id);
                    $items= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisProgramAndEvent($item['resourcegroup_id'],$domain_id) === false){
                           if($this->isTheProgramVisibilityPrivate($item['resourcegroup_id'])){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['end_date']),$start_date,$end_date)){
                                $all_media[] = $item['resourcegroup_id'];
                             }
                            }
                             
                       }
                          
                      }
                      
                       //get the unigue program
                                            
                      return array_unique($all_media);
                
            }
            
            
            /**
             * This is the function that confirms id a program visibility is private
             */
            public function isTheProgramVisibilityPrivate($program_id){
                
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('resourcegroup')
                    ->where("id = $program_id && (visibility ='private' || visibility ='private & public' || visibility ='private & restricted_public')");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            
            /**
             * This is the function that generates the ddr0007 report
             */
            public function actiongetDDR0007ReportContent(){
                
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes/users that are created within this time range for this domain
                 
                 $contents = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_contents = [];
                 
                 foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= Resourcegroup::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
        
                 }
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           "content"=>$contents
                           
                       ));
                       
                }
                
                
            }
            
            
            /**
             * This is the function that generates the ddr0008 report
             */
            public function actiongetDDR0008ReportContent(){
                
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 
                 
                 //spool all the networks/programs & events/toolboxes/users that are created within this time range for this domain
                 
                 $programs = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 $all_domains = [];
                 //get the domain id for each of this program
                 foreach($programs as $program){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$program);
                      $domain= Resourcegroup::model()->find($criteria1);
                      
                      $all_domains[]=$domain['domain_id'];
        
                 }
                 
                 $all_contents = [];
                 //get the country of each of these domains
                 foreach($all_domains as $content){
                      $criteria2 = new CDbCriteria();
                      $criteria2->select = '*';
                      $criteria2->condition='id=:id';
                      $criteria2->params = array(':id'=>$content);
                      $reports= Resourcegroupcategory::model()->find($criteria2);
                      
                      $all_contents[]=$reports;
        
                 }
                 
                 if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           //"content"=>$contents
                           
                       ));
                       
                }
                
                
            }
            
            
            
            
            /**
             * This is the function that generates the ddr0009 report
             */
            public function actiongetDDR0009ReportContent(){
                
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['keyword_id'] != ""){
                     $keyword_id = $_REQUEST['keyword_id'];
                 }else {
                     $keyword_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain keywords
                 $all_keywords = $this->getAllKeywordsFromOtherDomainsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 if($keyword_id == 0){
                     
                     foreach($all_keywords as $key_id){
                    $contents = $this->getTheListOfOtherDomainMediaWithThisKeyword($key_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                          "content"=>$contents,
                           "all_keywords"=>$all_keywords
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfOtherDomainMediaWithThisKeyword($keyword_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                          "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
                 
                
            }
            
            
            /**
             * This is the function that gets a list of other domain's media with a particular keyword
             */
            public function getTheListOfOtherDomainMediaWithThisKeyword($key_id,$domain_id,$start_date,$end_date){
                
                $all_keywords= [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='keyword_id=:id';
                    $criteria1->params = array(':id'=>$key_id);
                    $items= MediaHasKeywords::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id) === false){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_keywords[] = $item['id'];
                          }
                       }
                          
                      }
                      
                      return $all_keywords;
                
            }
            
            
            /**
             * This is the function that gets the keywords of other domain resources consumed by this domain
             */
            public function getAllKeywordsFromOtherDomainsConsumedByThisDomain($domain_id,$start_date,$end_date){
                
                $all_keywords = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id!=:id';
                      $criteria1->params = array(':id'=>$domain_id);
                      $keywords= Keywords::model()->findAll($criteria1);
                      
                      foreach($keywords as $keyword){
                          if($this->isThisKeywordInAProgramConsumedByThisDomain($keyword['id'],$domain_id,$start_date,$end_date)){
                             $all_keywords[] = $keyword['id']; 
                          }
                          
                      }
                
                      return $all_keywords;
                
            }
            
            
            /***
             * This is the function that determines if a keyword is in a program consumed by a domain
             */
            public function isThisKeywordInAProgramConsumedByThisDomain($keyword,$domain_id,$start_date,$end_date){
                
                //get all the other domain programs consumed by this domain
                $all_programs = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                
                //on each program, get the corresponding sessions
                $all_sessions = [];
                foreach($all_programs as $media_program_id){
                     //get all the sessions that make up this program
                     $all_sessions[] = $this->getAllSessionsInThisMediaProgram($media_program_id);
                     
                   }
                   
                   //put all the sessions in a one dimensional array and make it unique
                   $dsessions = array_unique($this->makeThisArrayAOneDimensionalArray($all_sessions));
                   //get the slots in each media session
                  $all_slots = [];
                  foreach($dsessions as $session){
                      $all_slots[] = $this->getAllMediaSlotsBelongingToThisSession($session);
               
                  }
                  
                  //put the slot in one dimensional array
                  $dslots = $this->makeThisArrayAOneDimensionalArray($all_slots);
                  $counter = 0;
                  foreach($dslots as $slot){
                      if($this->isMediaSlotWithThisKeyword($slot,$keyword)){
                          $counter = $counter + 1;
                       
                      }
                  }
                  if($counter > 0){
                      return true;
                  }else{
                       return false;
                  }
                 
            }
            
            
            
            
            /**
             * This is the function that makes session's array of arrays a one dimensional array
             */
            public function makeThisArrayAOneDimensionalArray($items){
                
                $all_item = [];
                if(is_array($items)){
                    foreach($items as $iten){
                        if(is_array($iten)){
                            foreach($iten as $ten){
                               $all_item[] =  $ten;
                            }
                        }else{
                           $all_item[] = $iten; 
                        }
                    }
                    return $all_item;
                }else{
                    return $items;
                }
            }
            
            /**
             * This is the function that determines if a media slot has keyword
             */
            public function isMediaSlotWithThisKeyword($media_id,$keyword_id){
                
                
              $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('media_has_keywords')
                    ->where("media_id = $media_id && keyword_id =$keyword_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
            
            /**
             * This is the function that generates the ddr0010 report
             */
            public function actiongetDDR0010ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['actor_id'] != ""){
                     $actor_id = $_REQUEST['actor_id'];
                 }else {
                     $actor_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain keywords
                 $all_actors = $this->getAllActorsFromOtherDomainsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 if($actor_id == 0){
                     
                     foreach($all_actors as $actorid){
                    $contents = $this->getTheListOfOtherDomainMediaWithThisActor($actorid,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           //"content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfOtherDomainMediaWithThisActor($actor_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                          // "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
  
                 
            }
            
            
            
            /**
             * This is the function that gets all actors from other domains that were consumed by this domain
             */
            public function getAllActorsFromOtherDomainsConsumedByThisDomain($domain_id,$start_date,$end_date){
                
                      $all_actors = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id!=:id';
                      $criteria1->params = array(':id'=>$domain_id);
                      $actors= Actors::model()->findAll($criteria1);
                      
                      foreach($actors as $actor){
                          if($this->isThisActorInAProgramConsumedByThisDomain($actor['id'],$domain_id,$start_date,$end_date)){
                             $all_actors[] = $actor['id']; 
                          }
                          
                      }
                
                      return $all_actors;
      
            }
            
       
            /**
             * This is the function that determines if an actor is in a program consumed by this domain
             */
            public function isThisActorInAProgramConsumedByThisDomain($actor,$domain_id,$start_date,$end_date){
                
                
                 //get all the other domain programs consumed by this domain
                $all_programs = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                
                //on each program, get the corresponding sessions
                $all_sessions = [];
                foreach($all_programs as $media_program_id){
                     //get all the sessions that make up this program
                     $all_sessions[] = $this->getAllSessionsInThisMediaProgram($media_program_id);
                     
                   }
                   //put all the sessions in a one dimensional array and make it unique
                   $dsessions = array_unique($this->makeThisArrayAOneDimensionalArray($all_sessions));
                   //get the slots in each media session
                  $all_slots = [];
                  foreach($dsessions as $session){
                      $all_slots[] = $this->getAllMediaSlotsBelongingToThisSession($session);
               
                  }
                  //put the slot in one dimensional array
                  $dslots = $this->makeThisArrayAOneDimensionalArray($all_slots);
                  $counter = 0;
                  foreach($dslots as $slot){
                      if($this->isMediaSlotWithThisActor($slot,$actor)){
                          $counter = $counter + 1;
                      }
                  }
                  if($counter > 0){
                      return true;
                  }else{
                      return false;
                  }
                
            }
            
            
            /**
             * This is the function that determines  if a media slot has an actor
             */
            public function isMediaSlotWithThisActor($media_id,$actor_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('media_has_keywords')
                    ->where("media_id = $media_id && actor_id =$actor_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
                
            }
            
        
            /**
             * This is the function that get the list of other domain media with an actor
             */
            public function getTheListOfOtherDomainMediaWithThisActor($actor_id,$domain_id,$start_date,$end_date){
                
                    $all_actors= [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='actor_id=:id';
                    $criteria1->params = array(':id'=>$actor_id);
                    $items= MediaHasKeywords::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id) === false){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_actors[] = $item['id'];
                          }
                       }
                          
                      }
                      
                      return $all_actors;
            } 
            
            
            /**
             *This is the function that generates ddr0011 report  
             */
            public function actiongetDDR0011ReportContent(){
                
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['designation_id'] != ""){
                     $designation_id = $_REQUEST['designation_id'];
                 }else {
                     $designation_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all domain keywords
                 $all_designations = $this->getAllDesignationsFromOtherDomainsConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 if($designation_id == 0){
                     
                    foreach($all_designations as $designationid){
                    $contents = $this->getTheListOfOtherDomainMediaWithThisDesignation($designationid,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                           //"content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfOtherDomainMediaWithThisDesignation($designation_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                          // "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
                
                
            }
            
            
            
            /**
             * This is the function the spools all designations from the other domain programs consumed by this domain 
             */
            public function getAllDesignationsFromOtherDomainsConsumedByThisDomain($domain_id,$start_date,$end_date){
                
                 $all_designations = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='domain_id!=:id';
                      $criteria1->params = array(':id'=>$domain_id);
                      $designations= Designations::model()->findAll($criteria1);
                      
                      foreach($designations as $designation){
                          if($this->isThisDesignationInAProgramConsumedByThisDomain($designation['id'],$domain_id,$start_date,$end_date)){
                             $all_designations[] = $designation['id']; 
                          }
                          
                      }
                
                      return $all_designations;
                
            }
            
            
            /**
             * This is the function that determines if a designation is in a program
             */
            public function isThisDesignationInAProgramConsumedByThisDomain($designation,$domain_id,$start_date,$end_date){
               
                
                 //get all the other domain programs consumed by this domain
                $all_programs = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                
                //on each program, get the corresponding sessions
                $all_sessions = [];
                foreach($all_programs as $media_program_id){
                     //get all the sessions that make up this program
                     $all_sessions[] = $this->getAllSessionsInThisMediaProgram($media_program_id);
                     
                   }
                   //put all the sessions in a one dimensional array and make it unique
                   $dsessions = array_unique($this->makeThisArrayAOneDimensionalArray($all_sessions));
                   //get the slots in each media session
                  $all_slots = [];
                  foreach($dsessions as $session){
                      $all_slots[] = $this->getAllMediaSlotsBelongingToThisSession($session);
               
                  }
                  //put the slot in one dimensional array
                  $dslots = $this->makeThisArrayAOneDimensionalArray($all_slots);
                  $counter = 0;
                  foreach($dslots as $slot){
                      if($this->isMediaSlotWithThisDesignation($slot,$designation)){
                          $counter = $counter + 1;
                      }
                  }
                 if($counter > 0){
                     return true;
                 }else{
                     return false;
                 }
                
            }
            
            
            /**
             * This is the function that determines if a media has a designation
             */
            public function isMediaSlotWithThisDesignation($media_id,$designation_id){
                
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('media_has_keywords')
                    ->where("media_id = $media_id && designation_id =$designation_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
            }
            
      
            
            /**
             * This is the function that spools the list of other domain media with this designation
             */
            public function getTheListOfOtherDomainMediaWithThisDesignation($designation_id,$domain_id,$start_date,$end_date){
                
                    $all_designations= [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='designation_id=:id';
                    $criteria1->params = array(':id'=>$designation_id);
                    $items= MediaHasKeywords::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id) === false){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_designations[] = $item['id'];
                          }
                       }
                          
                      }
                      
                      return $all_designations;
                
            }
            
            
            
            
            
            /**
             * This is the function that generates the ddr0012 report 
             */
            public function actiongetDDR0012ReportContent(){
                
                $user_id = Yii::app()->user->id;
                 
                  $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                 
                 //get the domain of the logged in user
                 $domain_id = $this->determineAUserDomainIdGiven($user_id);
          
                 if(($_REQUEST['start_date']) != ""){
                     $start_date = strtotime($_REQUEST['start_date']);
                 }else{
                     $start_date = strtotime('January 1 1970 00:00:00 UTC');
                 }
                 
                 if(($_REQUEST['end_date']) != ""){
                     $end_date = strtotime($_REQUEST['end_date']);
                 }else{
                     $end_date = $today;
                 }
                 if($_REQUEST['context_id'] != ""){
                     $context_id = $_REQUEST['context_id'];
                 }else {
                     $context_id = 0;
                 }                
                                  
                 $all_contents = [];
                 
                 //get all contexts
                 $all_contexts = $this->getAllContextsFromOtherDomainsMediaConsumedByThisDomain($domain_id,$start_date,$end_date);
                 
                 if($context_id == 0){
                     
                    foreach($all_contexts as $contextid){
                    $contents = $this->getTheListOfOtherDomainMediaWithThisContext($contextid,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }
                    
                }
                    
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                         //  "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }else{
                    
                    $contents = $this->getTheListOfOtherDomainMediaWithThisContext($context_id,$domain_id,$start_date,$end_date);
                    foreach($contents as $content){
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      $criteria1->condition='id=:id';
                      $criteria1->params = array(':id'=>$content);
                      $reports= MediaHasKeywords::model()->find($criteria1);
                      
                      $all_contents[]=$reports;
                 
                   }  
                   
                   if($all_contents===null) {
                        http_response_code(404);
                        $data['error'] ='No record found';
                        echo CJSON::encode($data);
                    } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "report" => $all_contents,
                         //  "content"=>$contents
                           
                       ));
                       
                } 
                     
                 }
                
            }
            
            
            
            /**
             * This is the function that get all context from other domain media consumed by this domain
             */
            public function getAllContextsFromOtherDomainsMediaConsumedByThisDomain($domain_id,$start_date,$end_date){
                
                
                    $all_contexts = [];
                      $criteria1 = new CDbCriteria();
                      $criteria1->select = '*';
                      //$criteria1->condition='domain_id!=:id';
                     // $criteria1->params = array(':id'=>$domain_id);
                      $contexts= Contexts::model()->findAll($criteria1);
                      
                      foreach($contexts as $context){
                          if($this->isThisContextInAProgramConsumedByThisDomain($context['id'],$domain_id,$start_date,$end_date)){
                             $all_contexts[] = $context['id']; 
                          }
                          
                      }
                
                      return $all_contexts;
                
            }
            
            
            /**
             * This is the function that determines if a program is in a context
             */
            public function isThisContextInAProgramConsumedByThisDomain($context,$domain_id,$start_date,$end_date){
                
                 //get all the other domain programs consumed by this domain
                $all_programs = $this->getTheListOfOtherDomainsProgramsAndEventsConsumedByThisDomain($domain_id,$start_date,$end_date);
                
                //on each program, get the corresponding sessions
                $all_sessions = [];
                foreach($all_programs as $media_program_id){
                     //get all the sessions that make up this program
                     $all_sessions[] = $this->getAllSessionsInThisMediaProgram($media_program_id);
                     
                   }
                    //put all the sessions in a one dimensional array and make it unique
                   $dsessions = array_unique($this->makeThisArrayAOneDimensionalArray($all_sessions));
                   //get the slots in each media session
                  $all_slots = [];
                  foreach($dsessions as $session){
                      $all_slots[] = $this->getAllMediaSlotsBelongingToThisSession($session);
               
                  }
                  //put the slot in one dimensional array
                  $dslots = $this->makeThisArrayAOneDimensionalArray($all_slots);
                  $counter = 0;
                  foreach($dslots as $slot){
                      if($this->isMediaSlotWithThisContext($slot,$context)){
                          $counter = $counter + 1;
                      }
                  }
                  if($counter > 0){
                      return true;
                  }else{
                      return false;
                  }
                
            }
            
            
            /**
             * This is the function that confirms the exitence of a media slot in a context
             */
            public function isMediaSlotWithThisContext($media_id,$context_id){
                
                $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('media_has_keywords')
                    ->where("media_id = $media_id && context_id =$context_id");
                $result = $cmd->queryScalar();
                
                if($result >0){
                    return true;
                }else{
                    return false;
                }
            }
          
            
            
            /**
             * This is the function that 
             * 
             */
            public function getTheListOfOtherDomainMediaWithThisContext($context_id,$domain_id,$start_date,$end_date){
                
                    $all_contexts= [];
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = '*';
                    $criteria1->condition='context_id=:id';
                    $criteria1->params = array(':id'=>$context_id);
                    $items= MediaHasKeywords::model()->findAll($criteria1);
                      
                      foreach($items as $item){
                        if($this->isThisDomainTheOwnerOfThisMedia($item['media_id'],$domain_id) === false){
                             if($this->isMediaItemWithinTheDateRange(strtotime($item['create_time']),$start_date,$end_date)){
                              $all_contexts[] = $item['id'];
                          }
                       }
                          
                      }
                      
                      return $all_contexts;
                
            }
            
}





