<?php

class FeedbacksForEnlistmentController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','submittingenlistmentcodefeedbackengagementdesign','submittingenlistmentcodefeedbackdesign','retrievefeedbackdesigninfo',
                                    'submittingmodifiedenlistmentcodefeedbackdesign','submittingmodifiedenlistmentcodefeedbackengagementdesign',
                                    'listAllFeedbackResponsesFromAFeedbackCode','retrieveendomainspecificfeedbackquestions'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	 /**
         * This is the function that submits feedback design for an enlietment code
         */
        public function actionsubmittingenlistmentcodefeedbackdesign(){
            
            $model = new FeedbacksForEnlistment;
            
             if($_REQUEST['maximum_feedback_required'] == "" or $_REQUEST['maximum_feedback_required'] == NULL){
                 $maximum_feedback_required = -1;
             }else{
                  $maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
             }
             $model->code_id = $_REQUEST['code_id'];
             $is_feedback_before_authenticity = $_REQUEST['is_feedback_before_authenticity'];
             if(isset($_REQUEST['is_multiple_feedback_responses_allowed'])){
                 $is_multiple_feedback_responses_allowed = $_REQUEST['is_multiple_feedback_responses_allowed'];
             }else{
                 $is_multiple_feedback_responses_allowed=0;
             }
            
            if($_REQUEST['template'] == 'default'){
                $model->is_default_feedback_comment = 1;
            }else {
                if(isset($_REQUEST['is_product_likes'])){
                    $model->is_product_likes =$_REQUEST['is_product_likes'];
                }else{
                    $model->is_product_likes = 0;
                }
                
                if(isset($_REQUEST['is_product_hates'])){
                    $model->is_product_hates =$_REQUEST['is_product_hates'];
                }else{
                    $model->is_product_hates = 0;
                }
                
                if(isset($_REQUEST['is_was_needs_met'])){
                    $model->is_was_needs_met =$_REQUEST['is_was_needs_met'];
                }else{
                    $model->is_was_needs_met = 0;
                }
                
                if(isset($_REQUEST['is_unfillfulled_needs'])){
                    $model->is_unfillfulled_needs =$_REQUEST['is_unfillfulled_needs'];
                }else{
                    $model->is_unfillfulled_needs = 0;
                }
                
                if(isset($_REQUEST['is_recommendation_to_friends'])){
                    $model->is_recommendation_to_friends =$_REQUEST['is_recommendation_to_friends'];
                }else{
                    $model->is_recommendation_to_friends = 0;
                }
                
                 if(isset($_REQUEST['is_can_get_product_again'])){
                    $model->is_can_get_product_again =$_REQUEST['is_can_get_product_again'];
                }else{
                    $model->is_can_get_product_again = 0;
                }
                
                if(isset($_REQUEST['is_preferred_product_to_this'])){
                    $model->is_preferred_product_to_this =$_REQUEST['is_preferred_product_to_this'];
                }else{
                    $model->is_preferred_product_to_this = 0;
                }
                
                if(isset($_REQUEST['is_your_expected_improvements_in_our_product'])){
                    $model->is_your_expected_improvements_in_our_product =$_REQUEST['is_your_expected_improvements_in_our_product'];
                }else{
                    $model->is_your_expected_improvements_in_our_product = 0;
                }
                
                 $model->is_default_feedback_comment = 0;
            }
            
            if($model->isThisFeedbackAlreadyWithTemplate($model->code_id)==false){
              if($this->isThisEnlistmentProductFeedbackCodeUpdatedsuccessfully($maximum_feedback_required,$model->code_id,$is_feedback_before_authenticity,$is_multiple_feedback_responses_allowed)){
                if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This Enlistment Feedback template is submitted succesfully"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
            }
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to update this enlistment feedback verification code. Please try again or contact customer service for assistance"
                        )); 
            }
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This feedback code already has a feedback response template. You can only modify the existing design",
                                "code_id"=>$model->code_id
                        )); 
            }
            
          
        }
        
        
        /**
         * This is the function that updates an enlistment verification code
         */
        public function isThisEnlistmentProductFeedbackCodeUpdatedsuccessfully($maximum_feedback_required,$code_id,$is_feedback_before_authenticity,$is_multiple_feedback_responses_allowed){
            $model = new EnlistmentVerificationCode;
            return $model->isThisEnlistmentProductFeedbackCodeUpdatedsuccessfully($maximum_feedback_required,$code_id,$is_feedback_before_authenticity,$is_multiple_feedback_responses_allowed);
        }
        
        
        
        /**
         * This is the function that submits enlistment feedback design and engagement limit settings 
         */
        public function actionsubmittingenlistmentcodefeedbackengagementdesign(){
            $model = new FeedbacksForEnlistment;
            
             $maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
             $model->code_id = $_REQUEST['code_id'];
             $is_feedback_before_authenticity = $_REQUEST['is_feedback_before_authenticity'];
             if(isset($_REQUEST['is_multiple_feedback_responses_allowed'])){
                 $is_multiple_feedback_responses_allowed = $_REQUEST['is_multiple_feedback_responses_allowed'];
             }else{
                 $is_multiple_feedback_responses_allowed = 0;
             }
             
             if(isset($_REQUEST['is_multiple_engagement_schedules_allowed'])){
                 $is_multiple_engagement_schedules_allowed = $_REQUEST['is_multiple_engagement_schedules_allowed'];
             }else{
                 $is_multiple_engagement_schedules_allowed= 0;
             }
             if($_REQUEST['maximum_engagement_required'] == "" or $_REQUEST['maximum_engagement_required'] == NULL){
                 $maximum_engagement_required = -1;
             }else{
                  $maximum_engagement_required = $_REQUEST['maximum_engagement_required'];
             }
             
              if($_REQUEST['maximum_feedback_required'] == "" or $_REQUEST['maximum_feedback_required'] == NULL){
                 $maximum_feedback_required = -1;
             }else{
                  $maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
             }
             
            
            if($_REQUEST['template'] == 'default'){
                $model->is_default_feedback_comment = 1;
            }else {
                if(isset($_REQUEST['is_product_likes'])){
                    $model->is_product_likes =$_REQUEST['is_product_likes'];
                }else{
                    $model->is_product_likes = 0;
                }
                
                if(isset($_REQUEST['is_product_hates'])){
                    $model->is_product_hates =$_REQUEST['is_product_hates'];
                }else{
                    $model->is_product_hates = 0;
                }
                
                if(isset($_REQUEST['is_was_needs_met'])){
                    $model->is_was_needs_met =$_REQUEST['is_was_needs_met'];
                }else{
                    $model->is_was_needs_met = 0;
                }
                
                if(isset($_REQUEST['is_unfillfulled_needs'])){
                    $model->is_unfillfulled_needs =$_REQUEST['is_unfillfulled_needs'];
                }else{
                    $model->is_unfillfulled_needs = 0;
                }
                
                if(isset($_REQUEST['is_recommendation_to_friends'])){
                    $model->is_recommendation_to_friends =$_REQUEST['is_recommendation_to_friends'];
                }else{
                    $model->is_recommendation_to_friends = 0;
                }
                
                 if(isset($_REQUEST['is_can_get_product_again'])){
                    $model->is_can_get_product_again =$_REQUEST['is_can_get_product_again'];
                }else{
                    $model->is_can_get_product_again = 0;
                }
                
                if(isset($_REQUEST['is_preferred_product_to_this'])){
                    $model->is_preferred_product_to_this =$_REQUEST['is_preferred_product_to_this'];
                }else{
                    $model->is_preferred_product_to_this = 0;
                }
                
                if(isset($_REQUEST['is_your_expected_improvements_in_our_product'])){
                    $model->is_your_expected_improvements_in_our_product =$_REQUEST['is_your_expected_improvements_in_our_product'];
                }else{
                    $model->is_your_expected_improvements_in_our_product = 0;
                }
                
                 $model->is_default_feedback_comment = 0;
            }
            
            
            if($model->isThisFeedbackAlreadyWithTemplate($model->code_id)== false){
              if($this->isThisEnlistmentProductFeedbackAndEngagementCodeUpdatedsuccessfully($maximum_engagement_required,$maximum_feedback_required,$model->code_id,$is_feedback_before_authenticity,$is_multiple_feedback_responses_allowed,$is_multiple_engagement_schedules_allowed)){
                if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This Enlistment Feedback template is submitted succesfully"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
            }
            }
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This feedback code already has a feedback response template. You can only modify the existing design"
                        )); 
                
            }
            
           
            
        }
        
        
         /**
         * This is the function that updates an enlistment verification code
         */
        public function isThisEnlistmentProductFeedbackAndEngagementCodeUpdatedsuccessfully($maximum_engagement_required,$maximum_feedback_required,$code_id,$is_feedback_before_authenticity,$is_multiple_feedback_responses_allowed,$is_multiple_engagement_schedules_allowed){
            $model = new EnlistmentVerificationCode;
            return $model->isThisEnlistmentProductFeedbackAndEngagementCodeUpdatedsuccessfully($maximum_engagement_required,$maximum_feedback_required,$code_id,$is_feedback_before_authenticity,$is_multiple_feedback_responses_allowed,$is_multiple_engagement_schedules_allowed);
        }
        
        
        /**
         * This is the function that retrieves feedback and engagement design information
         
        public function actionretrievefeedbackdesigninfo(){
            
            $code_id = $_REQUEST['code_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $feedback = FeedbacksForEnlistment::model()->find($criteria);
            
            //get the code info
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $code = EnlistmentVerificationCode::model()->find($criteria);
            
             if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$code,
                                    "feedback"=>$feedback
                                    
                    
                            ));
                       
                         }
        }
         * 
         */
        
        
        /**
         * This is the function that submits a modified feedback template design
         */
        public function actionsubmittingmodifiedenlistmentcodefeedbackdesign(){
          
            $code_id = $_REQUEST['code_id'];
            
            $feedback_id = $this->getTheIdOfThisFeedback($code_id);
            
            if($feedback_id>0){
                $model=  FeedbacksForEnlistment::model()->findByPk($feedback_id);
           
           
                                   
            if($_REQUEST['maximum_feedback_required'] == "" or $_REQUEST['maximum_feedback_required'] == NULL){
                 $maximum_feedback_required = -1;
             }else{
                  $maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
             }
             $model->code_id = $_REQUEST['code_id'];
             $is_feedback_before_authenticity = $_REQUEST['is_feedback_before_authenticity'];
             if(isset($_REQUEST['is_multiple_feedback_responses_allowed'])){
                 $is_multiple_feedback_responses_allowed = $_REQUEST['is_multiple_feedback_responses_allowed'];
             }else{
                 $is_multiple_feedback_responses_allowed=0;
             }
             
             
            
            if($_REQUEST['template'] == 'default'){
                $model->is_default_feedback_comment = 1;
            }else {
                if(isset($_REQUEST['is_product_likes'])){
                    $model->is_product_likes =$_REQUEST['is_product_likes'];
                }else{
                    $model->is_product_likes = 0;
                }
                
                if(isset($_REQUEST['is_product_hates'])){
                    $model->is_product_hates =$_REQUEST['is_product_hates'];
                }else{
                    $model->is_product_hates = 0;
                }
                
                if(isset($_REQUEST['is_was_needs_met'])){
                    $model->is_was_needs_met =$_REQUEST['is_was_needs_met'];
                }else{
                    $model->is_was_needs_met = 0;
                }
                
                if(isset($_REQUEST['is_unfillfulled_needs'])){
                    $model->is_unfillfulled_needs =$_REQUEST['is_unfillfulled_needs'];
                }else{
                    $model->is_unfillfulled_needs = 0;
                }
                
                if(isset($_REQUEST['is_recommendation_to_friends'])){
                    $model->is_recommendation_to_friends =$_REQUEST['is_recommendation_to_friends'];
                }else{
                    $model->is_recommendation_to_friends = 0;
                }
                
                 if(isset($_REQUEST['is_can_get_product_again'])){
                    $model->is_can_get_product_again =$_REQUEST['is_can_get_product_again'];
                }else{
                    $model->is_can_get_product_again = 0;
                }
                
                if(isset($_REQUEST['is_preferred_product_to_this'])){
                    $model->is_preferred_product_to_this =$_REQUEST['is_preferred_product_to_this'];
                }else{
                    $model->is_preferred_product_to_this = 0;
                }
                
                if(isset($_REQUEST['is_your_expected_improvements_in_our_product'])){
                    $model->is_your_expected_improvements_in_our_product =$_REQUEST['is_your_expected_improvements_in_our_product'];
                }else{
                    $model->is_your_expected_improvements_in_our_product = 0;
                }
                //organization specific
                if(isset($_REQUEST['is_atm_not_operational'])){
                    $model->is_atm_not_operational =$_REQUEST['is_atm_not_operational'];
                }else{
                    $model->is_atm_not_operational = 0;
                }
                
                 if(isset($_REQUEST['is_atm_out_of_cash'])){
                    $model->is_atm_out_of_cash =$_REQUEST['is_atm_out_of_cash'];
                }else{
                    $model->is_atm_out_of_cash = 0;
                }
                
                 if(isset($_REQUEST['is_atm_out_of_service'])){
                    $model->is_atm_out_of_service =$_REQUEST['is_atm_out_of_service'];
                }else{
                    $model->is_atm_out_of_service = 0;
                }
                
                if(isset($_REQUEST['is_atm_debiting_but_not_giving_cash'])){
                    $model->is_atm_debiting_but_not_giving_cash =$_REQUEST['is_atm_debiting_but_not_giving_cash'];
                }else{
                    $model->is_atm_debiting_but_not_giving_cash = 0;
                }
                
                if(isset($_REQUEST['is_atm_giving_out_dirty_notes'])){
                    $model->is_atm_giving_out_dirty_notes =$_REQUEST['is_atm_giving_out_dirty_notes'];
                }else{
                    $model->is_atm_giving_out_dirty_notes = 0;
                }
                
                if($_REQUEST['template'] == 'custom'){
                    $model->is_custom_generic_template = 1;
                }else{
                    $model->is_custom_generic_template=0;
                }
                
                 $model->is_default_feedback_comment = 0;
            }
            
         if($this->isThisEnlistmentProductFeedbackCodeUpdatedsuccessfully($maximum_feedback_required,$model->code_id,$is_feedback_before_authenticity,$is_multiple_feedback_responses_allowed)){
                if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This Enlistment feedback template is modified succesfully"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
            }
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue trying to update this enlistment feedback verification code. Please try again or contact customer service for assistance"
                        )); 
            }
                
        
                
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This feedback template could not be modified. Please confirm that the template actually exist",
                               
                        )); 
                
            }
            
           
           
            
        }
        
        
        /**
         * This is the function that gets the id of a feedback enlistment
         */
        public function getTheIdOfThisFeedback($code_id){
            
            $model = new FeedbacksForEnlistment;
            return $model->getTheIdOfThisFeedback($code_id);
        }
        
        
        /**
         * This is the function that submits a modified feedback and engagement template
         */
        public function actionsubmittingmodifiedenlistmentcodefeedbackengagementdesign(){
            $model = new FeedbacksForEnlistment;
            
            $code_id = $_REQUEST['code_id'];
            
             $feedback_id = $this->getTheIdOfThisFeedback($code_id);
            
            if($feedback_id>0){
                $model=  FeedbacksForEnlistment::model()->findByPk($feedback_id);
           
                      
              $maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
             $model->code_id = $_REQUEST['code_id'];
             $is_feedback_before_authenticity = $_REQUEST['is_feedback_before_authenticity'];
             if(isset($_REQUEST['is_multiple_feedback_responses_allowed'])){
                 $is_multiple_feedback_responses_allowed = $_REQUEST['is_multiple_feedback_responses_allowed'];
             }else{
                 $is_multiple_feedback_responses_allowed = 0;
             }
             
             if(isset($_REQUEST['is_multiple_engagement_schedules_allowed'])){
                 $is_multiple_engagement_schedules_allowed = $_REQUEST['is_multiple_engagement_schedules_allowed'];
             }else{
                 $is_multiple_engagement_schedules_allowed= 0;
             }
             
             if($_REQUEST['maximum_engagement_required'] == "" or $_REQUEST['maximum_engagement_required'] == NULL){
                 $maximum_engagement_required = -1;
             }else{
                  $maximum_engagement_required = $_REQUEST['maximum_engagement_required'];
             }
             
              if($_REQUEST['maximum_feedback_required'] == "" or $_REQUEST['maximum_feedback_required'] == NULL){
                 $maximum_feedback_required = -1;
             }else{
                  $maximum_feedback_required = $_REQUEST['maximum_feedback_required'];
             }
             
            
            if($_REQUEST['template'] == 'default'){
                $model->is_default_feedback_comment = 1;
            }else {
                if(isset($_REQUEST['is_product_likes'])){
                    $model->is_product_likes =$_REQUEST['is_product_likes'];
                }else{
                    $model->is_product_likes = 0;
                }
                
                if(isset($_REQUEST['is_product_hates'])){
                    $model->is_product_hates =$_REQUEST['is_product_hates'];
                }else{
                    $model->is_product_hates = 0;
                }
                
                if(isset($_REQUEST['is_was_needs_met'])){
                    $model->is_was_needs_met =$_REQUEST['is_was_needs_met'];
                }else{
                    $model->is_was_needs_met = 0;
                }
                
                if(isset($_REQUEST['is_unfillfulled_needs'])){
                    $model->is_unfillfulled_needs =$_REQUEST['is_unfillfulled_needs'];
                }else{
                    $model->is_unfillfulled_needs = 0;
                }
                
                if(isset($_REQUEST['is_recommendation_to_friends'])){
                    $model->is_recommendation_to_friends =$_REQUEST['is_recommendation_to_friends'];
                }else{
                    $model->is_recommendation_to_friends = 0;
                }
                
                 if(isset($_REQUEST['is_can_get_product_again'])){
                    $model->is_can_get_product_again =$_REQUEST['is_can_get_product_again'];
                }else{
                    $model->is_can_get_product_again = 0;
                }
                
                if(isset($_REQUEST['is_preferred_product_to_this'])){
                    $model->is_preferred_product_to_this =$_REQUEST['is_preferred_product_to_this'];
                }else{
                    $model->is_preferred_product_to_this = 0;
                }
                
                if(isset($_REQUEST['is_your_expected_improvements_in_our_product'])){
                    $model->is_your_expected_improvements_in_our_product =$_REQUEST['is_your_expected_improvements_in_our_product'];
                }else{
                    $model->is_your_expected_improvements_in_our_product = 0;
                }
                
                //organization specific
                if(isset($_REQUEST['is_atm_not_operational'])){
                    $model->is_atm_not_operational =$_REQUEST['is_atm_not_operational'];
                }else{
                    $model->is_atm_not_operational = 0;
                }
                
                 if(isset($_REQUEST['is_atm_out_of_cash'])){
                    $model->is_atm_out_of_cash =$_REQUEST['is_atm_out_of_cash'];
                }else{
                    $model->is_atm_out_of_cash = 0;
                }
                
                 if(isset($_REQUEST['is_atm_out_of_service'])){
                    $model->is_atm_out_of_service =$_REQUEST['is_atm_out_of_service'];
                }else{
                    $model->is_atm_out_of_service = 0;
                }
                
                if(isset($_REQUEST['is_atm_debiting_but_not_giving_cash'])){
                    $model->is_atm_debiting_but_not_giving_cash =$_REQUEST['is_atm_debiting_but_not_giving_cash'];
                }else{
                    $model->is_atm_debiting_but_not_giving_cash = 0;
                }
                
                if(isset($_REQUEST['is_atm_giving_out_dirty_notes'])){
                    $model->is_atm_giving_out_dirty_notes =$_REQUEST['is_atm_giving_out_dirty_notes'];
                }else{
                    $model->is_atm_giving_out_dirty_notes = 0;
                }
                
                if($_REQUEST['template'] == 'custom'){
                    $model->is_custom_generic_template = 1;
                }else{
                    $model->is_custom_generic_template=0;
                }
                
                 $model->is_default_feedback_comment = 0;
            }
            
          if($this->isThisEnlistmentProductFeedbackAndEngagementCodeUpdatedsuccessfully($maximum_engagement_required,$maximum_feedback_required,$model->code_id,$is_feedback_before_authenticity,$is_multiple_feedback_responses_allowed,$is_multiple_engagement_schedules_allowed)){
                if($model->save()){
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"This Enlistment feedback and engagement template is modfied succesfully"
                        ));
                
                
            }else{
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
            }
            }else{
                 header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There was an issue while attempting to modify this feedback and engagement template. Please contact service desl for assistance"
                        )); 
            }
                
           
            }else{
                header('Content-Type: application/json');
                    echo CJSON::encode(array(
                       "success" => mysql_errno() != 0,
                        "msg" => "This template could not be modified. Please confirm that the template actually exist",
                        "code_id" => $model->code_id
            ));
        }   
            
            
        }
        
        
        /**
         * This is the function that confirms if a code is still active
         */
        public function isThisCodeActive($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisCodeActive($code_id);
        }
        
        
        /**
         * This is the function that retrieves all responses of a feedback code
         */
        public function actionlistAllFeedbackResponsesFromAFeedbackCode(){
            $code_id = $_REQUEST['code_id'];
            
            //get the feedbakc template othis code
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $code = FeedbacksForEnlistment::model()->find($criteria);
            
            
            //get all the responses from this feedback template
            //get the feedbakc template othis code
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='feedback_id=:feedid';
            $criteria->params = array(':feedid'=>$code['id']);
            $feedbacks = FeedbacksResponse::model()->findAll($criteria);
            
            if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "feedback" =>$feedbacks
                                                                        
                    
                            ));
                       
                         }
        }
        
        
        
         /**
         * This is the function that retrieves feedback design information that is specific to a domain
         */
    public function actionretrievefeedbackdesigninfo(){
            $model = new FeedbacksForEnlistment;
            
            $user_id = Yii::app()->user->id;
             //get the domain of this user
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            $code_id = $_REQUEST['code_id'];
            
         if($model->isThisFeedbackAlreadyWithTemplate($code_id)== false){
                $model->code_id=$code_id;
                
           if($model->save()){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$model->id);
                    $feedback = FeedbacksForEnlistment::model()->find($criteria);
            
                    //get the code info
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:codeid';
                    $criteria->params = array(':codeid'=>$code_id);
                    $code = EnlistmentVerificationCode::model()->find($criteria);
            
                    if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$code,
                                    "feedback"=>$feedback,
                                    "domain"=>$domain_id
                                    
                    
                            ));
                       
                         }
              
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
                    
                }
                
                
         }else{
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code_id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $feedback = FeedbacksForEnlistment::model()->find($criteria);
            
            //get the code info
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:codeid';
            $criteria->params = array(':codeid'=>$code_id);
            $code = EnlistmentVerificationCode::model()->find($criteria);
            
             if($code_id===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$code,
                                    "feedback"=>$feedback,
                                    "domain"=>$domain_id
                                    
                    
                            ));
                       
                         }
            }
            
            
            
        }
        
        
         /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            $model = new User;
            return $model->determineAUserDomainIdGiven($user_id);
        }
}
