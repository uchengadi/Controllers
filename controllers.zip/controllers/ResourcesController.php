<?php

class ResourcesController extends Controller
{
	
         private $_id;
         private $_name;
        /**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','listallresourceitems','getTheTaskInformation','getToolboxDetailInformation','listsingleresourceitem','ListAllToolsAndTaskInThisPlatform'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('createresourcevideoonlygroup', 'createresourcevideoonlyitem','updateresourcevideoonlygroup','updateresourcevideoonlyitem','createresourceaudioonlygroup',
                                                    'createresourceaudioonlyitem', 'updateresourceaudioonlygroup', 'updateresourceaudioonlyitem', 'createresourcetextonlygroup',
                                                     'updateresourcetextonlygroup','createresourcetextonlyitem', 'updateresourcetextonlyitem','createresourceimageonlygroup','updateresourceimageonlygroup',
                                                    'createresourceimageonlyitem', 'updateresourceimageonlyitem','createresourceappgroup', 'updateresourceappgroup', 'createresourceappsitem', 'updateresourceappitem',
                                                    'createresourcequizgroup', 'updateresourcequizgroup', 'createresourcequizitem', 'updateresourcequizitem', 'createresourcesurveygroup', 'updateresourcesurveygroup',
                                                    'createresourcesurveyitem','updateresourcesurveyitem','createresourcetextannouncementgroup', 'updateresourcetextannouncementgroup',
                                                    'createresourcetextannouncementitem', 'updateresourcetextannouncementitem', 'createresourceimageannouncementgroup', 'updateresourceimageannouncementgroup',
                                                    'createresourceimageannouncementitem', 'updateresourceimageannouncementitem', 'createresourceaudioannouncementgroup', 'updateresourceaudioannouncementgroup',
                                                    'createresourceaudioannouncementitem', 'updateresourceaudioannouncementitem', 'createresourcevideoannouncementgroup', 'updateresourcevideoannouncementgroup',
                                                    'createresourcevideoannouncementitem', 'updateresourcevideoannouncementitem', 'createresourceflashcardtextgroup', 'updateresourceflashcardtextgroup',
                                                    'createresourceflashcardtextitem', 'updateresourceflashcardtextitem','createresourceflashcardimagegroup','updateresourceflashcardimagegroup', 
                                                    'createresourceflashimageitem', 'updateresourceflashcardimageitem', 'createresourceflashcardaudiogroup', 'updateresourceflashcardaudiogroup','createresourceflashcardaudioitem',
                                                    'updateresourceflashcardaudioitem', 'createresourceflashcardvideogroup', 'updateresourceflashcardvideogroup', 'createresourceflashcardvideoitem',
                                                    'updateresourceflashcardvideoitem', 'createresourcemixedvideotextgroup', 'updateresourcemixedvideotextgroup', 'createresourcemixedvideotextitem', 'updateresourcemixedvideotextitem',
                                                    'createresourcemixedvideoimagegroup', 'updateresourcemixedvideoimagegroup', 'createresourcemixedvideoimageitem', 'updateresourcemixedvideoimageitem', 'createresourcemixedaudiotextgroup',
                                                    'updateresourcemixedaudiotextgroup', 'createresourcemixedaudiotextitem', 'updateresourcemixedaudiotextitem', 'createresourcemixedaudioimagegroup', 'updateresourcemixedaudioimagegroup',
                                                     'createresourcemixedaudioimageitem', 'updateresourcemixedaudioimageitem', 'createresourcemixedflashcardimageaudiogroup', 'updateresourcemixedflashcardimageaudiogroup',
                                                    'createresourcemixedflashcardimageaudioitem', 'updateresourcemixedflashcardimageaudioitem', 'createresourcemixflashcardvideoimagegroup', 'updateresourcemixflashcardvideoimagegroup',
                                                    'createresourcemixflashcardvideoimageitem', 'updateresourcemixflashcardvideoimageitem', 'createresourcemixflashcardaudioimagegroup', 'updateresourcemixflashcardaudioimagegroup',
                                                    'createresourcemixflashcardaudioimageitem','updateresourcemixflashcardaudioimageitem', 'createresourcemixeflashcardaudiotextgroup', 'updateresourcemixedflashcardaudiotextgroup',
                                                    'createresourceflashcardaudioitem', 'updateresourceflashcardaudioitem', 'createresourcemixflashcardimagevideogroup', 'updateresourcemixflashcardimagevideogroup',
                                                    'createresourcemixflashcardimagevideoitem', 'updateresourcemixflashcardimagevideoitem', 'createresourcemixflashcardimagetextgroup', 'updateresourcemixflashcardimagetextgroup',
                                                    'createresourcemixflashcardimagetextitem', 'updateresourcemixflashcardimagetextitem', 'createresourcecompositegroup', 'createresourcecompositeitem', 'updateresourcecompositeitem',
                                                    'updateresourcemixedimagetextgroup', 'updateresourcemixedimagetextitem', 'createresourcemixedimagetextitem', 'deleteoneresourcemixedimagetext', 'listallmixedimagetexts',
                                                    'createresourcemixedflashcardaudiotextgroup','createresourcemixedflashcardaudiotextitem', 'updateresourcemixedflashcardaudiotextgroup', 'updateresourcemixedflashcardaudiotextitem',
                                                    'createresourcemixeflashcardvideotextgroup', 'updateresourcemixedflashcardvideotextgroup','createresourcemixedflashcardvideotextitem', 'updateresourcemixedflashcardvideotextitem',
                                                    'createresourcemixeflashcardvideotextgroup', 'ListResourcesForResourcegroupAssigment', 'ListResourceForResourcegroupAssignmentUpdate', 'GetParentName', 'GetAllParentNameForAResourcetype',
                                                    'GetAllParentNameForAResourceVideoOnly', 'GetAllParentNameForAResourceAudioOnly', 'GetAllParentNameForAResourceTextOnly', 'GetAllParentNameForAResourceImageOnly', 'GetAllParentNameForAResourceApp',
                                                    'GetAllParentNameForAResourceQuiz', 'GetAllParentNameForAResourceSurvey', 'GetAllParentNameForAResourceComposite', 'GetAllParentNameForAResourceTextAnnouncement', 'GetAllParentNameForAResourceImageAnnouncement',
                                                    'GetAllParentNameForAResourceAudioAnnouncement', 'GetAllParentNameForAResourceVideoAnnouncement', 'GetAllParentNameForAResourceFlashcardText', 'GetAllParentNameForAResourceFlashcardImage','GetAllParentNameForAResourceFlashcardAudio',
                                                    'GetAllParentNameForAResourceFlashcardVideo', 'GetAllParentNameForAResourceMixedVideoText', 'GetAllParentNameForAResourceMixedVideoImage', 'GetAllParentNameForAResourceMixedAudioText', 'GetAllParentNameForAResourceMixedAudioImage',
                                                    'GetAllParentNameForAResourceMixedImageText', 'GetAllParentNameForAResourceMixedFlashcardImageAudio', 'GetAllParentNameForAResourceMixedFlashcardImageText', 'GetAllParentNameForAResourceMixedFlashcardImageVideo',
                                                    'GetAllParentNameForAResourceMixedFlashcardAudioText', 'GetAllParentNameForAResourceMixedFlashcardAudioImage', 'GetAllParentNameForAResourceMixedFlashcardVideoText', 'GetAllParentNameForAResourceMixedFlashcardVideoImage',
                                                    'UpdateResourceCompositeGroup', 'ListAllResourceItemForThisParentAndResourcetype', 'listallresourceitems', 'resourcedetailiteminfo', 'getresourceidname', 'listallresourceitemgroups', 'ListSingleResourceItem',
                                                    'determineIfAUserHasThisPrivilegeAssined','privilegeType', 'ReturnAllUserPrivileges', 'determineIfAUserHasThisPrivilegeAssigned','retrieveAllRolePrivileges','retrieveAllTaskPrivileges', 'ListAllToolsForThisDomain',
                                                     'ListAllTaskForAllDomain','retrieveAllTheIconMimeTypes','retrieveTheMaximumVideoSize','ListAllCopyableToolsProducedOrConsumedByADomain','justtesting',
                                                    'ListAllTaskForDuplicatedTools','ListAllTaskConsumableByADomain','getTheTaskInformation','getThePreferredCurrencyOfADomain','ListAllToolsAndTaskInThisPlatform',
                                                     'isDemoTypeAndSizeLegal','isVideoTypeAndSizeLegal','getalldomaintoolsbelongingtothisproduct','getTheDomainOfTheLoggedInUser','DownloadThisMedia','DownloadThisMedia',
                                    'destroyeddocuments','expiredbutawaitingdestruction','closetoexpirydocuments','effectExtendedDocumentExpiryDate','verifyExtendedDocumentExpiryDate','effectChangeOfExpiredDocumentExpiryDate',
                                    'confirmChangeOfExpiredDocumentExpiryDate','initiateThisDocumentDestruction','confirmThisDocumentDestruction','checkConfirmedDocumentDestruction','verifyCheckedDocumentDestruction',
                                    'rejectExtendedDocumentExpiryDate','rejectNewExpiryDateForExpiredDocument','rejectDestructionOfThisExpiredDocumentAtDomain','rejectDestructionOfThisExpiredDocumentAtCheckerLevel','rejectDestructionOfThisExpiredDocumentAtPlatformVerifierLevel',
                                    'verifyTheRemovalOfDestroyedDocumentAtPlatformLevel','checkTheRemovalOfDestroyedDocumentAtPlatformLevel','confirmTheRemovalOfDestroyedDocumentAtDomainLevel','removeDestroyedDocumentFromThePlatform','rejectionOfInitiatedRemovalOfDestroyedDocument',
                                    'rejectionOfConfirmedRemovalOfDestroyedDocument','rejectionOfCheckedRemovalOfDestroyedDocument','documentsinbatch','rejectDestructionOfThisExpiredDocumentAtCheckerLevel'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('listallvideosonly','deleteoneresourcevideoonly','listallaudiosonly','deleteoneresourceaudioonly', 'listalltextsonly',
                                                   'deleteoneresourcetextonly', 'listallimagesonly', 'deleteoneresourceimageonly', 'listallapps', 'deleteoneresourceapp',
                                                    'listallquizs','deleteoneresourcequiz', 'listallsurvey', 'deleteoneresourcesurvey','listalltextannouncements','deleteoneresourcetextannouncement',
                                                    'listallimageannouncements', 'deleteoneresourceimageannouncement', 'listallaudioannouncements', 'deleteoneresourceaudioannouncement',
                                                    'listallvideoannouncements', 'deleteoneresourcevideoannouncement', 'listallflashcardtext', 'deleteoneresourceflashcardtext', 'listallcardimages',
                                                    'deleteoneresourceflashcardimage', 'listallcardaudios', 'deleteoneresourceflashcardaudio', 'listallcardvideos', 'deleteoneresourceflashcardvideo',
                                                    'listallmixedvideotext', 'deleteoneresourcemixedvideotext', 'listallmixedvideoimages', 'deleteoneresourcemixedvideoimage', 'listallmixedaudiotext',
                                                    'deleteoneresourcemixedaudiotext', 'listallmixedaudioimages', 'deleteoneresourcemixedaudioimage', 'listallcardimageaudios', 'deleteoneresourcemixedflashcardimageaudio',
                                                    'listallmixedflashcardvideoimages', 'deleteoneresourcemixflashcardvideoimage', 'listallmixedflashcardaudioimages', 'deleteoneresourcemixflashcardaudioimage',
                                                    'listallmixedcardaudiotexts', 'deleteoneresourcemixedflashcardaudiotext', 'listallmixedflashcardimagevideos', 'deleteoneresourcemixflashcardimagevideo',
                                                    'listallmixedflashcardimagetext', 'deleteoneresourcemixflashcardimagetext', 'listallcomposites', 'deleteoneresourcecomposite', 'createresourcemixedimagetextgroup', 'listallmixedimagetexts',
                                                    'deleteoneresourcemixedflashcardaudiotext', 'listallmixedcardaudiotexts', 'listallmixedcardvideotexts', 'deleteoneresourcemixedflashcardvideotext', 'ListResourceForResourcegroupAssignmentUpdate',
                                                    'determineAllToolboxForADomain', 'RetrieveAllToolsInAUserToolboxes','DeleteOneResource','ListToolsAndTaskForThisDomain','ListAllToolsAndToolboxesForADomain'),
				'users'=>array('@'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreateResourceVideoOnlyGroup()
	{
		
             //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the platform base currency
            $base_currency = $this->getThePlatformBaseCurrency();
            
                $model=new Resources;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                //get the id of the logged in user
                $userid = Yii::app()->user->id;
                
                $domainid = $this->determineAUserDomainIdGiven($userid);
		
                //$model->resourcetype_id = $_POST['resourcetype_id'];
                $model->name = $_POST['name'];
                $model->product_id = $_POST['product'];
                $model->domain_id = $domainid;
                if(isset($_POST['description'])){
                    $model->description = $_POST['description'];
                }
                if(isset($_POST['duplicate'])){
                    $model->duplicate = $_POST['duplicate'];
                }
               if(isset($_POST['price'])){
                    if($base_currency == $preferred_currency){
                         $model->price = $_POST['price'];
                    }else{
                        //retrieve the exchange rate of the preferred currency
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $dollar_value = ((double)$_POST['price'])/((double)$exchange_rate);
                        $model->price = $dollar_value;
                    }
                
                }
                if(isset($_POST['discount_rate'])){
                    $model->discount_rate = $_POST['discount_rate'];
                }
                if(isset($_POST['discount_proof'])){
                    $model->discount_proof = $_POST['discount_proof'];
                }
                if(isset($_POST['enforce_equal_share'])){
                    $model->enforce_equal_share = $_POST['enforce_equal_share'];
                }
                if(isset($_POST['reconstruct_tool'])){
                    $model->reconstruct_tool = $_POST['reconstruct_tool'];
                }
                if(isset($_POST['price_preference'])){
                    $model->price_preference = $_POST['price_preference'];
                }
                if(isset($_POST['cumulative_component_price'])){
                    $model->cumulative_component_price = $_POST['cumulative_component_price'];
                }
                 if(isset($_POST['file_number'])){
                    $model->file_number = $_POST['file_number'];
                }
                if(isset($_POST['file_location'])){
                    $model->file_location = $_POST['file_location'];
                }
                if(isset($_POST['file_room_number'])){
                    $model->file_room_number = $_POST['file_room_number'];
                }
                if(isset($_POST['cabinet_shelf_number'])){
                    $model->cabinet_shelf_number = $_POST['cabinet_shelf_number'];
                }
                if(isset($_POST['cabinet_shelf_row_number'])){
                    $model->cabinet_shelf_row_number = $_POST['cabinet_shelf_row_number'];
                }
                if(isset($_POST['cabinet_shelf_column_number'])){
                    $model->cabinet_shelf_column_number = $_POST['cabinet_shelf_column_number'];
                }
                if(isset($_POST['file_position_from_right'])){
                    $model->file_position_from_right = $_POST['file_position_from_right'];
                }
                if(isset($_POST['file_position_from_left'])){
                    $model->file_position_from_left = $_POST['file_position_from_left'];
                }
             /**   if(isset($_POST['document_processed_date'])){
                    $model->document_processed_date = date("Y-m-d H:i:s", strtotime($_POST['document_processed_date']));
                }else{
                   $model->document_processed_date = new CDbExpression('NOW()');
                }
              * 
              */
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                 $icon_error_counter = 0;
               
                //$icon = $_FILES['icon']['name'];
                //$this->createOrUpdateAGroupForResource($model, $icon=null);
                //working with the icon file
                if($_FILES['icon']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal($domainid)){
                        
                       $icon_filename = $_FILES['icon']['name'];
                       $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $this->provideToolIconWhenUnavailable();
                   $icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           $model->icon_size = $icon_size;
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' File was created successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' file was not created successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your icon file type or size as icon must be of width '$platform_width'px and height '$platform_height'px. Icon type is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
	}
        
        
        /**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreateResourceVideoOnlyItem()
	{
		
             //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the platform base currency
            $base_currency = $this->getThePlatformBaseCurrency();
            
            
            $model=new Resources;
                //get the logged in userid
                $userid = Yii::app()->user->id;
                
                $domainid = $this->determineAUserDomainIdGiven($userid);
                
                //obtain the resource maximum level position and increment it
                $_name = $_REQUEST['parent'];
                $criteria = new CDbCriteria();
                $criteria->select = 'id, level, resourcetype_id';
                $criteria->condition='parent_id=:id and resourcetype_id=1';
                $criteria->params = array(':id'=>$_name);
                $level = Resources::model()->findAll($criteria); 
                
                $max_level = [];
                
                //$level_max = (int)max($level->level);
                foreach($level as $value){
                    $max_level[] = $value->level;
                }
                
                if($max_level === []){
                    $level_max = 0; 
                }else {
                  //obtain the maximum value from the array
                   $level_max = (int)max($max_level); 
                    
                }
                
                           

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		$model->domain_id = $domainid;
                $model->resourcetype_id = $_POST['type'];
                $model->name = $_POST['name'];
                $model->product_id = $_POST['product'];
                $model->level = $level_max + 1;
                if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
                }
               if(isset($_POST['parent'])){
                    $model->parent_id = $_POST['parent'];
               }else{
                   $model->parent_id = $_POST['parent_id'];
               }
               if(isset($_POST['text'])){
                   $model->text = $_POST['text'];
               }
                if(isset($_POST['index_html'])){
                   $model->index_html = $_POST['index_html']; 
                }
                if(isset($_POST['demo_file_homepage'])){
                   $model->demo_file_homepage = $_POST['demo_file_homepage']; 
                }
                if(isset($_POST['url'])){
                  $model->url = $_POST['url'];  
                }
                if(isset($_POST['price'])){
                    if($base_currency == $preferred_currency){
                         $model->price = $_POST['price'];
                    }else{
                        //retrieve the exchange rate of the preferred currency
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $dollar_value = ((double)$_POST['price'])/((double)$exchange_rate);
                        $model->price = $dollar_value;
                    }
                
                }
                if(isset($_POST['discount_rate'])){
                    $model->discount_rate = $_POST['discount_rate'];
                }
                if(isset($_POST['discount_proof'])){
                    $model->discount_proof = $_POST['discount_proof'];
                }
                if(isset($_POST['percentage_share'])){
                    if($this->isSpecialMinimumTaskShareSet($domainid)){
                        if($this->isValueLessThanTheMinSpecialPercentageShareForThisDomain($_POST['percentage_share'], $domainid)){
                            $model->percentage_share = $this->determineTheSpecialTaskMinimumShareValue($domainid);
                        }else{
                            $model->percentage_share = $_POST['percentage_share'];
                        }
                        
                    }else{
                        //verify if the given value is less than the domain set min share percentage
                        if($this->isValueLessThanDomainTaskMinPercentageShare($_POST['percentage_share'], $domainid)){
                            $model->percentage_share = $this->determineTaskMinShareForADomain($domainid);
                        }else{
                            $model->percentage_share = $_POST['percentage_share'];
                        }
                    }
                    
                }else{
                   $model->percentage_share = $this->determineTaskMinShareForADomain($domainid);
                }
                if(isset($_POST['respect_task_percentage_share'])){
                    $model->respect_task_percentage_share = $_POST['respect_task_percentage_share'];
                }
                if(isset($_POST['respect_share_but_could_squeeze_in'])){
                    $model->respect_share_but_could_squeeze_in = $_POST['respect_share_but_could_squeeze_in'];
                }else{
                    $model->respect_share_but_could_squeeze_in = 0;
                }
                if(isset($_POST['also_serve_as_preview'])){
                    $model->also_serve_as_preview = $_POST['also_serve_as_preview'];
                }
                if(isset($_POST['downloadable_by_owner_users'])){
                    $model->downloadable_by_owner_users = $_POST['downloadable_by_owner_users'];
                }
                 if(isset($_POST['downloadable_by_non_owner_users'])){
                    $model->downloadable_by_non_owner_users = $_POST['downloadable_by_non_owner_users'];
                }
                if(isset($_POST['document_number'])){
                    $model->document_number = $_POST['document_number'];
                }
                 if(isset($_POST['document_status'])){
                    $model->document_status = strtolower($_POST['document_status']);
                }
                if(isset($_POST['document_expiry_date'])){
                    $model->document_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['document_expiry_date']));
                }
                if(isset($_POST['document_processed_date'])){
                    $model->document_processed_date = date("Y-m-d H:i:s", strtotime($_POST['document_processed_date']));
                }else{
                   $model->document_processed_date = new CDbExpression('NOW()');
                }
                 if(isset($_POST['enforce_validation'])){
                    $model->enforce_validation = $_POST['enforce_validation'];
                }
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                               
                //get the name of the document type
                
                $document_type_name = $this->getTheNameOfThisDocumentType($model->resourcetype_id);
                
               //declare a universal error message variable
               $icon_error_counter = 0;
               $poster_error_counter =0;
               $video_error_counter = 0;//this is used for the document counter as video also represents documents in this context
               $zip_error_counter = 0;
               $html5_error_counter = 0;
                //working with the icon file
                if($_FILES['icon']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal($domainid)){
                        
                       $icon_filename = $_FILES['icon']['name'];
                       $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $this->provideTaskIconWhenUnavailable();
                   $icon_size = 0;
             
                }//end of the if icon is empty statement
                
                //Working with the poster file
                 if($_FILES['poster']['name'] != ""){
                    if($this->isPosterTypeAndSizeLegal($domainid)){
                        
                       $poster_filename = $_FILES['poster']['name'];
                       $poster_size = $_FILES['poster']['size'];
                        
                    }else{
                        $poster_error_counter = $poster_error_counter + 1;
                        
                    }//end of the determine size and type statement
                }else{
                     $poster_filename = $this->provideTaskPosterWhenUnavailable();
                    $poster_size = 0;
                }//end of the if icon is empty statement
                
                //working with the video file
                
                if($_FILES['filename']['name'] != ""){
                    if($this->isDocumentTypeAndSizeLegal($domainid)){
                       $video_filename = $_FILES['filename']['name'];
                       $video_size = $_FILES['filename']['size'];
                       
                    }else{
                          $video_error_counter = $video_error_counter + 1;
                         
                        
                    }//end of the determine size and type statement
                }else{
                   $video_filename = null;
                   $video_size = 0;
                   
                }//end of the if icon is empty statement
                
                //working with the zip/demo file
                
                if($_FILES['zipped_filename']['name'] != ""){
                    if($this->isDemoTypeAndSizeLegal($domainid)){
                        
                         $zipped_filename = $_FILES['zipped_filename']['name'];
                        $demo_size = $_FILES['zipped_filename']['size'];
                      
                    }else{
                         $zip_error_counter = $zip_error_counter + 1;
                        
                        }//end of the determine size and type statement
                }else{
                    $zipped_filename = null;
                    $demo_size = 0;
                }//end of the if icon is empty statement
                
                if($_FILES['html5_demo_file']['name'] != ""){
                    if($this->isHtml5DemoTypeAndSizeLegal($domainid)){
                        
                        $html5_demofile = $_FILES['html5_demo_file']['name'];
                        $handholding_size = $_FILES['html5_demo_file']['size'];
                      
                    }else{
                         $html5_error_counter = $html5_error_counter + 1;
                        
                        }//end of the determine size and type statement
                }else{
                    $html5_demofile = null;
                    $handholding_size = 0;
                }//end of the if icon is empty statement
                
                             
                //Ensure that the files variables all validates
                if(($icon_error_counter ==0 && $poster_error_counter == 0) &&  ($video_error_counter == 0 && $zip_error_counter == 0 && $html5_error_counter ==0) ){
                    
                    if($this->isThereSpaceInThisTool($domainid,$model->parent_id,$model->id,$model->percentage_share)){
                        //determine if this task is squeezable
                        if(isset($_POST['respect_share_but_could_squeeze_in']) || $this->isTaskShareValueAcceptable($model->percentage_share,$model->parent_id,$model->id=null)){
                            if($model->validate()){
                    
                            $model->icon = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                            $model->poster = $this->moveThePosterToItsPathAndReturnThePosterName($model,$poster_filename);
                            $model->filename = $this->moveTheVideoToItsPathAndReturnTheVideoName($model,$video_filename);
                            $zipped_demo_file = $this->moveTheZipFileToItsPathAndReturnTheZipFileName($model,$zipped_filename,$demo_size);
                            $model->zipped_filename = $zipped_demo_file[0];
                            $model->demo_size = $zipped_demo_file[1];
                            $handholding_file_details =  $this->moveTheDemoZipFileToItsPathAndReturnTheZipFileName($model,$html5_demofile,$handholding_size);
                            $model->html5_demo_file = $handholding_file_details[0];
                            $model->handholding_size = $handholding_file_details[1];
                            $model->full_media_filename = $handholding_file_details[2];
                            if($video_size !== NULL){
                                $model->video_size = $video_size;
                            }
                            if($icon_size !== NULL){
                                $model->icon_size = $icon_size;
                            }
                            if($poster_size !== NULL){
                                $model->poster_size = $poster_size;
                            }
                            //confirm if the content of the full document file is the recommended format
                            if($this->isTheContentOfTheFullDocumentFormatAcceptable($model->full_media_filename,$model->resourcetype_id)){
                                 //save the file to the database
                            if($model->save()) {
                        
                                $msg = "'$model->name' document was created successfuly";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                                //delete all the moved files in the directory when validation error is encountered
                               $msg = "Document Format Error: The document format provided in the full content folder is not acceptable for the '$document_type_name' document type";
                               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                                );
                            }
                    
                                
                            }else{
                                //delete all the moved files in the directory when validation error is encountered
                               $msg = 'Validaion Error: Check your file fields for correctness';
                               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg,
                                        "file"=>$model->full_media_filename
                                        )
                                ); 
                                
                            }
                           
                }else{
                    
                    //delete all the moved files in the directory when validation error is encountered
                       $msg = "Validation Error: '$model->name' document was created successfully";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                    
                }
                   
                            
                        }else{
                             $msg = 'Space Constraints: There is no space left in this file. If you must add this document, you need to remove some documents from this file';
                             header('Content-Type: application/json');
                             echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                        }//end of the isset if statement
                             
                    }else{
                       
                        $msg = 'Space Constraints: Remove some documents from this file if you must add this document to the folder';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                        
                        
                    }
                     
              }elseif($icon_error_counter > 0){
                 //get the platform assigned icon width and height
                  $platform_width = $this->getThePlatformSetIconWidth();
                  $platform_height = $this->getThePlatformSeticonHeight();
                  $icon_types = $this->retrieveAllTheIconMimeTypes();
                  $icon_types = json_encode($icon_types);
                    $msg = "Please check your icon file type or size as icon must be of width '$platform_width'px and height '$platform_height'px. Icon type is of types '$icon_types'";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                }else if($poster_error_counter >0){
                    //get the platform settings for this property
                    $platform_width = $this->getThePlatformSetPosterWidth();
                    $platform_height =$this->getThePlatformSetPosterHeight();
                    $poster_types = $this->retrieveAllThePosterMimeTypes();
                    $poster_types =  json_encode($poster_types);
                   $msg = "Please check your poster file type or size as poster must be of width '$platform_width'px and height '$platform_height'px.Poster image is of types '$poster_types'";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                }else if($video_error_counter > 0){
                    //get the platform settings for this property
                    $max_video_size = $this->getTheMaxDocumentSizeForThisDomain($domainid);
                    $video_types = $this->retrieveAllDocumentMimeTypes();
                    $video_types = json_encode($video_types);
                     $msg = "Please check your document file type or size as the maximum allowable file size is '$max_video_size'kb and types must be any of this: '$video_types'kb";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                }elseif($zip_error_counter > 0){
                    //get the platform settings for this property
                    $max_zip_size = $this->getTheMaxZipSizeForThisDomain($domainid);
                    $zip_types = $this->retrieveZippedFileMimeTypes();
                    $zip_types = json_encode($zip_types);
                    $msg = "Please check your zipped file type or size as the maximum allowable file size is '$max_zip_size'kb and types must be any of these: ' $zip_types'kb ";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                }elseif($html5_error_counter > 0){
                    //get the platform settings for this property
                    $max_zip_size = $this->getTheMaxZipSizeForThisDomain($domainid);
                    $zip_types = $this->retrieveZippedFileMimeTypes();
                    $zip_types = json_encode($zip_types);
                    $msg = "Please check your zipped file type or size as the maximum allowable file size is '$max_zip_size'kb and types must be any of these: ' $zip_types'kb ";
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                } 
                
  
	}
        
        
        
        
        /**
         * This is the function that gets the name of a document type
         */
        public function getTheNameOfThisDocumentType($type_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$type_id);
                    $document = Resourcetype::model()->find($criteria); 
                    
                    return  $document['name'];
            
        }
        
        
        /**
         * This is the function that varifies if a provided document format is accepted for a document type
         */
   public function isTheContentOfTheFullDocumentFormatAcceptable($filename,$type_id){
            
            
    if($this->doesThisDocumentTypeAcceptAllFormat($type_id) || $filename === null){
                return true;
            }else{
                //get the file extension
                $extension = strtolower ( substr ($filename, -4));
                if($this->isThisExtensionAcceptableToThisDocumentType($type_id,$extension)){
                    return true;
                }else{
                    return false;
                }
                
            } 
            
            
        }
        
        /**
         * This is the function that determines if a document type accepts all formats
         */
        public function doesThisDocumentTypeAcceptAllFormat($type_id){
            //get the preferred extension for this type
            $extension = $this->getThePreferredExtensionForThisDocumentType($type_id);
            
            if(strtolower($extension) == strtolower('All')){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that determines if a file extension is acceptable to a ducument type
         */
        public function isThisExtensionAcceptableToThisDocumentType($type_id,$extension){
            
            //get the preferred extension of this document type
            $preferred_extension = $this->getThePreferredExtensionForThisDocumentType($type_id);
            
            //add dot to the preferred extension
            //make an array of the four letter document extensions
            $four_letter_extensions = ['json','docx','pptx','xlsx'];
            if(in_array($preferred_extension,$four_letter_extensions)){
                 $preferred_extension = $preferred_extension;
            }else{
                 $preferred_extension = '.'.$preferred_extension;
            }
            
            //ensure that microsoft office documents are well accommodated
            if(strtolower($preferred_extension) == 'doc' && $extension == 'docx' ){
                return true;
            }else if(strtolower($preferred_extension) == 'ppt' && $extension == 'pptx'){
                return true;
            }else if(strtolower($preferred_extension) == 'xls' && $extension == 'xlsx'){
                return true;
            }else if(strtolower($preferred_extension) == $extension){
                return true;
            }else{
                return false;
            }
            
         
        }
        
        
        
        /**
         * This is the function that gets the preferred extension for a document type
         */
        public function getThePreferredExtensionForThisDocumentType($type_id){
            
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='id=:id';
                    $criteria->params = array(':id'=>$type_id);
                    $document = Resourcetype::model()->find($criteria); 
                    
                    return  $document['document_format'];
            
        }

	/**
	 * Updates Resource Video Only resourcetype a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdateResourceVideoOnlyGroup()
	{
		
            
             //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the platform base currency
            $base_currency = $this->getThePlatformBaseCurrency();
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
                //get the logged in user id
                $userid = Yii::app()->user->id;
                
                $domainid = $this->determineAUserDomainIdGiven($userid);
            
                $_id = $_POST['id'];
                $model=Resources::model()->findByPk($_id);
		//$model->resourcetype_id = $_POST['resourcetype_id'];
                $model->name = $_POST['name'];
                if(is_numeric($_POST['product'])){
                   $model->product_id = $_POST['product']; 
                }else{
                    $model->product_id = $_POST['product_id'];
                }
                
                $model->domain_id = $domainid;
                if(isset($_POST['description'])){
                    $model->description = $_POST['description'];
                }
                if(isset($_POST['duplicate'])){
                    $model->duplicate = $_POST['duplicate'];
                }else{
                    $model->duplicate = 0;
                }
                if(isset($_POST['price'])){
                    if($base_currency == $preferred_currency){
                         $model->price = $_POST['price'];
                    }else{
                        //retrieve the exchange rate of the preferred currency
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $dollar_value = ((double)$_POST['price'])/((double)$exchange_rate);
                        $model->price = $dollar_value;
                    }
                
                }
                if(isset($_POST['discount_rate'])){
                    $model->discount_rate = $_POST['discount_rate'];
                }
                if(isset($_POST['discount_proof'])){
                    $model->discount_proof = $_POST['discount_proof'];
                }else{
                    $model->discount_proof = 0;
                }
                if(isset($_POST['enforce_equal_share'])){
                    $model->enforce_equal_share = $_POST['enforce_equal_share'];
                }else{
                    $model->enforce_equal_share = 0;
                }
                if(isset($_POST['reconstruct_tool'])){
                    $model->reconstruct_tool = $_POST['reconstruct_tool'];
                }else{
                    $model->reconstruct_tool = 0;
                }
                if(isset($_POST['price_preference'])){
                    $model->price_preference = $_POST['price_preference'];
                }else{
                    $model->price_preference = 0;
                }
                if(isset($_POST['cumulative_component_price'])){
                    $model->cumulative_component_price = $_POST['cumulative_component_price'];
                }else{
                    $model->cumulative_component_price = 0;
                }
                if(isset($_POST['file_number'])){
                    $model->file_number = $_POST['file_number'];
                }
                if(isset($_POST['file_location'])){
                    $model->file_location = $_POST['file_location'];
                }
                if(isset($_POST['file_room_number'])){
                    $model->file_room_number = $_POST['file_room_number'];
                }
                if(isset($_POST['cabinet_shelf_number'])){
                    $model->cabinet_shelf_number = $_POST['cabinet_shelf_number'];
                }
                if(isset($_POST['cabinet_shelf_row_number'])){
                    $model->cabinet_shelf_row_number = $_POST['cabinet_shelf_row_number'];
                }
                if(isset($_POST['cabinet_shelf_column_number'])){
                    $model->cabinet_shelf_column_number = $_POST['cabinet_shelf_column_number'];
                }
                if(isset($_POST['file_position_from_right'])){
                    $model->file_position_from_right = $_POST['file_position_from_right'];
                }
                if(isset($_POST['file_position_from_left'])){
                    $model->file_position_from_left = $_POST['file_position_from_left'];
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                
                //verify if the value of the poster field in the database
                $criteria = new CDbCriteria();
                $criteria->select = 'id, icon';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$_id);
                $iconname = Resources::model()->find($criteria); 
                
                 $icon_error_counter = 0;          
                //$icon = $_FILES['icon']['name'];
                //$this->createOrUpdateAGroupForResource($model, $icon=null);
                
                if($_FILES['icon']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal($domainid)){
                        
                       $icon_filename = $_FILES['icon']['name'];
                       $icon_size = $_FILES['icon']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    //$model->icon = $this->retrieveThePreviousIconName($_id);
                    $icon_filename = $this->retrieveThePreviousIconName($_id);
                    $icon_size = $this->retrieveThePrreviousIconSize($_id);
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           $model->icon_size = $icon_size;
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name'  file was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' file information was not updated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                        }elseif($icon_error_counter > 0){
                        //get the platform assigned icon width and height
                            $platform_width = $this->getThePlatformSetIconWidth();
                            $platform_height = $this->getThePlatformSeticonHeight();
                            $icon_types = $this->retrieveAllTheIconMimeTypes();
                            $icon_types = json_encode($icon_types);
                            $msg = "Please check your icon file type or size as icon must be of width '$platform_width'px and height '$platform_height'px. Icon type is of types '$icon_types'";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        }
        
	}
        
        
        /**
	 * Updates Resource Video Only resourcetype a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdateResourceVideoOnlyItem()
	{
		
		
                 //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the platform base currency
            $base_currency = $this->getThePlatformBaseCurrency();
                // Uncomment the following line if AJAX validation is needed
		
                //get the logged in user id
                $userid = Yii::app()->user->id;
                
                $domainid = $this->determineAUserDomainIdGiven($userid);
                
                $_id = $_POST['id'];
                $model=Resources::model()->findByPk($_id);
		
               
                if(is_numeric($_POST['type'])){
                   $model->resourcetype_id = $_POST['type'];  
                }else{
                    $model->resourcetype_id = $_POST['resourcetype_id'];
                }
                $model->level = $_POST['level'];
                $model->name = $_POST['name'];
                if(is_numeric($_POST['product'])){
                   $model->product_id = $_POST['product']; 
                }else{
                    $model->product_id = $_POST['product_id'];
                }
                $model->parent_id = $_POST['parent_id'];
                $model->domain_id = $domainid;
                if(isset($_POST['description'])){
                    $model->description = $_POST['description']; 
                }
               if(isset($_REQUEST['parent_id'])){
                    $model->parent_id = $_REQUEST['parent_id'];
               }
               if(isset($_POST['text'])){
                   $model->text = $_POST['text'];
               }
                if(isset($_POST['index_html'])){
                   $model->index_html = $_POST['index_html']; 
                }
                if(isset($_POST['demo_file_homepage'])){
                   $model->demo_file_homepage = $_POST['demo_file_homepage']; 
                }
                if(isset($_POST['url'])){
                  $model->url = $_POST['url'];  
                }
               if(isset($_POST['price'])){
                    if($base_currency == $preferred_currency){
                         $model->price = $_POST['price'];
                    }else{
                        //retrieve the exchange rate of the preferred currency
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $dollar_value = ((double)$_POST['price'])/((double)$exchange_rate);
                        $model->price = $dollar_value;
                    }
                
                }
                if(isset($_POST['discount_rate'])){
                    $model->discount_rate = $_POST['discount_rate'];
                }
                if(isset($_POST['discount_proof'])){
                    $model->discount_proof = $_POST['discount_proof'];
                }else{
                    $model->discount_proof = 0;
                }
                
                 //get the name of the document type
                
                $document_type_name = $this->getTheNameOfThisDocumentType($model->resourcetype_id);
                
                if(isset($_POST['percentage_share'])){
                    if($this->isSpecialMinimumTaskShareSet($domainid)){
                        if($this->isValueLessThanTheMinSpecialPercentageShareForThisDomain($_POST['percentage_share'], $domainid)){
                            $model->percentage_share = $this->determineTheSpecialTaskMinimumShareValue($domainid);
                        }else{
                            $model->percentage_share = $_POST['percentage_share'];
                        }
                        
                    }else{
                        //verify if the given value is less than the domain set min share percentage
                        if($this->isValueLessThanDomainTaskMinPercentageShare($_POST['percentage_share'], $domainid)){
                            $model->percentage_share = $this->determineTaskMinShareForADomain($domainid);
                        }else{
                            $model->percentage_share = $_POST['percentage_share'];
                        }
                    }
                    
                }else{
                   $model->percentage_share = $this->determineTaskMinShareForADomain($domainid);
                }
                if(isset($_POST['respect_task_percentage_share'])){
                    $model->respect_task_percentage_share = $_POST['respect_task_percentage_share'];
                }else{
                     $model->respect_task_percentage_share = 0;
                }
                if(isset($_POST['respect_share_but_could_squeeze_in'])){
                    $model->respect_share_but_could_squeeze_in = $_POST['respect_share_but_could_squeeze_in'];
                }else{
                    $model->respect_share_but_could_squeeze_in = 0;
                }
                if(isset($_POST['also_serve_as_preview'])){
                    $model->also_serve_as_preview = $_POST['also_serve_as_preview'];
                }else{
                    $model->also_serve_as_preview = 0;
                }
                if(isset($_POST['downloadable_by_owner_users'])){
                    $model->downloadable_by_owner_users = $_POST['downloadable_by_owner_users'];
                }else{
                    $model->downloadable_by_owner_users = 0;
                }
                 if(isset($_POST['downloadable_by_non_owner_users'])){
                    $model->downloadable_by_non_owner_users = $_POST['downloadable_by_non_owner_users'];
                }else{
                    $model->downloadable_by_non_owner_users = 0;
                }
                if(isset($_POST['document_number'])){
                    $model->document_number = $_POST['document_number'];
                }
                 if(isset($_POST['document_status'])){
                    $model->document_status = strtolower($_POST['document_status']);
                }
                if(isset($_POST['document_expiry_date'])){
                    $model->document_expiry_date = date("Y-m-d H:i:s", strtotime($_POST['document_expiry_date']));
                }
                if(isset($_POST['document_processed_date'])){
                    $model->document_processed_date = date("Y-m-d H:i:s", strtotime($_POST['document_processed_date']));
                }else{
                   $model->document_processed_date = new CDbExpression('NOW()');
                }
                if(isset($_POST['enforce_validation'])){
                    $model->enforce_validation = $_POST['enforce_validation'];
                }else{
                    $model->enforce_validation = 0;
                }
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                
               
               $icon_error_counter = 0;
               $poster_error_counter =0;
               $video_error_counter = 0;//this also is used to represent the document counter: video=document
               $zip_error_counter = 0;
               $html5_error_counter = 0;
                //working with the icon file
                if($_FILES['icon']['name'] != ""){
                    if($this->isIconTypeAndSizeLegal($domainid)){
                      $icon_filename = $_FILES['icon']['name'];
                      $icon_size = $_FILES['icon']['size'];
                      
                    }else{
                       $icon_error_counter = $icon_error_counter + 1;
                        
                    }//end of the determine size and type statement
                }else{
                    //$model->icon = $this->retrieveThePreviousIconName($_id);
                    $icon_filename = $this->retrieveThePreviousIconName($_id);
                    $icon_size = $this->retrieveThePrreviousIconSize($_id);
                }//end of the if icon is empty statement
                
                //Working with the poster file
                 if($_FILES['poster']['name'] != ""){
                    if($this->isPosterTypeAndSizeLegal($domainid)){
                        
                       $poster_filename = $_FILES['poster']['name'];
                       $poster_size = $_FILES['poster']['size'];
                    }else{
                         $poster_error_counter = $poster_error_counter + 1;
                        
                    }//end of the determine size and type statement
                }else{
                    $poster_filename = $this->retrieveThePreviousPosterName($_id);
                    $poster_size = $this->retrieveThePreviousPosterSize($_id);
                }//end of the if icon is empty statement
                
                //working with the document file; note: video here represents pdf documents
                
                if($_FILES['filename']['name'] != ""){
                    if($this->isDocumentTypeAndSizeLegal($domainid)){
                        
                       $video_filename = $_FILES['filename']['name'];
                       $video_size = $_FILES['filename']['size'];
                        
                    }else{
                         $video_error_counter = $video_error_counter + 1;
                    }//end of the determine size and type statement
                }else{
                    $video_filename = $this->retrieveThePreviousVideoName($_id);
                    $video_size = $this->retrieveThePreviousVideoSize($_id);
                }//end of the if icon is empty statement
                
                //working with the zip/demo file
                
                if($_FILES['zipped_filename']['name'] != ""){
                    if($this->isDemoTypeAndSizeLegal($domainid)){
                        $zipped_filename = $_FILES['zipped_filename']['name'];
                        $demo_size = $_FILES['zipped_filename']['size'];
                       
                    }else{
                         $zip_error_counter = $zip_error_counter + 1;
                        
                    }//end of the determine size and type statement
                }else{
                    $zipped_filename = $this->retrieveThePreviousDemoName($_id);
                    $demo_size = $this->retrieveThePreviousDemoSize($_id);
                }//end of the if icon is empty statement
                
                if($_FILES['html5_demo_file']['name'] != ""){
                    if($this->isHtml5DemoTypeAndSizeLegal($domainid)){
                        $html5_demofile = $_FILES['html5_demo_file']['name'];
                        $handholding_size = $_FILES['html5_demo_file']['size'];
                       
                    }else{
                         $html5_error_counter = $zip_error_counter + 1;
                        
                    }//end of the determine size and type statement
                }else{
                    $html5_demofile = $this->retrieveThePreviousHtml5DemoName($_id);
                    $handholding_size = $this->retrieveThePreviousHtml5DemoSize($_id);
                }//end of the if icon is empty statement
                
               //Ensure that the files variables all validates
                if(($icon_error_counter ==0 && $poster_error_counter==0) &&($video_error_counter == 0 && $zip_error_counter==0 && $html5_error_counter == 0)){
                    
                     if($this->isThereSpaceInThisTool($domainid,$model->parent_id,$model->id,$model->percentage_share)){
                        //determine if this task is squeezable
                        if(isset($_POST['respect_share_but_could_squeeze_in']) || $this->isTaskShareValueAcceptable($model->percentage_share,$model->parent_id,$_id)){
                            if($model->validate()){
                    
                            $model->icon = $this->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                            $model->poster = $this->moveThePosterToItsPathAndReturnThePosterName($model,$poster_filename);
                            $model->filename = $this->moveTheVideoToItsPathAndReturnTheVideoName($model,$video_filename);
                            $zipped_demo_file = $this->moveTheZipFileToItsPathAndReturnTheZipFileName($model,$zipped_filename,$demo_size);
                            $model->zipped_filename = $zipped_demo_file[0];
                            $model->demo_size = $zipped_demo_file[1];
                            $handholding_file_details =  $this->moveTheDemoZipFileToItsPathAndReturnTheZipFileName($model,$html5_demofile,$handholding_size);
                            $model->html5_demo_file = $handholding_file_details[0];
                            $model->handholding_size = $handholding_file_details[1];
                            $model->full_media_filename = $handholding_file_details[2];
                            $model->video_size = $video_size;
                            $model->icon_size = $icon_size;        
                            $model->poster_size = $poster_size;   
                            
                     
                     if($this->isTheContentOfTheFullDocumentFormatAcceptable($model->full_media_filename,$model->resourcetype_id)){
                                 
                                  //save the file to the database
                            if($model->save()) {
                        
                                $msg = "'$model->name' document was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                             //delete all the moved files in the directory when validation error is encountered
                                $msg = 'Validaion Error: Check your file fields for correctness';
                                header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                                );
                            }
                                 
                                 
                             }else{
                                  //delete all the moved files in the directory when validation error is encountered
                                  $msg = "Document Format Error: The document format provided in the full content folder is not acceptable for the '$document_type_name' document type";
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg,
                                        "file"=>$model->full_media_filename)
                                    );
                                 
                                 
                             }    
                           
                    
                }else{
                    
                    //delete all the moved files in the directory when validation error is encountered
                       $msg = "Validation Error: '$model->name' document information update was not successful";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                    
                }
                   
                            
                        }else{
                            
                            $msg = 'Space Constraints: You cannot add to this file or increase the capacity of any file in the folder';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                            
                        }//end of the isset if statement
                             
                    }else{
                       
                        $msg = 'Space Constraints: You cannot add to this file or increase the capacity of any document in the folder';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                        
                        
                    }
                }elseif($icon_error_counter > 0){
                 //get the platform assigned icon width and height
                  $platform_width = $this->getThePlatformSetIconWidth();
                  $platform_height = $this->getThePlatformSeticonHeight();
                  $icon_types = $this->retrieveAllTheIconMimeTypes();
                  $icon_types = json_encode($icon_types);
                    $msg = "Please check your icon file type or size as icon must be of width '$platform_width'px and height '$platform_height'px. Icon type is of types '$icon_types'";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                }else if($poster_error_counter >0){
                    //get the platform settings for this property
                    $platform_width = $this->getThePlatformSetPosterWidth();
                    $platform_height =$this->getThePlatformSetPosterHeight();
                    $poster_types = $this->retrieveAllThePosterMimeTypes();
                    $poster_types =  json_encode($poster_types);
                    $whitespace = "\n";
                    $msg = "Please check your poster file type or size as poster must be of width '$platform_width'px and height '$platform_height'px.Poster image is of types '$poster_types'";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                }else if($video_error_counter > 0){
                    //get the platform settings for this property
                    $max_video_size = $this->getTheMaxDocumentSizeForThisDomain($domainid);
                    $video_types = $this->retrieveAllDocumentMimeTypes();
                    $video_types = json_encode($video_types);
                     $msg = "Please check your document file type or size as the maximum allowable file size is '$max_video_size'kb and types must be any of this: '$video_types'kb";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                }elseif($zip_error_counter > 0){
                    //get the platform settings for this property
                    $max_zip_size = $this->getTheMaxZipSizeForThisDomain($domainid);
                    $zip_types = $this->retrieveZippedFileMimeTypes();
                    $zip_types = json_encode($zip_types);
                    $msg = "Please check your zipped file type or size as the maximum allowable file size is '$max_zip_size'kb and types must be any of these: ' $zip_types'kb ";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                }elseif($html5_error_counter > 0){
                    //get the platform settings for this property
                    $max_zip_size = $this->getTheMaxZipSizeForThisDomain($domainid);
                    $zip_types = $this->retrieveZippedFileMimeTypes();
                    $zip_types = json_encode($zip_types);
                    $msg = "Please check your zipped file type or size as the maximum allowable file size is '$max_zip_size'kb and types must be any of these: ' $zip_types'kb ";
                    header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() != 0,
                             "msg" => $msg)
                       );
                } 
                
                   
          
	}
        
        
        /**
         * This is the function that determines the type and size of icon file
         */
        public function isIconTypeAndSizeLegal($domainid){
            
           $size = []; 
            if(isset($_FILES['icon']['name'])){
                $tmpName = $_FILES['icon']['tmp_name'];
                $iconFileName = $_FILES['icon']['name'];    
                $iconFileType = $_FILES['icon']['type'];
                $iconFileSize = $_FILES['icon']['size'];
            } 
           if (isset($_FILES['icon'])) {
             $filename = $_FILES['icon']['tmp_name'];
             list($width, $height) = getimagesize($filename);
           }
      

           
            $platform_width = $this->getThePlatformSetIconWidth();
            $platform_height = $this->getThePlatformSeticonHeight();
            
            $width = $width;
            $height = $height;
           
            //$size = $width * $height;
           
            $icontypes = $this->retrieveAllTheIconMimeTypes();
            
          
           
            //if(($iconFileType === 'image/png'|| $iconFileType === 'image/jpg' || $iconFileType === 'image/jpeg') && ($iconFileSize = 256 * 256)){
            if((in_array($iconFileType,$icontypes)) && ($platform_width == $width && $platform_height = $height)){
                return true;
               
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that gets the platform icon set width
         */
        public function getThePlatformSetIconWidth(){
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_width'];
        }
        
        
        /**
         * This is the function that gets the platform poster set width
         */
        public function getThePlatformSetPosterWidth(){
            
           $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $poster = PlatformSettings::model()->find($criteria); 
            
            return $poster['poster_width'];
        }
        
        
        /**
         * This is the function that gets the platform height setting
         */
        public function getThePlatformSeticonHeight(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_height'];
        }
        
        
        /**
         * This is the function that gets the platform height setting
         */
        public function getThePlatformSetPosterHeight(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $poster = PlatformSettings::model()->find($criteria); 
            
            return $poster['poster_height'];
        }
        
         /**
         * This is the function that determines the type and size of poster file
         */
        public function isPosterTypeAndSizeLegal($domainid){
          
            if(isset($_FILES['poster']['name'])){
                $tmpName = $_FILES['poster']['tmp_name'];
                $posterFileName = $_FILES['poster']['name'];    
                $posterFileType = $_FILES['poster']['type'];
                $posterFileSize = $_FILES['poster']['size'];
            } 
            //obtain the poster sizes for this domain
           if (isset($_FILES['poster'])) {
             $filename = $_FILES['poster']['tmp_name'];
             list($width, $height) = getimagesize($filename);
           }
            
            $platform_width = $this->getThePlatformSetPosterWidth();
            $platform_height = $this->getThePlatformSetPosterHeight();
            
            $width = $width;
            $height =  $height;
            
           // $max_poster_size = $this->retrieveTheMaxPosterSizeForThisDomain($domainid);
            $postertypes = $this->retrieveAllThePosterMimeTypes();
            
                       
           // if(($posterFileType === 'image/png'|| $posterFileType === 'image/jpg' || $posterFileType === 'image/jpeg') && ($posterFileSize <= 256 * 256 * 2)){
           if(in_array($posterFileType,$postertypes) && ($platform_width==$width && $platform_height==$height)){
                return true;
            }else{
                return false;
            }
            
        }
        
        
         /**
         * This is the function that determines the type and size of th pdf document file;
          * Note: that video here represents the pdf document and must be taking as such
         */
        public function isDocumentTypeAndSizeLegal($domainid){
            
            $videotypes = [];
            if(isset($_FILES['filename']['name'])){
                $tmpName = $_FILES['filename']['tmp_name'];
                $videoFileName = $_FILES['filename']['name'];    
                $videoType = $_FILES['filename']['type'];
                $videoFileSize = $_FILES['filename']['size'];
            } 
            //obtain the maximum video size for this domain
           //confirm if domain has its special video size set
            if($this->isSpecialMaxVideoSizeProvided($domainid)){
                $size = $this->determineTheSpecialVideoMaxSizeForThisDomain($domainid);
            }else{
               $size = $this->retrieveTheMaximumVideoSize(); 
            }
        
             $videotypes = $this->retrieveAllDocumentMimeTypes();
            
            //$size = 1024 * 1024 * 10 ;
           
         //if(($videoType === 'video/mp4' && $videoFileSize <= $size)){
             if((in_array($videoType,$videotypes) && $videoFileSize <= $size)){    
                return true;
            }else{
                return false;
            }
         
         
        }
        
        
         /**
         * This is the function that determines the type and size of th zip file
         */
        public function isDemoTypeAndSizeLegal($domainid){
           
         $ziptypes = []; 
            if(isset($_FILES['zipped_filename']['name'])){
                        $tmpName = $_FILES['zipped_filename']['tmp_name'];
                        $zipFileName = $_FILES['zipped_filename']['name'];    
                        $zipFileType = $_FILES['zipped_filename']['type'];
                        $zipFileSize = $_FILES['zipped_filename']['size'];
                  
            }
            //obtain the maximum demo sizes for this domain
           if($this->isSpecialMaxZipSizeProvided($domainid)){
               $size = $this->determineTheSpecialZipMaxSizeForThisDomain($domainid);
           }else{
               $size = $this->retrieveTheMaximumDemoSize();
           }
       
            $ziptypes = $this->retrieveZippedFileMimeTypes();
            
            //$size = 1024 * 1024 * 10;
           
          // if(($zipFileType === 'application/zip'|| $zipFileType === 'application/x-zip-compressed' || $zipFileType === 'multipart/x-zip' || $zipFileType === 'application/x-compressed') && $zipFileSize <= $size){
        if(in_array($zipFileType,$ziptypes) && $zipFileSize <= $size){ 
                return true;
            }else{
                return false;
            }
       
        }
        
        
        /**
         * This is the function that determines the type and size of th zip file
         */
        public function isHtml5DemoTypeAndSizeLegal($domainid){
            
           $ziptypes = []; 
            if(isset($_FILES['html5_demo_file']['name'])){
                        $tmpName = $_FILES['html5_demo_file']['tmp_name'];
                        $zipFileName = $_FILES['html5_demo_file']['name'];    
                        $zipFileType = $_FILES['html5_demo_file']['type'];
                        $zipFileSize = $_FILES['html5_demo_file']['size'];
                  
            }
            //obtain the maximum demo sizes for this domain
          if($this->isSpecialMaxZipSizeProvided($domainid)){
               $size = $this->determineTheSpecialZipMaxSizeForThisDomain($domainid);
           }else{
               $size = $this->retrieveTheMaximumDemoSize();
           }
            
            $ziptypes = $this->retrieveZippedFileMimeTypes();
            
            //$size = 1024 * 1024 * 10;
           
           //if(($zipFileType === 'application/zip'|| $zipFileType === 'application/x-zip-compressed' || $zipFileType === 'multipart/x-zip' || $zipFileType === 'application/x-compressed') && $zipFileSize <= $size){
           if(in_array($zipFileType,$ziptypes) && $zipFileSize <= $size){ 
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that gets the maximum video=document size permitted to a domain
         */
        public function getTheMaxDocumentSizeForThisDomain($domainid){
            
            if($this->isSpecialMaxVideoSizeProvided($domainid)){
                $size = $this->determineTheSpecialVideoMaxSizeForThisDomain($domainid);
            }else{
               $size = $this->retrieveTheMaximumVideoSize(); 
            }
            
            return $size;
        }
        
        
        /**
         * This is the function that gets the maximum zip size permitted to a domain
         */
        public function getTheMaxZipSizeForThisDomain($domainid){
            
            if($this->isSpecialMaxZipSizeProvided($domainid)){
               $size = $this->determineTheSpecialZipMaxSizeForThisDomain($domainid);
           }else{
               $size = $this->retrieveTheMaximumDemoSize();
           }
           
           return $size;
        }
        
        
        
        /**
         * This is the function that retrieves the previous icon of the task in question
         */
        public function retrieveThePreviousIconName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Resources::model()->find($criteria);
            
            
            return $icon['icon'];
            
            
        }
        
        /**
         * This is the function that retrieves the previous icon size
         */
        public function retrieveThePrreviousIconSize($id){
           
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $icon = Resources::model()->find($criteria);
            
            
            return $icon['icon_size'];
        }
        
        
         /**
         * This is the function that retrieves the previous poster of the task in question
         */
        public function retrieveThePreviousPosterName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $poster = Resources::model()->find($criteria);
            
            
            return $poster['poster'];
            
            
            
        }
        
        /**
         * This is the function that returns the previous poster size
         */
        public function retrieveThePreviousPosterSize($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $poster = Resources::model()->find($criteria);
            
            
            return $poster['poster_size'];
            
        }
        
        
         /**
         * This is the function that retrieves the previous video file name of the task in question
         */
        public function retrieveThePreviousVideoName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $video = Resources::model()->find($criteria);
            
            
            return $video['filename'];
            
            
            
        }
        
        /**
         * This is the function that retrieves the previous video size
         */
        public function retrieveThePreviousVideoSize($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $video = Resources::model()->find($criteria);
            
            
            return $video['video_size'];
            
        }
        
        
        
         /**
         * This is the function that retrieves the previous zipped file name of the task in question
         */
        public function retrieveThePreviousDemoName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $zip = Resources::model()->find($criteria);
            
            
            return $zip['zipped_filename'];
              
        }
        
        /**
         * This is the function that retrieves the previous zipped file name of the task in question
         */
        public function retrieveThePreviousDemoSize($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $zip = Resources::model()->find($criteria);
            
            
            return $zip['demo_size'];
              
        }
        
        
        
        
        /**
         * This is the function that retrieves the previous demo zipped file size of the task in question
         */
        public function retrieveThePreviousHtml5DemoName($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $zip = Resources::model()->find($criteria);
            
            
            return $zip['html5_demo_file'];
              
        }
        
        
        /**
         * This is the function that retrieves the previous handholding zipped file size of the task in question
         */
        public function retrieveThePreviousHtml5DemoSize($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$id);
            $zip = Resources::model()->find($criteria);
            
            
            return $zip['handholding_size'];
              
        }
        
        /**
         * This is the function that moves icons to its directory
         */
        public function moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename){
            
            if(isset($_FILES['icon']['name'])){
                        $tmpName = $_FILES['icon']['tmp_name'];
                        $iconName = $_FILES['icon']['name'];    
                        $iconType = $_FILES['icon']['type'];
                        $iconSize = $_FILES['icon']['size'];
                  
                   }
                    
                    if($iconName !== null) {
                        if($model->id === null){
                          //$iconFileName = time().'_'.$icon_filename; 
                          if($icon_filename != 'general_unavailable.png'){
                                $iconFileName = time().'_'.$icon_filename;  
                            }else{
                                $iconFileName = $icon_filename;  
                            }    
                          
                           // upload the icon file
                        if($iconName !== null){
                            	$iconPath = Yii::app()->params['icons'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconFileName;
                        }else{
                            $iconFileName = $icon_filename;
                            return $iconFileName;
                        } // validate to save file
                        }else{
                            if($this->noNewIconFileProvided($model->id,$icon_filename)){
                                $iconFileName = $icon_filename; 
                                return $iconFileName;
                            }else{
                            if($icon_filename != 'general_unavailable.png'){
                                if($this->removeTheExistingIconFile($model->id)){
                                 $iconFileName = time().'_'.$icon_filename; 
                                 //$iconFileName = time().$icon_filename;  
                                   $iconPath = Yii::app()->params['icons'].$iconFileName;
                                   move_uploaded_file($tmpName,$iconPath);
                                   return $iconFileName;
                                    
                                   // $iconFileName = time().'_'.$icon_filename;  
                                    
                             }
                            }
                                
                                
                            }
                            
                            //$iconFileName = $icon_filename; 
                                              
                            
                        }
                      
                     }else{
                         $iconFileName = $icon_filename;
                         return $iconFileName;
                     }
					
                       
                               
        }
        
        
        
        /**
         * This is the function that moves poster files to its directory
         */
        public function moveThePosterToItsPathAndReturnThePosterName($model,$poster_filename){
            
            if(isset($_FILES['poster']['name'])){
                        $tmpName = $_FILES['poster']['tmp_name'];
                        $posterName = $_FILES['poster']['name'];    
                        $posterType = $_FILES['poster']['type'];
                        $posterSize = $_FILES['poster']['size'];
                  
                    }
                    
                    if( $posterName !== null) {
                      if($model->id === null){
                          //$posterFileName = time().'_'.$poster_filename;
                          if($poster_filename != 'poster_general_unavailable.png'){
                                $posterFileName = time().'_'.$poster_filename;  
                            }else{
                                $posterFileName= $poster_filename;  
                            }
                          
                           // upload the poster file
                        if( $posterName !== null){
                            	$posterPath = Yii::app()->params['posters'].$posterFileName;
				move_uploaded_file($tmpName,  $posterPath);
                                        
                        
                                return $posterFileName;
                        }else{
                            
                            return $poster_filename;
                            
                            
                        } // validate to save file
                      }else{
                          if($this->noNewPosterFileProvided($model->id,$poster_filename)){
                                $posterFileName = $poster_filename;
                                return $posterFileName;
                            }else{
                              if($poster_filename != 'poster_general_unavailable.png'){
                                  if($this->removeTheExistingPosterFile($model->id)){
                                 
                                     $posterFileName = time().'_'.$poster_filename;
                                     $posterPath = Yii::app()->params['posters'].$posterFileName;
                                     move_uploaded_file($tmpName,  $posterPath);
                                     return $posterFileName;
                               }
                              }
                                
                                
                                
                               //return $poster_filename;
                            }
                       
                      }
                        
                     }else{
                         $posterFileName = $poster_filename;
                          return $posterFileName;
                     }
					
                       
                               
        }
        
        
         /**
         * This is the function that moves video files to its directory
         */
        public function moveTheVideoToItsPathAndReturnTheVideoName($model,$video_filename){
            
           // $zipFileDetails = [];
            
            if(isset($_FILES['filename']['name'])){
                        $tmpName = $_FILES['filename']['tmp_name'];
                        //$videoName = $_FILES['filename']['name'];    
                        $videoType = $_FILES['filename']['type'];
                        $videoSize = $_FILES['filename']['size'];
                  
                    }
                    
                    if($video_filename !== null) {
                        if($model->id === null){
                            $videoFileName = time().'_'.$video_filename;
                             // upload the video file
                        if($video_filename !== null){
                           // validate to save file
                               	$videoPath = Yii::app()->params['videos'].$videoFileName;
				move_uploaded_file($tmpName,  $videoPath);
                                        
                        
                                return $videoFileName; 
                        }else{
                            return null;
                        } 
                        }else{
                            if($this->noNewVideoFileProvided($model->id,$video_filename)){
                                $videoFileName = $video_filename;
                                return $videoFileName;
                            }else{
                             if($video_filename !== null){
                                  if($this->removedThisExistingVideoFile($model->id)){
                               
                                //move the new file to the disk
                                    $videoFileName = time().'_'.$video_filename;
                                    $videoPath = Yii::app()->params['videos'].$videoFileName;
                                    move_uploaded_file($tmpName,  $videoPath);
                                    return $videoFileName; 
                              }
                                
                             }
                               
                                
                               
                            } 
                            
                            
                        }
                      
                     }else{
                         return null;
                     }
					
                       
        }
        
        
        /**
         * This is the function that gets an existing video file from the disk
         */
        public function getTheExistingVideoFilename($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $file= Resources::model()->find($criteria);
                
                return $file['filename'];
            
        }
        
        
         /**
         * This is the function that gets an existing poster filename from the disk
         */
        public function getTheExistingPosterFilename($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $file= Resources::model()->find($criteria);
                
                return $file['poster'];
            
        }
        
        
        /**
         * This is the function that moves video files to its directory
         */
        public function moveTheZipFileToItsPathAndReturnTheZipFileName($model,$zipFileName,$zipFileSize){
            
            if(isset($_FILES['zipped_filename']['name'])){
                        $tmpName = $_FILES['zipped_filename']['tmp_name'];
                        //$zipFileName = $_FILES['zipped_filename']['name'];    
                        $zipFileType = $_FILES['zipped_filename']['type'];
                        //$zipFileSize = $_FILES['zipped_filename']['size'];
                  
                    }
                    
                   if($zipFileName !== null) {
                       if($model->id === null){
                            $zipped_FileName= time().'_'.$zipFileName;
                            $name = explode(".",$zipped_FileName);
                            //$model->zipped_filename = $name[0];
                            
                             if($zipFileName !== null) {// validate to save file
                                        $zip_filePath = Yii::app()->params['demoFile'].$zipped_FileName;
                                        $zipHtml = Yii::app()->params['demoFile'];
                                         //$newDir = $zipHtml.
                                         $filenoext = basename ($zipped_FileName, '.zip'); 
                                        $filenoext = basename ($filenoext, '.ZIP');  
                                        $myDir = $zipHtml . $filenoext; 
                                        // $myDir = time().'_'.$myDir_1;
                                        mkdir($myDir, 0777);
                                        if(move_uploaded_file($tmpName,  $zip_filePath)){
                                        //extract the zip file to a folder
                                            $zip = new ZipArchive();
                                            $open = $zip->open($zip_filePath); // open the zip file to extract
                                            if ($open === true) {
                                                 $zip->extractTo($myDir); // place in the directory with same name
                                                 //get the unzipped directory size
                                                 $name[1] = $this->getThisDirectorySize($myDir);
                                                 //$name[2] =$this->getTheNameOfTheFullMediaFileInThisDirectory($myDir);
                                                 $zip->close();
                                                    unlink($zip_filePath);
                                                
                                             }
                                            
                                        }
                      
                                 return $name;
                      
                             }else {
                                return null;
                            }
                       }else{
                         if($this->noNewZippedFileProvided($model->id,$zipFileName)){
                               $name[0]= $zipFileName;
                               $name[1] = $zipFileSize;
                                // $name = explode(".",$zipped_FileName);
                                return $name;
                           }else{
                          if($zipFileName !== null){
                               
                              if($this->removeTheExistingDemoDirectory($model->id)) {
                              
                                    $zipped_FileName= time().'_'.$zipFileName;
                                    $name = explode(".",$zipped_FileName);
                                    //$name[1] = $zipFileSize;
                                //move the zipped file
                                $zip_filePath = Yii::app()->params['demoFile'].$zipped_FileName;
                                        $zipHtml = Yii::app()->params['demoFile'];
                                         //$newDir = $zipHtml.
                                         $filenoext = basename ($zipped_FileName, '.zip'); 
                                        $filenoext = basename ($filenoext, '.ZIP');  
                                        $myDir = $zipHtml . $filenoext; 
                                        // $myDir = time().'_'.$myDir_1;
                                        mkdir($myDir, 0777);
                                      
                                          
                                          if(move_uploaded_file($tmpName,  $zip_filePath)){
                                        //extract the zip file to a folder
                                            $zip = new ZipArchive();
                                            $open = $zip->open($zip_filePath); // open the zip file to extract
                                            if ($open === true) {
                                                 $zip->extractTo($myDir); // place in the directory with same name
                                                 //get the unzipped directory size
                                                 $name[1] = $this->getThisDirectorySize($myDir);
                                                // $name[2] =$this->getTheNameOfTheFullMediaFileInThisDirectory($myDir);
                                                 $zip->close();
                                                    unlink($zip_filePath);
                                                
                                             }
                                            
                                        }
                                          
                                    } 
                                    return $name;
                          }
                               
                                        
                                //return $name[0];
                                return null;
                               // }  
                               
                           }
                           
                       }
                       
                     
                    }else{
                        return null;
                    }
					
					
                      
        }
        
        
       
        /**
         * This is the function that moves a demo zipped file to its path
         */
        public function moveTheDemoZipFileToItsPathAndReturnTheZipFileName($model,$zipFileName,$zipFileSize){
            
             if(isset($_FILES['html5_demo_file']['name'])){
                        $tmpName = $_FILES['html5_demo_file']['tmp_name'];
                        //$zipFileName = $_FILES['zipped_filename']['name'];    
                        $zipFileType = $_FILES['html5_demo_file']['type'];
                        //$zipFileSize = $_FILES['html5_demo_file']['size'];
                  
                    }
                    
                   if($zipFileName !== null) {
                       if($model->id === null){
                            $zipped_FileName= time().'_'.$zipFileName;
                            $name = explode(".",$zipped_FileName);
                            //$model->zipped_filename = $name[0];
                             //$name[1] = $zipFileSize;
                            
                             if($zipFileName !== null) {// validate to save file
                                        $zip_filePath = Yii::app()->params['zipHtml'].$zipped_FileName;
                                        $zipHtml = Yii::app()->params['zipHtml'];
                                         //$newDir = $zipHtml.
                                         $filenoext = basename ($zipped_FileName, '.zip'); 
                                        $filenoext = basename ($filenoext, '.ZIP');  
                                        $myDir = $zipHtml . $filenoext; 
                                        // $myDir = time().'_'.$myDir_1;
                                        mkdir($myDir, 0777);
                                        if(move_uploaded_file($tmpName,  $zip_filePath)){
                                        //extract the zip file to a folder
                                            $zip = new ZipArchive();
                                            $open = $zip->open($zip_filePath); // open the zip file to extract
                                            if ($open === true) {
                                                 $zip->extractTo($myDir); // place in the directory with same name
                                                 //get the unzipped directory size
                                                 $name[1] = $this->getThisDirectorySize($myDir);
                                                 $name[2] =$this->getTheNameOfTheFullMediaFileInThisDirectory($myDir);
                                                 $zip->close();
                                                    unlink($zip_filePath);
                                                
                                             }
                                            
                                        }
                      
                                 //return $name[0];
                                 return $name;       
                      
                             }else {
                                return null;
                            }
                       }else{
                         if($this->noNewDemoZippedFileProvided($model->id,$zipFileName)){
                               $name[0]= $zipFileName;
                               $name[1] = $zipFileSize;
                               $name[2] = $model->full_media_filename;
                                // $name = explode(".",$zipped_FileName);
                                return $name;
                           }else{
                            if($zipFileName !== null){
                                 if($this->removeThisExistingHandholdingFolder($model->id)){
                              
                                    $zipped_FileName= time().'_'.$zipFileName;
                                    $name = explode(".",$zipped_FileName);
                                    $name[1] = $zipFileSize;
                                //move the zipped file
                                $zip_filePath = Yii::app()->params['zipHtml'].$zipped_FileName;
                                        $zipHtml = Yii::app()->params['zipHtml'];
                                         //$newDir = $zipHtml.
                                         $filenoext = basename ($zipped_FileName, '.zip'); 
                                        $filenoext = basename ($filenoext, '.ZIP');  
                                        $myDir = $zipHtml . $filenoext; 
                                        // $myDir = time().'_'.$myDir_1;
                                        mkdir($myDir, 0777);
                                        
                                             if(move_uploaded_file($tmpName,  $zip_filePath)){
                                        //extract the zip file to a folder
                                            $zip = new ZipArchive();
                                            $open = $zip->open($zip_filePath); // open the zip file to extract
                                            if ($open === true) {
                                                 $zip->extractTo($myDir); // place in the directory with same name
                                                 //get the unzipped directory size
                                                 $name[1] = $this->getThisDirectorySize($myDir);
                                                 $name[2] =$this->getTheNameOfTheFullMediaFileInThisDirectory($myDir);
                                                 $zip->close();
                                                    unlink($zip_filePath);
                                                
                                             }
                                            
                                        }
                                      }
                                      return $name;
                                }
                              
                                       
                                return null ;
                               // }  
                               
                           }
                           
                       }
                       
                     
                    }else{
                        return null;
                    }
            
        }
        
        /**
         * This is the function that deletes the existing zip file before a new one is created
         */
        public function removeTheExistingDemoDirectory($id){
            
            
            if($this->isTheFullVideoZippedNullValue($id) === false){
                //retreve the existing zip file from the database
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $zip= Resources::model()->find($criteria);
                $filePath = "c:\\xampp\\htdocs\document_client\\complementary\\";
                //$directoryPath = Yii::app()->params['zipHtml'].$zip['zipped_filename'];
                $directoryPath = $filePath.$zip['zipped_filename'];
                
                if($this->deleteDir($directoryPath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
            
                
        }
        
        
         /**
         * This is the function that deletes the existing zip file before a new one is created
         */
        public function removeThisExistingHandholdingFolder($id){
            
            if($this->isHandHoldingFileANullValue($id) === false){
                 //retreve the existing zip file from the database
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $html5= Resources::model()->find($criteria);
                
                $filePath = "c:\\xampp\\htdocs\\document_client\\fullfiles\\";
                $directoryPath = $filePath.$html5['html5_demo_file'];
                if($this->deleteDir($directoryPath)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return true;
            }
           
                
        }
        
        
        /**
         * This is the function that determines if a handholding file value is null
         */
        public function isHandHoldingFileANullValue($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $zip= Resources::model()->find($criteria);
                
                if($zip['html5_demo_file'] === null){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that determines if the full zipped media file has a null value
         */
        public function isTheFullVideoZippedNullValue($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $zip= Resources::model()->find($criteria);
                
                if($zip['zipped_filename'] === null){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * Recursively delete a directory and files in a directory tree
         */
       public static function deleteDir($dirPath) {
           if (! is_dir($dirPath)) {
                throw new InvalidArgumentException("$dirPath must be a directory");
           }
           if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
                $dirPath .= '/';
            }
            $files = glob($dirPath . '*', GLOB_MARK);
            foreach ($files as $file) {
            if (is_dir($file)) {
                self::deleteDir($file);
            } else {
                unlink($file);
         }
            }
            //rmdir($dirPath);
            
            if(rmdir($dirPath)){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that will retrieve the media filename from the directory
         */
        public function getTheNameOfTheFullMediaFileInThisDirectory($dir){
            
            if (is_dir($dir)){
                
                if ($handle = opendir($dir)) {

                    while (false !== ($entry = readdir($handle))) {

                        if ($entry != "." && $entry != "..") {

                            $file = $entry;
                        }
                     }

                 closedir($handle);
                }
            } 
            return $file;
        }
        
        
        
        
        /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingPosterFile($id){
            
            if($this->isThePosterTheDefault($id)=== false){
                
                //retreve the existing zip file from the database
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $poster= Resources::model()->find($criteria);
                
               // $directoryPath =  dirname(Yii::app()->request->scriptFile);
                $directoryPath = "c:\\xampp\htdocs\appspace_assets\\posters\\";
                //$posterpath = '..\appspace_assets\posters'.$poster['poster'];
               $filepath =  $directoryPath.$poster['poster'];
               // $filepath = $directoryPath.$posterpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
            
            
            
        }
        
         /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isThePosterTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Resources::model()->find($criteria);
                
                if($icon['poster'] == 'poster_general_unavailable.png' || $icon['poster'] ===NULL){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that removes an existing video file
         */
        public function removeTheExistingIconFile($id){
            
            if($this->isTheIconTheDefault($id)=== false){
                
                //retreve the existing zip file from the database
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Resources::model()->find($criteria);
                
                //$directoryPath =  dirname(Yii::app()->request->scriptFile);
               $directoryPath = "c:\\xampp\htdocs\appspace_assets\\icons\\";
               // $iconpath = '..\appspace_assets\icons'.$icon['icon'];
                $filepath =$directoryPath.$icon['icon'];
                //$filepath = $directoryPath.$iconpath;
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
            
            
            
        }
        
        /**
         * This is the function that determines if  a tooltype icon is the default
         */
        public function isTheIconTheDefault($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Resources::model()->find($criteria);
                
                if($icon['icon'] == 'general_unavailable.png' || $icon['icon'] ===NULL){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that removes an existing video file
         */
        public function removedThisExistingVideoFile($id){
            
           if($this->isThisTheCurrentDemoVideoFileNull($id) === false){
               //retreve the existing zip file from the database
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $video= Resources::model()->find($criteria);
                
                //$directoryPath = dirname(Yii::app()->request->scriptFile);
                $directoryPath = "c:\\xampp\htdocs\appspace_assets\\documents\\";
                //$videopath = '..\appspace_assets\videos'.$video['filename'];
               
                $filepath = $directoryPath.$video['filename'];
                        
                
                //$filepath = Yii::app()->params['videos'].$video['filename'];
                
                if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
               
           }else{
               return true;
           }
            
            
            
        }
        
        
        /**
         * This is the function that deterines if a current video file is null
         */
        public function isThisTheCurrentDemoVideoFileNull($id){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, filename';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $filename= Resources::model()->find($criteria);
                
                if($filename['filename']=== null){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        /**
         * This is the function to ascertain if a new icon was provided or not
         */
        public function noNewIconFileProvided($id,$icon_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, icon';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $icon= Resources::model()->find($criteria);
                
                if($icon['icon']==$icon_filename){
                    return true;
                }else{
                    return false;
                }
            
        }

        
        /**
         * This is the function to ascertain if a new poster was provided or not
         */
        public function noNewPosterFileProvided($id,$poster_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, poster';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $poster= Resources::model()->find($criteria);
                
                if($poster['poster']==$poster_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function to ascertain if a new video was provided or not
         */
        public function noNewVideoFileProvided($id,$video_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, filename';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $video= Resources::model()->find($criteria);
                
                if($video['filename']==$video_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        
        /**
         * This is the function to ascertain if a new zipped was provided or not
         */
        public function noNewZippedFileProvided($id,$zipped_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, zipped_filename';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $zipped= Resources::model()->find($criteria);
                
                if($zipped['zipped_filename']==$zipped_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function to ascertain if a new zipped was provided or not
         */
        public function noNewDemoZippedFileProvided($id,$zipped_filename){
            
                $criteria = new CDbCriteria();
                $criteria->select = 'id, html5_demo_file';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $zipped= Resources::model()->find($criteria);
                
                if($zipped['html5_demo_file']==$zipped_filename){
                    return true;
                }else{
                    return false;
                }
            
        }
	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDeleteOneResource()
	{
            $_id = $_POST['id'];
            
          //  if(($this->removeTheExistingPosterFile($_id) && $this->removeTheExistingIconFile($_id)) && ($this->removedThisExistingVideoFile($_id) && $this->removedTheExistingZippedFile($_id))){
                
                $model=Resources::model()->findByPk($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = 'The data was successfully deleted';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
                
           /** }else {
                $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            }
            * 
            */
            
            
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Resources');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionListToolsAndTaskForThisDomain_old()
	{
		
            $resourcetype_id = $_REQUEST['resourcetype_id'];
            $userid = Yii::app()->user->id;   
                if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformResourceAdmin")){  
		$criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='resourcetype_id=:typeid';   
                $criteria->params = array(':typeid'=>$resourcetype_id);
                $resource = Resources::model()->findAll($criteria);
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "data" => $resource)
                       );
                       
                }

        }elseif($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainResourceAdmin")){
                //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:typeid';   
                $criteria5->params = array(':typeid'=>$resourcetype_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and resourcetype_id=:typeid';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':typeid'=>$resourcetype_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and resourcetype_id=:typeid';
                    $criteria13->params = array(':id'=>$resid, ':typeid'=>$resourcetype_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "data" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
            
	

        } else{
                $criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and resourcetype_id=:typeid';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid,':typeid'=>$resourcetype_id);
                 $resource= Resources::model()->findAll($criteria14); 
		
         if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "data" => $resource)
                       );
                       
                }




}
	}


        
        /**
	 * Manages all models.
	 */
	public function actionListToolsAndTaskForThisDomain()
	{
		
            //get the logged in user
            $userid = Yii::app()->user->id;
            
            //get the domain id of this user
            
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            //$resourcetype_id = $_REQUEST['resourcetype_id'];
           
                if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformResourcesAdmin")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformResourceSupport")){  
		$criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='resourcetype_id=:typeid';   
               // $criteria->params = array(':typeid'=>$resourcetype_id);
                $resource = Resources::model()->findAll($criteria);
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "data" => $resource
                               )
                       );
                       
                }

        }else{
            
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                $criteria1->condition='domain_id=:id';   
                $criteria1->params = array(':id'=>$domain_id);
                $resource = Resources::model()->findAll($criteria1);
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "data" => $resource)
                       );
                       
                }
        }
	}
        
             
        /**
          * listing all the items needed for the resource to resourcegroup 
         * assignment update
          */
         public function actionListResourceForResourcegroupAssignmentUpdate()
	{
		
           // $_id = $_REQUEST['resourcegroup_id'];
            
            $criteria = new CDbCriteria();
             $criteria->select = 'id, name,select_value';
             $result = Resources::model()->findAll($criteria);   
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'resource_id, resourcegroup_id';
             //$criteria2->condition=
              //$criteria2->params = 
             $selected = ResourceHasResourcegroups::model()->findAll($criteria2);
               
                if($result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "selected" => $selected,
                            "data" => $result)
                       );
                       
                }
	}
        
        
        
         /**
          * Get the name of the parent of the resource item 
         * 
          */
         public function actionGetParentName()
	{
	
           
            //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the prefferred currency code
            
            $currency_code = $this->getThisCurrencyCode($preferred_currency); 
            
            $base_currency = $this->getThePlatformBaseCurrency();
            
            $resource_id = $_REQUEST['id'];
            
            
            
            if($base_currency == $preferred_currency){
                //get the toolbox price
                $price = $this->getTheToolOrTaskPrice($resource_id);
            }else{
                //retrieve the exchange rate of the preferred currency
                        $dprice = $this->getTheToolOrTaskPrice($resource_id);
                        $exchange_rate = $this->getThePreferredCurrencyExchangeRate($preferred_currency,$base_currency);
                        //divide the value by the exchange rate to get the dollar value
                        $new_value = ((double)$dprice) * ((double)$exchange_rate);
                        $price = $new_value;
            }
             
           $_id = $_REQUEST['parent_id'];
           $productid = $_REQUEST['product_id'];
           $type = $_REQUEST['type'];
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$_id);
            $resource = Resources::model()->findAll($criteria);   
            
            
            //get the product name
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$productid);
            $product = Products::model()->findAll($criteria);  
            
            //get the document type
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$type);
            $doctype = Resourcetype::model()->find($criteria);            
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource,
                           "product"=>$product,
                           "currency_code"=>$currency_code,
                           "price"=>$price,
                           "type"=>$doctype['name']
                               
                               )
                       );
                       
                }
	}
        
        
        /**
         * This is the function that fetches the tool or task price
         */
        public function getTheToolOrTaskPrice($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $resource = Resources::model()->find($criteria); 
            
            return $resource['price'];
            
            
        }
        
        /**
          * Get the name of the parent of the video only resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceVideoOnly()
	{
		
          //$_id = $_REQUEST['resourcetype_id'];
          $product_id = $_REQUEST['product_id'];
            // $_id = 1;
           
	$userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
         /**
          * Get the name of the parent of the audio only resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceAudioOnly()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 2;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        
        /**
          * Get the name of the parent of the text only resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceTextOnly()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 3;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        /**
          * Get the name of the parent of the image only resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceImageOnly()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 4;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        /**
          * Get the name of the parent of the app only resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceApp()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 5;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
         /**
          * Get the name of the parent of the quiz only resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceQuiz()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 6;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
         /**
          * Get the name of the parent of the survey only resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceSurvey()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 7;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        /**
          * Get the name of the parent of the composite only resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceComposite()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 8;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
         /**
          * Get the name of the parent of the text announcement resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceTextAnnouncement()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 9;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        /**
          * Get the name of the parent of the image announcement resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceImageAnnouncement()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 10;
           
            $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        /**
          * Get the name of the parent of the audio announcement resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceAudioAnnouncement()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 11;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
         /**
          * Get the name of the parent of the video announcement resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceVideoAnnouncement()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 12;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
         /**
          * Get the name of the parent of the text flashcard resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceFlashcardText()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 13;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        /**
          * Get the name of the parent of the image flashcard resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceFlashcardImage()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 14;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        
        /**
          * Get the name of the parent of the audio flashcard resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceFlashcardAudio()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 15;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        
        /**
          * Get the name of the parent of the video flashcard resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceFlashcardVideo()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 16;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        /**
          * Get the name of the parent of the mixed video & text  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedVideoText()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 17;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
         /**
          * Get the name of the parent of the mixed video & image  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedVideoImage()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 18;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        /**
          * Get the name of the parent of the mixed audio & text  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedAudioText()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 19;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        /**
          * Get the name of the parent of the mixed audio & image  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedAudioImage()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 20;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
         /**
          * Get the name of the parent of the mixed image & text  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedImageText()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 21;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
         /**
          * Get the name of the parent of the mixed flashcard image & audio  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedFlashcardImageAudio()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 22;
           $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
         
        
        /**
          * Get the name of the parent of the mixed flashcard image & audio  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedFlashcardImageText()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 27;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        
        /**
          * Get the name of the parent of the mixed flashcard image & video  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedFlashcardImageVideo()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 26;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
         /**
          * Get the name of the parent of the mixed flashcard audio & text  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedFlashcardAudioText()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 25;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        
          /**
          * Get the name of the parent of the mixed flashcard audio & image  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedFlashcardAudioImage()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 24;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
          /**
          * Get the name of the parent of the mixed flashcard video & text  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedFlashcardVideoText()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = 28;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
          /**
          * Get the name of the parent of the mixed flashcard video & image  resources item 
         * 
          */
         public function actionGetAllParentNameForAResourceMixedFlashcardVideoImage()
	{
		
           $_id = $_REQUEST['resourcetype_id'];
           //  $_id = 23;
           
             $userid = Yii::app()->user->id;   
	if(Yii::app()->user->checkAccess('platformAdmin')||Yii::app()->user->checkAccess('platformResourcesAdmin')){  
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id';
             $criteria->condition='resourcetype_id=:id AND parent_id is null';
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	 }elseif(Yii::app()->user->checkAccess('domainAdmin')||Yii::app()->user->checkAccess('domainResourcesAdmin')){
		 //determine the logged-in user usertype
                $criteria3 = new CDbCriteria();
                $criteria3->select = 'id, usertype_id';
                $criteria3->condition='id=:id';
                $criteria3->params = array(':id'=>$userid);
                $user= User::model()->find($criteria3);
                
                //determine the id and name  of the usertype/user domain
                $criteria4 = new CDbCriteria();
                $criteria4->select = 'id, name';
                $criteria4->condition='id=:id';
                $criteria4->params = array(':id'=>$user->usertype_id);
                $usertypeid= UserType::model()->find($criteria4);
              
                //obtain all the users that created or updated a resource
                $criteria5 = new CDbCriteria();
                $criteria5->select = 'id, name, create_user_id, update_user_id';
                $criteria5->condition='resourcetype_id=:id AND parent_id is null';   
                $criteria5->params = array(':id'=>$_id);
                $domainresource= Resources::model()->findAll($criteria5);
                
                //create array to hold the users that created or updated  resources in the system
                
                $group_users = [];
                $result = [];
                
                foreach($domainresource as $usergroup) {
                    
                     //obtain the usertype of the user that created or updated the resourcegroup
                    
                    $criteria6 = new CDbCriteria();
                    $criteria6->select = 'id, usertype_id';
                    $criteria6->condition='id=:id OR id=:userid';
                    $criteria6->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id);
                    $usertypes= User::model()->find($criteria6);
                    
                    if($usertypeid->id === $usertypes->usertype_id){
                        //determine if the user is already in the array
                            if(!(in_array($usergroup->create_user_id, $group_users))||(!(in_array($usergroup->update_user_id, $group_users))) ){
                            //if(!(in_array($usergroup->create_user_id, $group_users)) ){    
                                        $criteria7 = new CDbCriteria();
                                        $criteria7->select = '*';
                                        $criteria7->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid AND parent_id is null)';
                                        $criteria7->params = array(':id'=>$usergroup->create_user_id, ':userid'=>$usergroup->update_user_id, ':resid'=>$_id);
                                        $allgroups= Resources::model()->findAll($criteria7);
                            
                           
                                        $result = array_merge($result, $allgroups);
                                        if($usergroup->create_user_id !== null){
                                            $group_users[] = $usergroup->create_user_id;
                                            
                                        }
                                       if($usergroup->update_user_id !== null){
                                            $group_users[] = $usergroup->update_user_id;
                                            
                                        } 
                                         
                                       
                        
                        
                            }
                        
                        
                    }
                    
                     
                     
                    
                    
                    
                }
                
                //obtain all the resourcegroup id spool,
                $allres = [];
                foreach($result as $res){
                    $allres[] = $res->id;
                    
                }
                
                //make the array unique and spool from resources table
                 $resourceid = array_unique($allres, $sort_flags=SORT_NUMERIC);
                $domain_result = [];
                 foreach($resourceid as $resid){
                    $criteria13 = new CDbCriteria();
                    $criteria13->select = '*';
                    $criteria13->condition='id=:id and (resourcetype_id=:resid AND parent_id is null)';
                    $criteria13->params = array(':id'=>$resid, ':resid'=>$_id);
                    $result2= Resources::model()->findAll($criteria13);
                    
                    $domain_result = array_merge($domain_result, $result2);
                     
                     
                 }
                
                if($domain_result===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "resource" => $domain_result
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
			
			
        }else{
		$criteria14 = new CDbCriteria();
                $criteria14->select = '*';
                $criteria14->condition='(create_user_id=:id OR update_user_id=:userid) and (resourcetype_id=:resid and parent_id is null)';
                $criteria14->params = array(':id'=>$userid, ':userid'=>$userid, ':resid'=>$_id);
                $resource= Resources::model()->findAll($criteria14); 
		
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }

			
			
			
	}		
       }
        
        
        
         /**
          * Get the name of the parent of the mixed flashcard video & image  resources item 
         * 
          */
         public function actionListAllResourceItemForThisParentAndResourcetype()
	{
		
           //$_id = $_REQUEST['resourcetype_id'];
             $_id = $_REQUEST['parent_id'];
             $type = $_REQUEST['resourcetype_id'];
           
             $criteria = new CDbCriteria();
             $criteria->select = 'id, name, resourcetype_id, level, parent_id, description';
             $criteria->condition='resourcetype_id=:type AND parent_id=:parent';
             $criteria->params = array(':type'=>$type, ':parent'=>$_id);
             $resource = Resources::model()->findAll($criteria);   
             
                           
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "resource" => $resource)
                       );
                       
                }
	}
        
        
        
        
        /**
	 * Manages all text-announcement resource models.
	 */
	public function actionListAllResourceItems()
	{
           
              if(isset($_REQUEST['id'])){
                  $resource_id = $_REQUEST['id'];  
              }else{
                  $resource_id="";
              }
              if(isset($_REQUEST['name'])){
                  
                  $name = $_REQUEST['name'];
                  $search_string = $_REQUEST['name'];
                  $string = preg_replace('/\s/', '', $search_string);
                  $searchWords = explode('+',$string);
              }else{
                  $search_string = "";
              }   
                  
              if($resource_id !=="" &&  $search_string === ""){
                  
                   if($this->isThisToolADuplicate($resource_id)){
                   $tasks = $this->getAllTaskInThisTool($resource_id);
                   
                   $resources = [];
                   foreach($tasks as $task){
                       $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='id=:task';  
                        $criteria->params = array(':task'=>$task);
                        $alltasks = Resources::model()->find($criteria);
                       $resources[] = $alltasks;
                   }
                   
                   
               }else{
                   $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='parent_id=:resourceId';  
                    $criteria->params = array(':resourceId'=>$resource_id);
                    $resources = Resources::model()->findAll($criteria);
               }
              }else if($resource_id !=="" &&  $search_string !== ""){
                $searchable_items = [];
                foreach($searchWords as $word){
                   $q = "SELECT id FROM resources where parent_id=$resource_id and name REGEXP '$word'" ;
                    $cmd = Yii::app()->db->createCommand($q);
                    $results = $cmd->query();
                    foreach($results as $result){
                       
                           $searchable_items[] = $result['id'];
                        
                        
                    } 
                    
                }
                 
                $resources = [];
                foreach($searchable_items as $item){
                    $criteria3 = new CDbCriteria();
                    $criteria3->select = '*';
                    $criteria3->condition='id=:id';
                    $criteria3->params = array(':id'=>$item);
                    $tasks= Resources::model()->find($criteria3);
                    $resources[] = $tasks;
                }
                  
              }   
                  
          
                if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resources" => $resources)
                       );
                       
                }
	}
        
        
        
        /**
         * This is the function that retrieves task/resource items from duplicate tools
         */
        public function isThisToolADuplicate($task_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';  
                $criteria->params = array(':id'=>$task_id);
                $resources = Resources::model()->find($criteria);
                
                if($resources['is_duplicate']==1){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that gets all tasks in a duplicate toolbox
         */
        public function getAllTaskInThisTool($tool_id){
                    $criteria = new CDbCriteria();
                    $criteria->select = '*';
                    $criteria->condition='tool_id=:resourceId';  
                    $criteria->params = array(':resourceId'=>$tool_id);
                    $resources = DuplicateToolHasTask::model()->findAll($criteria);
                    
                    $all_tasks = [];
                    foreach($resources as $tool){
                         $all_tasks[] = $tool['task_id'];
                    }
                    return $all_tasks;
        }
        
        /**
	 * Select just one resource item.
	 */
	public function actionListSingleResourceItem()
	{
              $_id = $_REQUEST['id'];  
               //$_id = 4;  
               // $resource_id = 16;
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';  
                $criteria->params = array(':id'=>$_id);
                $resources = Resources::model()->findAll($criteria);
               
                if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resources" => $resources)
                       );
                       
                }
	}
        
        
        /**
          * Get all the information about a particular resource item 
         * 
          */
         public function actionResourceDetailItemInfo()
	{
		
            $_id = $_REQUEST['id'];
            $group_id = $_REQUEST['group_id'];
            
           
            //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $user_domain = $this->determineAUserDomainIdGiven($user_id);
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';  
             $criteria->params = array(':id'=>$_id);
             $resource = Resources::model()->find($criteria);  
             
                          
             //retrieve the task parent tool
             $criteria6 = new CDbCriteria();
             $criteria6->select = '*';
             $criteria6->condition='id=:id';  
             $criteria6->params = array(':id'=>$resource['parent_id']);
             $parent = Resources::model()->find($criteria6);   
             
             //get the product name
             $criteria4 = new CDbCriteria();
             $criteria4->select = '*';
             $criteria4->condition='id=:id';  
             $criteria4->params = array(':id'=>$resource['product_id']);
             $product = Products::model()->find($criteria4);   
             
             //get the domain owner's name
             $criteria5 = new CDbCriteria();
             $criteria5->select = '*';
             $criteria5->condition='id=:id';  
             $criteria5->params = array(':id'=>$resource['domain_id']);
             $owner = ResourcegroupCategory::model()->find($criteria5);  
             
             $criteria2 = new CDbCriteria();
             $criteria2->select = 'id, name';
             $criteria2->condition='id=:id';  
             $criteria2->params = array(':id'=>$resource->resourcetype_id);
             $resourcetype = ResourceType::model()->find($criteria2);
             
             $criteria3 = new CDbCriteria();
             $criteria3->select = 'resource_id, resourcegroup_id,start_date, end_date, min_date, max_date, excluded_days';
             $criteria3->condition='resource_id=:id and resourcegroup_id=:groupId';  
             $criteria3->params = array(':id'=>$resource->parent_id, ':groupId'=>$group_id);
             $scheduled_info = ResourceHasResourcegroups::model()->find($criteria3); 
             
             $on_schedule = $this->isThisResourceOnScheduled($scheduled_info['end_date']);
             
             //get the preview media type
             $preview_document_type = $this->getThePreviewDocumentTypeOfThisDocument($resource['filename']);
             
             //get the full media type of this media
             $full_document_type = $this->getTheFullDocumentTypeOfThisDocument($resource['full_media_filename']);
             
                            
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "resourcetype" => $resourcetype,
                           "resource" => $resource,
                            "scheduled_info" => $scheduled_info,
                           "product"=>$product['name'],
                           "owner"=>$owner['name'],
                           "parent"=>$parent['name'],
                           "user_domain"=>$user_domain,
                           "onSchedule"=>$on_schedule,
                           "preview_media_type"=>$preview_document_type,
                           "full_media_type"=>$full_document_type,
                          
                          )
                       );
                       
                }
	}
        
        
        
        /**
         * 
         * This is the function that gets the preview media type
         */
        public function getThePreviewMediaTypeOfThisMedia($media_type){
            
            //get the extension of this file
            $extension = strtolower ( substr ($media_type, -4));

            //get all the platform enable video media extension
            $video_extensions = $this->getAllPlatformEnabledVideoExtensions();
            
            //get all the platform enables audio extensions
           $audio_extensions = $this->getAllPlatformEnabledAudioExtensions();
            
            //confirm the appropriate media type for this preview media
            if(in_array($extension, $video_extensions )){
                return "video";
            }else if (in_array($extension, $audio_extensions )){
                return "audio";
            }else{
                return null;
            }
            
            
        }
        
        
        
         /**
         * 
         * This is the function that gets the preview media type
         */
        public function getThePreviewDocumentTypeOfThisDocument($document_type){
            
            //get the extension of this file
            $extension = strtolower ( substr ($document_type, -4));

            //get all the platform enable video media extension
            $document_extensions = $this->getAllPlatformEnabledVideoExtensions();
            
            //get all the platform enables audio extensions
           // $audio_extensions = $this->getAllPlatformEnabledAudioExtensions();
            
            //confirm the appropriate media type for this preview media
            if(in_array($extension, $document_extensions )){
                return "document";
            }else{
                return null;
            }
            
            
        }
        
        /**
         * This is the function that gets the full media type
         */
        public function getTheFullMediaTypeOfThisMedia($media_type){
            
            //get the extension of this file
            $extension = strtolower ( substr ($media_type, -4));
            
             //get all the platform enable video media extension
            $video_extensions = $this->getAllPlatformEnabledVideoExtensions();
            
            //get all the platform enables audio extensions
           $audio_extensions = $this->getAllPlatformEnabledAudioExtensions();
            
            //confirm the appropriate media type for this full media
            if(in_array($extension, $video_extensions )){
                return "video";
            }else if(in_array(in_array($extension, $audio_extensions ))){
                return "audio";
            }else{
                return null;
            }
            
        }
        
        
        /**
         * This is the function that gets the full media type
         */
        public function getTheFullDocumentTypeOfThisDocument($document_type){
            
            //get the extension of this file
            $extension = strtolower ( substr ($document_type, -4));
            
             //get all the platform enable video media extension
            $document_extensions = $this->getAllPlatformEnabledDocumentExtensions();
            
            //get all the platform enables audio extensions
           // $audio_extensions = $this->getAllPlatformEnabledAudioExtensions();
            
            //confirm the appropriate media type for this full media
            if(in_array($extension, $document_extensions )){
                return "document";
            }else{
                return null;
            }
            
        }
        
        /**
         * This is the function that gets all the document enabled extensions on the platform
         */
        public function getAllPlatformEnabledVideoExtensions(){
            //get all the currently enabled video extensions
            $current_video_extensions = $this->getAllCurrentDocumentExtensions();
            
            return $current_video_extensions;
            
        }
        
        /**
         * This is the function that gets all the document enabled extensions on the platform
         */
        public function getAllPlatformEnabledDocumentExtensions(){
            //get all the currently enabled video extensions
            $current_video_extensions = $this->getAllCurrentDocumentExtensions();
            
            return $current_video_extensions;
            
        }
        
        /**
         * This is the function that gets all the video enabled extensions on the platform
         */
        public function getAllPlatformEnabledAudioExtensions(){
            //get all the currently enabled audio extensions
            $current_audio_extensions = $this->getAllCurrentAudioExtensions();
            
            return $current_audio_extensions;
            
        }
        
        
        /**
         * This is the function that gets all currently enabled video extensions
         */
        public function getAllCurrentDocumentExtensions(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
            //$criteria->params = array(':id'=>$domain_id);
            $video= PlatformSettings::model()->find($criteria);
            
            //explode this field and convert to an array
            $video_extensions = explode(',',$video['document_mime_type']);
            
            $enabled_extension = [];
            
            foreach($video_extensions as $ext){
                if($ext == 'application/pdf'){
                    array_push($enabled_extension,".pdf");
                }else if($ext == 'application/xml'){
                    array_push($enabled_extension,".xml");
                }else if($ext == 'application/json'){
                    array_push($enabled_extension,".json");
                }else if($ext == 'text/csv'){
                    array_push($enabled_extension,".csv");
                }else if($ext == 'text/plain'){
                    array_push($enabled_extension,".txt");
                }else if($ext == 'application/msword' || $ext=='application/vnd.openxmlformats-officedocument.wordprocessingml.document'){
                    array_push($enabled_extension,".doc");
                }else if($ext == 'application/vnd.ms-powerpoint' || $ext == 'application/vnd.openxmlformats-officedocument.presentationml.presentation'){
                    array_push($enabled_extension,".ppt");
                }else if($ext == 'application/vnd.ms-excel' || $ext == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'){
                    array_push($enabled_extension,".xls");
                }
                
            }
            
            return $enabled_extension;
            
        }
        
        
        /**
         * This is the function that gets all the audio file extensions as enabled on the platform
         */
        public function getAllCurrentAudioExtensions(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
            //$criteria->params = array(':id'=>$domain_id);
            $video= PlatformSettings::model()->find($criteria);
            
            //explode this field and convert to an array
            $audio_extensions = explode(',',$video['video_mime_type']);
            
            $enabled_extension = [];
            
            foreach($audio_extensions as $ext){
                if($ext == 'audio/mp3'){
                    array_push($enabled_extension,".mp3");
                }else if($ext == 'audio/wav'){
                    array_push($enabled_extension,".wav");
                }else if($ext == 'audio/ogg'){
                    array_push($enabled_extension,".ogg");
                }
                
            }
            
            return $enabled_extension;
            
        }
        
        /**
         * This is the function that determines if a resource is on schedule
         */
        public function isThisResourceOnScheduled($end_date){
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            $end_date = getdate(strtotime($end_date));
            
            $day = $today['mday'];
            $month = $today['mon'];
            $year = $today['year'];
            if(($end_date['year'] - $year <= 0) and (($end_date['mon'] - $month)<=0 and $end_date['mday']-$day<=0)){
                    return false;
             }else{
                    return true;
              }
            
            
        }
        
        /**
         * This is the function that gets the domain of the logged in user
         */
        public function actiongetTheDomainOfTheLoggedInUser(){
            
            $userid = Yii::app()->user->id;
            
            $user_domain = $this->determineAUserDomainIdGiven($userid);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "domainid" => $user_domain)
                       );
            
        }
        
        
        
        
        
        /**
         * This is the function that determines if a task is on schedule in a tool
         */
        public function isTaskOnSchedule($today, $end_date){
            
            
            
        }
        
        
         /**
	 * Manages all text-announcement resource models.
	 */
	public function actionGetResourceIdName()
	{
               $resource_id = $_REQUEST['id'];  
               //$resource_id = 16;
                
                $criteria = new CDbCriteria();
                $criteria->select = 'id, name';
                $criteria->condition='id=:resourceId';  
                $criteria->params = array(':resourceId'=>$resource_id);
                $resource = Resources::model()->find($criteria);
               
                if($resource===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resource" => $resource)
                       );
                       
                }
	}
        
         /**
	 * Manages all text-announcement resource models.
	 */
	public function actionListAllResourceItemGroups()
	{
              $toolbox_id = $_REQUEST['id'];  
               //$resource_id = 16;
            
            $user_id = Yii::app()->user->id;
            
            //$domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //get the domain of this toolbox id
            $domain_id = $this->getTheDomainOfThisToolbox($toolbox_id);
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='parent_id is null and domain_id=:domainid';  
                $criteria->params = array(':domainid'=>$domain_id);
                $resources = Resources::model()->findAll($criteria);
               
                if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resources" => $resources)
                       );
                       
                }
	}
        
        /**
         * This is the function that gets the domain of a toolbox
         */
        public function getTheDomainOfThisToolbox($toolbox_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$toolbox_id);
                $domain = Resourcegroup::model()->find($criteria);
                
                return $domain['domain_id'];
            
        }
        
        
        /**
	 * Manages all text-announcement resource models.
	 */
	public function actionListAllToolsAndToolboxesForADomain()
	{
              // $resource_id = $_REQUEST['id'];  
               //$resource_id = 16;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:domainid';  
                $criteria->params = array(':domainid'=>$domain_id);
                $resources = Resources::model()->findAll($criteria);
               
                if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resources" => $resources)
                       );
                       
                }
	}
        
        
        /**
	 * Manages all text-announcement resource models.
	 */
	public function actionListAllToolsAndTaskInThisPlatform()
	{
              // $resource_id = $_REQUEST['id'];  
               //$resource_id = 16;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='domain_id=:domainid';  
               // $criteria->params = array(':domainid'=>$domain_id);
                $resources = Resources::model()->findAll($criteria);
               
                if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resources" => $resources)
                       );
                       
                }
	}
       
       
        
        
        /**
         * This is the function to call when a group is to be created for a resource
         */
        public function createOrUpdateAGroupForResource($model, $icon=null){
            
            
            if($_FILES['icon']['name'] == null AND $model->id === null) {
                            
                //$model->icon = 'general_unavailable.png'; 
                $model->icon = $this->provideToolIconWhenUnavailable($model->resourcetype_id);
                if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = 'File creation/update was successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'File creation/update was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
                    
                    
                }elseif($_FILES['icon']['name'] == null AND $model->id !== null) {
                    
                  //$model->icon = 'general_unavailable.png';        
                    if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = 'File creation/update was successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'File creation/update was not successful';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
                    
                }else if($_FILES['icon']['name'] != null) {
                    
                        if(isset($_FILES)){
                                 $tmpName = $_FILES['icon']['tmp_name'];
                                 $fileName = $_FILES['icon']['name'];
                                 $type = $_FILES['icon']['type'];
                                 $size = $_FILES['icon']['size'];
                  
                         }
                        if($fileName !== null) {
                                $iconFileName = time().'_'.$fileName;
                             $model->icon = $iconFileName;
                             $model->icon_size = $size;
                         }
                        //Testing for the file extension and size
                             if($type === 'image/png'|| $type === 'image/jpg' || $type === 'image/jpeg'){
                                      if($size <= 256 * 256){
                                          if($model->save())
                                           {
                                                // upload the file
                                                if($fileName !== null) // validate to save file
                                                 $filepath = Yii::app()->params['icons'].$iconFileName;
                                                 move_uploaded_file($tmpName,  $filepath);
                                                 //get the moved file size
                                                 //$model->icon_size = $this->getThisFileSize($filepath);
                                                 //save the icon size
                                                 //$this->saveThisToolIconSize($model);
                                              //  $result['success'] = 'true';
                                                 $msg = 'File  creation/update was successful';
                                                 header('Content-Type: application/json');
                                                echo CJSON::encode(array(
                                                     "success" => mysql_errno() == 0,
                                                     "msg" => $msg)
                                                 );
                                            }else {
                                                 //$result['success'] = 'false';
                                                 $msg = 'File creation/update was not successfull.Check your input data';
                                                 header('Content-Type: application/json');
                                                 echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );
                                            }
                                     }else {
                                         //$result['success'] = 'false';
                                        $msg = 'Creation/Update failed. Icon/Image File is too large. Maximum size allowed is 65.5kb';
                                        header('Content-Type: application/json');
                                       echo CJSON::encode(array(
                                                     "success" => mysql_errno() != 0,
                                                     "msg" => $msg)
                                                 );                   
                                    }
                   
                         }else {
                                 //$result['success'] = 'false';
                                 $msg = 'Failed: Wrong File Type. Only jpeg, jpg or png files are allowed';
                                 header('Content-Type: application/json');
                                 echo CJSON::encode(array(
                                              "success" => mysql_errno() != 0,
                                              "msg" => $msg)
                                    );
                    
                    
                        }
                    
                    
                }//end of the if-else statement
            
            
            
            
        }
        
        /** 
         * This is the function that gets a file size on disk
         */
        public function getThisFileSize($file){
            
            $size = filesize($file); 
            
            if ($size < 0) 
            if (!(strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')) 
                $size = trim(`stat -c%s $file`); 
            else{ 
                $fsobj = new COM("Scripting.FileSystemObject"); 
                $f = $fsobj->GetFile($file); 
                $size = $file->Size; 
            } 
        return $size; 
        }
        
        
        /**
         * This is the function to get a directory size
         */
        public function getThisDirectorySize($directory){
            
            $size = 0; 
            foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory)) as $file){ 
                     $size+=$file->getSize(); 
            } 
            return $size; 
        } 
        
        
        /**
         * This is the function that saves the icon size
         */
        public function saveThisToolIconSize($model){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('resources',
                         array('icon_size'=>$model->icon_size,
                          
                     ),
                    ("id = $model->id")
              );
            
            if($result > 0){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * This is the function to call when a group is created without an icon
         */
        public function provideToolIconWhenUnavailable(){
            
         /**   if($resourcetype === 1){
                return 'general_unavailable.png';
            }
            if($resourcetype === 2){
                return 'accounts_unavailable.png';
            }
            if($resourcetype === 3){
                return 'operations_unavailable.png';
            }
            if($resourcetype === 4){
                return 'hr_unavailable.png';
            }
            if($resourcetype === 5){
                return 'crm_unavailable.png';
            }
            if($resourcetype === 6){
                return 'erp_unavailable.png';
            }
            if($resourcetype === 7){
                return 'loans_unavailable.png';
            }
            if($resourcetype === 8){
                return 'treasury_unavailable.png';
            }
            if($resourcetype === 9){
                return 'os_unavailable.png';
            }
            if($resourcetype === 10){
                return 'database_unavailable.png';
            }
            if($resourcetype === 11){
                return 'network_unavailable.png';
            }
            if($resourcetype === 12){
                return 'hardware_unavailable.png';
            }
            if($resourcetype === 13){
                return 'data_acquisition_unavailable.png';
            }
            if($resourcetype === 14){
                return 'cleaning_unavailable.png';
            }
            if($resourcetype === 15){
                return 'data_visual_unavailable.png';
            }
            if($resourcetype === 16){
                return 'data_analysis_unavailable.png';
            }
            if($resourcetype === 17){
                return 'processes_unavailable.png';
            }
            if($resourcetype === 18){
                return 'security_unavailable.png';
            }
            if($resourcetype === 19){
                return 'equipments_unavailable.png';
            }
            if($resourcetype === 20){
                return 'production_unavailable.png';
            }
            if($resourcetype === 21){
                return 'research_unavailable.png';
            }
            if($resourcetype === 22){
                return 'maintenance_unavailable.png';
            }
            if($resourcetype === 23){
                return 'investment_unavailable.png';
            }
            if($resourcetype === 24){
                return 'automation_unavailable.png';
            }
            if($resourcetype === 25){
                return 'chain_unavailable.png';
            }
            if($resourcetype === 26){
                return 'risk_unavailable.png';
            }
            if($resourcetype === 27){
                return 'control_unavailable.png';
            }
            if($resourcetype === 28){
                return 'crm_unavailable.png';
            }
          * 
          */
            return 'general_unavailable.png';
        }
        
        
        /**
         * This is the function to call when a task is created without an icon
         */
        public function provideTaskIconWhenUnavailable(){
            
          /**  if($resourcetype === 1){
                return 'general_unavailable_2.png';
            }
            if($resourcetype === 2){
                return 'accounts_unavailable_2.png';
            }
            if($resourcetype === 3){
                return 'operations_unavailable_2.png';
            }
            if($resourcetype === 4){
                return 'hr_unavailable_2.png';
            }
            if($resourcetype === 5){
                return 'crm_unavailable_2.png';
            }
            if($resourcetype === 6){
                return 'erp_unavailable_2.png';
            }
            if($resourcetype === 7){
                return 'loans_unavailable_2.png';
            }
            if($resourcetype === 8){
                return 'treasury_unavailable_2.png';
            }
            if($resourcetype === 9){
                return 'os_unavailable_2.png';
            }
            if($resourcetype === 10){
                return 'database_unavailable_2.png';
            }
            if($resourcetype === 11){
                return 'network_unavailable_2.png';
            }
            if($resourcetype === 12){
                return 'hardware_unavailable_2.png';
            }
            if($resourcetype === 13){
                return 'data_acquisition_unavailable_2.png';
            }
            if($resourcetype === 14){
                return 'cleaning_unavailable_2.png';
            }
            if($resourcetype === 15){
                return 'data_visual_unavailable_2.png';
            }
            if($resourcetype === 16){
                return 'data_analysis_unavailable_2.png';
            }
            if($resourcetype === 17){
                return 'processes_unavailable_2.png';
            }
            if($resourcetype === 18){
                return 'security_unavailable_2.png';
            }
            if($resourcetype === 19){
                return 'equipments_unavailable_2.png';
            }
            if($resourcetype === 20){
                return 'production_unavailable_2.png';
            }
            if($resourcetype === 21){
                return 'research_unavailable_2.png';
            }
            if($resourcetype === 22){
                return 'maintenance_unavailable_2.png';
            }
            if($resourcetype === 23){
                return 'investment_unavailable_2.png';
            }
            if($resourcetype === 24){
                return 'automation_unavailable_2.png';
            }
            if($resourcetype === 25){
                return 'chain_unavailable_2.png';
            }
            if($resourcetype === 26){
                return 'risk_unavailable_2.png';
            }
            if($resourcetype === 27){
                return 'control_unavailable_2.png';
            }
            if($resourcetype === 28){
                return 'crm_unavailable_2.png';
            }
           * 
           */
            return 'general_unavailable.png';
        }
        
        
        /**
         * This is the function to call when a task is created without a poster
         */
        public function provideTaskPosterWhenUnavailable(){
            
          /**  if($resourcetype === 1){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 2){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 3){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 4){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 5){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 6){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 7){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 8){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 9){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 10){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 11){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 12){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 13){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 14){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 15){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 16){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 17){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 18){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 19){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 20){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 21){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 22){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 23){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 24){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 25){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 26){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 27){
                return 'poster_general_unavailable.png';
            }
            if($resourcetype === 28){
                return 'poster_general_unavailable.png';
            }
           * 
           */
            return 'poster_general_unavailable.png';
        }
        
        
        /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
                
                
                
                
                
           
           
            
           
        }
        
        
        /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
        
       
        
        /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
        /**
         * This is the function that retrieves all the resources/tools in a domain
         */
        public function actionListAllToolsForThisDomain(){
            
            //obtain the userid of the logged in user
            $userid = Yii::app()->user->id;
            
           //determine the domain id of the user given his userid
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
           //determine all the toolboxes/resourcegroup belonging to this domain
            $toolboxes = $this->determineAllToolboxForADomain($domainid);
           
            //determine all the tools in those toolboxes for a domain
            $alltools = [];
            foreach($toolboxes as $toolbox){
                
                $tools = $this->determineAllToolsInAToolbox($toolbox);
                $alltools = array_unique(array_merge($alltools, $tools));
            }
            
            //determine the name of the tools
            
            $alltoolnames = [];
            foreach($alltools as $alltool){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$alltool);
                $domaintools= Resources::model()->findAll($criteria);
                
               $alltoolnames = array_merge($alltoolnames, $domaintools);
                
            }
                       
                
            if($domainid===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "tools" => $alltoolnames
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
            
            
        }
        
        
        /**
         * This is the function that retrieves all tasks/know-how consumable or produced by a domain
         */
        public function actionListAllTaskConsumableByADomain(){
            
           //obtain the userid of the logged in user
            $userid = Yii::app()->user->id;
            
           //determine the domain id of the user given his userid
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
           //determine all the toolboxes/resourcegroup belonging to this domain
            $toolboxes = $this->determineAllToolboxForADomain($domainid);
           
            //determine all the tools in those toolboxes for a domain
            $alltools = [];
            foreach($toolboxes as $toolbox){
                
                $tools = $this->determineAllToolsInAToolbox($toolbox);
                $alltools = array_unique(array_merge($alltools, $tools));
            }
            
            //retrieve all tools that is created by the domain
            $alltools_created_by_domain = $this->retrieveAllToolsOwnedByDomain($domainid);
            //merge the two tools into $alltools
            
            $alltools = array_unique(array_merge($alltools, $alltools_created_by_domain));
            
            
            //determine the tasks for these tools
            
            $alltasknames = [];
            foreach($alltools as $alltool){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='parent_id=:id';
                $criteria->params = array(':id'=>$alltool);
                $domaintasks= Resources::model()->findAll($criteria);
                
               $alltasknames = array_merge($alltasknames, $domaintasks);
                
            }
            
            if($domainid===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "task" => $alltasknames
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
        }
        
        
        /**
         * This is the function that retrieve all the tools in a user's toolboxes 
         */
        public function actionRetrieveAllToolsInAUserToolboxes(){
            
            //get the logged in user
            $userid = Yii::app()->user->id;
            
            //determine all the toolboxes/resourcegroup assigned to a user
            $usertoolboxes = $this->determineAllToolboxesForAUser($userid);
            
           //determine all the tools in those toolboxes for a domain
            $allusertools = [];
            foreach($usertoolboxes as $toolbox){
                
                $tools = $this->determineAllToolsInAToolbox($toolbox);
                $allusertools = array_unique(array_merge($allusertools, $tools));
            }
            
            //determine the name of the tools
            
            $alltoolnames = [];
            foreach($allusertools as $alltool){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$alltool);
                $domaintools= Resources::model()->findAll($criteria);
                
               $alltoolnames = array_merge($alltoolnames, $domaintools);
                
            }
            
            if($userid===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "tools" => $alltoolnames
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
            
            
        }
        
        
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        
      
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
        /**
         * Determine all toolboxes for a user
         */
        public function determineAllToolboxesForAUser($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'resourcegroup_id';
            $criteria->condition='user_id=:userid';
            $criteria->params = array(':userid'=>$userid);
            $toolboxes= UserHasResourcegroup::model()->findAll($criteria);
            
             $toolboxids = [];
            foreach($toolboxes as $toolbox){
                $toolboxids[] = $toolbox['resourcegroup_id'];
                
                
            }
            return $toolboxids;
            
        }
        
        /**
         * Determine all toolboxes/resourcegroup belonging to a domain
         */
        public function determineAllToolboxForADomain($domainid){
                       
            $criteria2 = new CDbCriteria();
            $criteria2->select = 'resourcegroup_id';
            $criteria2->condition='category_id=:id';
            $criteria2->params = array(':id'=>$domainid);
            $toolboxes= ResourcegroupHasResourcegroupcategory::model()->findAll($criteria2);
                                
            $toolboxids = [];
            foreach($toolboxes as $toolbox){
                $toolboxids[] = $toolbox['resourcegroup_id'];
                
                
            }
            return $toolboxids;
           /** 
            if($toolboxids===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "toolboxes" => $toolboxids
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
            * 
            */
            
            
        }
        
        /**
         * Determine tools in a toolbox
         */
        public function determineAllToolsInAToolbox($resourcegroup_id){
            
            $criteria2 = new CDbCriteria();
            $criteria2->select = 'resource_id';
            $criteria2->condition='resourcegroup_id=:id';
            $criteria2->params = array(':id'=>$resourcegroup_id);
            $tools= ResourceHasResourcegroups::model()->findAll($criteria2);
            
            $toolids = [];
            foreach($tools as $tool){
                $toolids[] = $tool['resource_id'];
                
                
            }
            return $toolids;
            
            
        }
        
        /**
	 * This is the function that list all task all resource items in the platform.
	 */
	public function actionListAllTaskForAllDomain()
	{
              // $resource_id = $_REQUEST['id'];  
               // $resource_id = 16;
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='parent_id is not null';  
                $criteria->params = array(':id'=>null);
                $resources = Resources::model()->findAll($criteria);
               
                if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "resources" => $resources)
                       );
                       
                }
	}
        
        /**
         * This is the function that determines the minimum task percentage share for a domain
         */
        public function determineTaskMinShareForADomain($domainid){
            
             //retreive the set domain task minimum share
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $min_share = DomainPolicy::model()->find($criteria); 
            
            return $min_share['min_task_share_in_tool'];
            
            
            
        }
        
        
        /**
         * This is the function that will determine if the provided value is less than the domain's task minimum share
         */
        public function isValueLessThanDomainTaskMinPercentageShare($value, $domainid){
            
            if($value < $this->determineTaskMinShareForADomain($domainid)){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the funcrion that determines if  the special min task percentage share is set
         */
        public function isSpecialMinimumTaskShareSet($domainid){
            
              //determine if the special min tasl share is set
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_min_share = DomainPolicy::model()->find($criteria); 
            
            if($special_min_share['special_min_task_share_in_tool'] >0){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that obtains the value of the special task min share
         */
        public function determineTheSpecialTaskMinimumShareValue($domainid){
            
              //retreive the set domain special task minimum share
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_min_share = DomainPolicy::model()->find($criteria); 
            
            return $special_min_share['special_min_task_share_in_tool'];
            
        }
        
        /**
         * This is the function that determines if a domain has store
         */
        public function determineIfThisDomainHasStore($domainid){
            
             //determine if this domain has store
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('stores')
                    ->where("domain_id=$domainid");
                $result = $cmd->queryScalar();
            
                     
               //confirm if this domain has at least one store
               if($result > 0){
                        return true;
                    
                     }else{
                         
                         return false;
                     }
            
            
        }
        
        /**
         * This is the function that determines if a specials video/doc size is provided
         */
        public function isSpecialMaxVideoSizeProvided($domainid){
            
             //determine if the special max video size is set
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_max_video = DomainPolicy::model()->find($criteria); 
            
            if($special_max_video['video_size'] >0){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that determines if a special demo or file size is provided
         */
        public function isSpecialMaxZipSizeProvided($domainid){
            
              //determine if the special max zip size is set
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_max_zip = DomainPolicy::model()->find($criteria); 
            
            if($special_max_zip['zip_file_size'] >0){
                return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that retrieves the value of the special max video size
         */
        public function determineTheSpecialVideoMaxSizeForThisDomain($domainid){
            
              //retreive the set domain special max video
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_max_video = DomainPolicy::model()->find($criteria); 
            
            return $special_max_video['video_size'];
            
        }
        
        /**
         *This is the function that retrieves the value of the special max zip file
         */
        public function determineTheSpecialZipMaxSizeForThisDomain($domainid){
            
             //retreive the set domain special max video
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>'active');
            $special_max_zip = DomainPolicy::model()->find($criteria); 
            
            return $special_max_zip['zip_file_size'];
            
        }
        
        
       
        /**
         * This is the function that retrieves the icon width in the platform
         */
        public function retrieveTheIconWidthSize(){
             //retreive the platform set icon width  size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_width'];
            
        }
        
        
        /**
         * This is the function that retrieves the icon width size in the platform
         */
        public function retrieveTheIconHeightSize(){
            
             //retreive the platform set icon height  size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $icon = PlatformSettings::model()->find($criteria); 
            
            return $icon['icon_height'];
            
        }
        
        
        /**
         * This is the function that retrieves all icon mime types in the platform
         */
        public function retrieveAllTheIconMimeTypes(){
            
            $icon_mimetype = [];
            $icon_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $icon_mime = PlatformSettings::model()->find($criteria); 
            
            $icon_mimetype = explode(',',$icon_mime['icon_mime_type']);
            foreach($icon_mimetype as $icon){
                $icon_types[] =$icon; 
                
            }
            
            return $icon_types;
            
        }
        
        
        
        /**
         * This is the function that retrieves the poster width in the platform
         */
        public function retrieveThePosterWidthSize(){
            
             //retreive the platform set poster width  size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $poster = PlatformSettings::model()->find($criteria); 
            
            return $poster['poster_width'];
            
        }
        
        
        /**
         * This is the function that retrieves the poster width size in the platform
         */
        public function retrieveThePosterHeightSize(){
            
            //retreive the platform set poster height  size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $poster = PlatformSettings::model()->find($criteria); 
            
            return $poster['poster_height'];
            
        }
        
        
        /**
         * This is the function that retrieves all poster mime types in the platform
         */
        public function retrieveAllThePosterMimeTypes(){
           
             //retrieve the poster mime types
            $poster_mimetype = [];
            $poster_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $poster_mime = PlatformSettings::model()->find($criteria); 
            
            $poster_mimetype = explode(',',$poster_mime['poster_mime_type']);
            foreach($poster_mimetype as $poster){
                $poster_types[] =$poster; 
                
            }
            
            return $poster_types;
            
        }
        
        /**
         * This is the function that determines size of the zip file
         * 
         */
        public function retrieveTheMaximumDemoSize(){
            
            //retreive the platform set zip file size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $zip = PlatformSettings::model()->find($criteria); 
            
            return $zip['zip_file_size'];
            
           
            
        }
        
        /**
         * This is the function that retrieves all zip mime types
         */
        public function retrieveZippedFileMimeTypes(){
            
            //retrieve the zip mime types
            $zip_mimetype = [];
            $zip_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $zip_mime = PlatformSettings::model()->find($criteria); 
            
            $zip_mimetype = explode(',',$zip_mime['zip_file_type']);
            foreach($zip_mimetype as $zip){
                $zip_types[] =$zip; 
                
            }
            
            return $zip_types;
        }
        
        /**
         * This is the function that retrieves the size of the video size from the domain
         */
        public function retrieveTheMaximumVideoSize(){
            
            //retreive the platform set video size
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $video = PlatformSettings::model()->find($criteria); 
            
            return $video['video_size']; 
        }
        
        
        /**
         * This is the function that retrieves all video mime types
         */
        public function retrieveAllDocumentMimeTypes(){
            
            //retrieve the video mime types
            $doc_mimetype = [];
            $doc_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $doc_mime = PlatformSettings::model()->find($criteria); 
            
            $doc_mimetype = explode(',',$doc_mime['document_mime_type']);
            foreach($doc_mimetype as $doc){
                $doc_types[] =$doc; 
                
            }
            
            return $doc_types;
        }
        
        
         /**
         * This is the function that retrieves all video mime types
         */
        public function retrieveAllVideoMimeTypes(){
            
            //retrieve the video mime types
            $video_mimetype = [];
            $video_types = [];
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $video_mime = PlatformSettings::model()->find($criteria); 
            
            $video_mimetype = explode(',',$video_mime['video_mime_type']);
            foreach($video_mimetype as $video){
                $video_types[] =$video; 
                
            }
            
            return $video_types;
        }
        
        
        /**
         * This is the function that determines if a value is less than the special min percentage task share in that domain
         */
        public function isValueLessThanTheMinSpecialPercentageShareForThisDomain($value, $domainid){
            if($value < $this->determineTheSpecialTaskMinimumShareValue($domainid)){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that determines if there is still space in a tool
         */
        public function isThereSpaceInThisTool($domainid,$tool_id,$id, $task_share_value){
            
            if($this->isSpecialMinimumTaskShareSet($domainid)){
                if($id === null){
                   if($this->determineTheSpecialTaskMinimumShareValue($domainid) <= $this->toolRemainingSpaceValue($tool_id, $id)){
                    return true;
                }else{
                    return false;
                } 
                }else{
                    if($this->isTaskShareValueTheSameAsThisExistingOne($id,$task_share_value)){
                   
                        return true;
                        
                    }else{
                        
                        if($this->isNewTaskPercentageShareLowerThanTheExistingOne($task_share_value,$id)){
                          return true;
                                     
                        }else{
                            if($this->isTaskShareValueAcceptable($task_share_value, $tool_id,$id)){
                                return true;
                                
                                
                    
                            }else{
                                return false;
                            }
                        }
                    }
                }
                
            }else{
               if($id === null){
                  if($this->determineTaskMinShareForADomain($domainid) <= $this->toolRemainingSpaceValue($tool_id,$id)){
                    return true;
                    
                }else{
                    return false;
                } 
               }else{
                   if($this->isTaskShareValueTheSameAsThisExistingOne($id,$task_share_value)){
                        return true;
                    }else{
                        
                        if($this->isNewTaskPercentageShareLowerThanTheExistingOne($task_share_value,$id)){
                            return true;
                            
                        }else{
                            if($this->isTaskShareValueAcceptable($task_share_value, $tool_id,$id)){
                                return true;
                            }else{
                                return false;
                            }
                        }
                    }
               }
                
            }
            
        }
        
        
        /**
         * This is the function that determines the remaining tool space 
         */
        public function toolRemainingSpaceValue($tool_id,$id){
            
            $remaining_space = 0.00;
            $total_space = 0.00;
            //spool all the tasks in this tool
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='parent_id=:id';
            $criteria->params = array(':id'=>$tool_id);
            $tasks = Resources::model()->findAll($criteria); 
                    
            foreach($tasks as $task){
                $total_space = $total_space + (double)$task['percentage_share'];
            }
           if($id === null){
                $remaining_space = 100.00 - $total_space;
            
                return $remaining_space;
           }else{
               //return $task_share_value;
                 $exemp_total = 0.00;
                  $criteria1 = new CDbCriteria();
                  $criteria1->select = '*';
                  $criteria1->condition='parent_id=:id and id!=:taskid';
                  $criteria1->params = array(':id'=>$tool_id,':taskid'=>$id);
                  $exemp_task = Resources::model()->findAll($criteria1);
                  
                  foreach($exemp_task as $value){
                      $exemp_total = $exemp_total + $value['percentage_share'];
                  }
                  $remaining_space = 100.00 - $exemp_total;
                  
                  return $remaining_space;
           } 
           
           
        }
        
        
        /**
         * This is the function that determines if a task could be added to a tool base on its share value
         */
        public function isTaskShareValueAcceptable($percentage_share, $tool_id,$id){
            
            if($percentage_share <= $this->toolRemainingSpaceValue($tool_id,$id)){
                 return true;
            }else{
                return false;
            }
            
        }
        
        /**
         * This is the function that determines if a stated task share value had not changed
         */
        public function isTaskShareValueTheSameAsThisExistingOne($id,$task_share_value){
            if($task_share_value == (double)$this->determineThisTaskPercentageShareValue($id)){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that retrieves the task percentage share in a tool
         */
        public function determineThisTaskPercentageShareValue($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $task = Resources::model()->find($criteria); 
            
            return $task['percentage_share'];
        }
        
        /**
         * This is the function that determines if the new task share is lower that the existing one
         */
        public function isNewTaskPercentageShareLowerThanTheExistingOne($task_share_value, $id){
            
            if($task_share_value <= (double)$this->determineThisTaskPercentageShareValue($id)){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that moves image to a temporary location
         */
        public function moveIconImageToATempLocation(){
            
            if(isset($_FILES['icon']['name'])){
                        $tmpName = $_FILES['icon']['tmp_name'];
                        $iconName = $_FILES['icon']['name'];    
                        $iconType = $_FILES['icon']['type'];
                        $iconSize = $_FILES['icon']['size'];
                  
                    }
           
           
                    if($iconName !== null) {
                
                        
                          $iconFileName = time().'_'.$iconName; 
                     
                           // upload the icon file
                        if($iconName !== null){
                     
                            	$iconPath = Yii::app()->params['imagetemp'].$iconFileName;
				move_uploaded_file($tmpName,  $iconPath);
                                        
                        
                                return $iconPath;
                        }
                    }else{
                        return null;
                    }
        }
        
        /**
         * This is the function to remove image from the temp location
         */
        public function removeImageFromTempLocation($filepath){
            
            if(unlink($filepath)){
                    return true;
                }else{
                    return false;
                }
        }
       
        
        /**
         * This is the list of tools produced or consumed by a domain
         */
      /**  public function actionListAllCopyableToolsProducedOrConsumedByADomain(){
            
            //get the logged in user id
            $userid = Yii::app()->user->id;
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            //retrieve all the toolboxes assigned to this domain
            $alltoolsInToolboxes= [];
            $alltoolsInToolboxes = $this->retrieveAllToolsInToolboxesProducedOrConsumedByThisDomain($domainid);
           
            //retrieve all tools created by this domain
            $toolsproducedByDomain = [];
            $toolsproducedByDomain = $this->retrieveAllToolsProducedByThisDomain($domainid);
           
            //merge the two arrays together
            $toolsProducedAndConsumedByDomain = array_unique(array_merge($alltoolsInToolboxes,$toolsproducedByDomain));
           
            //obtain the detail of the tools
            $alltoolswithinfo = [];
            foreach($toolsProducedAndConsumedByDomain as $tool){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$tool);
                $toolinfo = Resources::model()->findAll($criteria); 
                
                $alltoolswithinfo = array_merge($alltoolswithinfo,$toolinfo);
                
           }
                 if($alltoolswithinfo===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "tool" => $alltoolswithinfo
                          
                           
                           
                          
                       ));
                       
                }  
                   
            
            
            
        }
       * 
       */
        
        
        /**
         * This is the tool that list all tools produced and consumed by this domain
         */
        public function actionListAllCopyableToolsProducedOrConsumedByADomain(){
            //obtain the userid of the logged in user
            $userid = Yii::app()->user->id;
            
           //determine the domain id of the user given his userid
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
           //determine all the toolboxes/resourcegroup belonging to this domain
            $toolboxes = $this->determineAllToolboxForADomain($domainid);
           
            //determine all the tools in those toolboxes for a domain
            $alltools = [];
            foreach($toolboxes as $toolbox){
                
                $tools = $this->determineAllToolsInAToolbox($toolbox);
                $alltools = array_unique(array_merge($alltools, $tools));
            }
            
            //retrieve all tools that is created by the domain
            $alltools_created_by_domain = $this->retrieveAllToolsOwnedByDomain($domainid);
            //merge the two tools into $alltools
            
            $alltools = array_unique(array_merge($alltools, $alltools_created_by_domain));
            
            
            //determine the name of the tools
            
            $alltoolnames = [];
            foreach($alltools as $alltool){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id and duplicate=:duplicate';
                $criteria->params = array(':id'=>$alltool,':duplicate'=>1);
                $domaintools= Resources::model()->findAll($criteria);
                
               $alltoolnames = array_merge($alltoolnames, $domaintools);
                
            }
            
                       
                
            if($domainid===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "tool" => $alltoolnames
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
                } 
        }
        
        
        /**
         * This is the function that retrieves all tools produced by domain
         */
        public function retrieveAllToolsOwnedByDomain($domainid){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and duplicate=:duplicate';
            $criteria->params = array(':id'=>$domainid,':duplicate'=>1);
            $domaintools= Resources::model()->findAll($criteria);
            
            $alltools = [];
            foreach($domaintools as $tool){
                $alltools[] = $tool['id'];
            }
            
            return $alltools;
            
            
            
        }
        
               
        /**
         * This is just a tester function
         */
        public function actionjusttesting(){
            //$toolboxes = [];
            $toolboxes = $this->retrieveAllToolsOwnedByDomain($domain=1);
            
            if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "toolboxids" => $toolboxes,
                           //"original"=>$other_parameters
                          
                           
                           
                          
                       ));
                       
                }
        }
        
        /**
         * This is the function that list all task for duplicate tools
         */
        public function actionListAllTaskForDuplicatedTools(){
            
            $tool_id = $_REQUEST['id'];
            //$tool_id = 321;        
            //retrieve all tasks for this tool
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='tool_id=:id';  
            $criteria->params = array(':id'=>$tool_id);
            $tools = DuplicateToolHasTask::model()->findAll($criteria);
            
          /**  $alltools = [];
           //retreive the detail of the task 
            foreach($tools as $tool){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';  
                $criteria->params = array(':id'=>$tool['task_id']);
                $resources = Resources::model()->findAll($criteria);
                
                $alltools = array_merge($alltools,$resources);
            }
           * 
           */
                   
             if($tools===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "task" => $tools)
                       );
                       
                }        
            
        }
        
        /**
         * This is the function that fetches the information about a task
         */
        public function actiongetTheTaskInformation(){
            
            $id = $_REQUEST['id'];
            
            //fetch the task info from the database
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';  
            $criteria->params = array(':id'=>$id);
            $task = Resources::model()->find($criteria);
         
           //get the product name
            $productname = $this->getTheProductName($task['product_id']);
            
            //get the resourcetype name
            $typename = $this->getTheResourcetypeName($task['resourcetype_id']);
            
      
             if($task===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "task" => $task,
                           "productname"=>$productname,
                           "type"=>$typename
                               )
                       );
                       
                } 
            
            
            
        }
        
        /**
         * This is the function that gets the product name
         */
        public function getTheProductName($product_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';  
            $criteria->params = array(':id'=>$product_id);
            $product = Products::model()->find($criteria);
            
            return $product['name'];
            
        }
        
        
        /**
         * This is the function that retrieves the preferred currency for a domain
         * 
         */
        public function actiongetThePreferredCurrencyOfADomain(){
            
            //get the id of the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the domain of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            //retrieve the preferred currency for this domain
            
            $preferred_currency = $this->getThisDomainPreferredCurrency($domain_id);
            
            //get the prefferred currency code
            
            $currency_code = $this->getThisCurrencyCode($preferred_currency);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "currency_code" =>$currency_code,
                           "preferred_currency"=> $preferred_currency
                       ));
        }
        
        
        /**
         * This is the function that gets the preferred currency for a domain
         */
        public function getThisDomainPreferredCurrency($domain_id){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='domain_id=:id and status="active"';
                     $criteria->params = array(':id'=>$domain_id);
                     $domain= DomainPolicy::model()->find($criteria);
                     
                     return $domain['domain_currency_preference'];
            
            
        }
        
        /**
         * get the preferred currency code
         */
        public function getThisCurrencyCode($preferred_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$preferred_currency);
            $currency = Currencies::model()->find($criteria); 
            
            return $currency['currency_code'];
        }
        
        
        /**
         * This is the function that gets the resource type name
         */
        public function getTheResourcetypeName($resourcetype_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';  
            $criteria->params = array(':id'=>$resourcetype_id);
            $type = ResourceType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        
        /**
         * This is the function that gets the platform base currency
         */
        public function getThePlatformBaseCurrency(){
            
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                    // $criteria->condition='country_id=:id';
                   //  $criteria->params = array(':id'=>$country_id);
                     $platform= PlatformSettings::model()->find($criteria);
                     
                     return $platform['platform_default_currency_id'];
            
        }
        
        /**
         * This is the function that gets the exchange rate of a currency
         */
        public function getThePreferredCurrencyExchangeRate($currency,$base_currency){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='base_currency_id=:baseid and currency_id=:currencyid';
            $criteria->params = array(':baseid'=>$base_currency,':currencyid'=>$currency);
            $currency= CurrencyExchange::model()->find($criteria);
            
            return $currency['exchange_rate'];
        }
        
        
        /**
         * This is the function that gets all domain tools belonging to a product
         */
        public function actiongetalldomaintoolsbelongingtothisproduct(){
            
            $product_id = $_REQUEST['product_id'];
            //$resourcetype_id= $_REQUEST['resourcetype_id'];
            //$product_id = 2;
           // $resourcetype_id = 1;
            //get the logged in user
            $user_id = Yii::app()->user->id;
            
            //get the logged in user domain
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
                       
            $all_domain_product_tools = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='(domain_id=:domainid) and (product_id=:productid and parent_id is null)';
            $criteria->params = array(':domainid'=>$domain_id,':productid'=>$product_id);
            $tools= Resources::model()->findAll($criteria);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "tool" =>$tools
                          
                       ));
            
            
            
        }
        
        
        /**
         * This is the function that downloads media to the user
         */
        public function actionDownloadThisMedia(){
            
            $id = $_REQUEST['id'];
            
            //get the full media filename
            $media_name = $this->getThisMediaFullFilename($id);

            
           $msg = "File successfully downloaded";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "filename" => $media_name
                                        
                           ));
       
     }
        
        
     /**
      * This is the function that gets the media zipped filename
      */
     public function getThisMediaFullFilename($id){
         
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$id);
                $name= Resources::model()->find($criteria);
                
                $media_name = $name['html5_demo_file']. '.zip';
                
                return $media_name;
     }
     
     
     /**
      * This is the file that gets the media directory name
      */
     public function getTheMediaDirectoryName($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $name = Resources::model()->find($criteria); 
            
            return $name['html5_demo_file'];
     }
     
     
     /*
      * This is the function that determines if a domain is exempted from having an initiator verifier
      */
     public function doesDomainSupportInitiatorVerifier($domain_id){
        
         if($this->doesPlatformSupportsInitiatorVerifier() == true){
              if($this->isDomainExemptedFromHavingInitiatorVerifier($domain_id)== true){
                return false;
              }else{
                return true;
              }
         }else{
             return false;
         }
        
         
     }
     
     /**
      * This is the function that determines if a domain supports initiator verifier
      */
     public function isDomainExemptedFromHavingInitiatorVerifier($domain_id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id  and status=:status';
            $criteria->params = array(':id'=>$domain_id, ':status'=>'active');
            $domain = DomainPolicy::model()->find($criteria); 
            
            if($domain['exempt_domain_initiator_verifier'] == 1){
                return true;
            }else{
                return false;
            }
     }
     
     /**
      * This is the function that determines if the platform supports initiator verifier
      */
     public function doesPlatformSupportsInitiatorVerifier(){
         
         if($this->isPlatformInSupportOfHavingInitiatorVerifier()== true){
             return true;
         }else{
             return false;
         }
         
     }
     
     /**
      * This is the function that determines if this platform supports initiator verifier
      */
     public function isPlatformInSupportOfHavingInitiatorVerifier(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $platform = PlatformSettings::model()->find($criteria); 
            
            if($platform['enable_domain_initiator_verifier'] == 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
     /**
      * This is the function that determines if domain supports platform checker verifier
      */
     public function doesPlatformSupportsCheckerVerifier(){
         
         if($this->isPlatformInSupportOfHavingCheckerVerifier()== true){
             return true;
         }else{
             return false;
         }
     }
     
     
     /** 
      * This is the function that gets the checker verifier value from the database
      */
     public function isPlatformInSupportOfHavingCheckerVerifier(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $platform = PlatformSettings::model()->find($criteria); 
            
            if($platform['enable_platform_checker_verifier'] == 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     /**
      * This is the function that retrieves the minimum number of months  to expiration for a document
      */
     public function getThePlatformMinimumNumberOfMonthsToDocumentExpiration(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $platform = PlatformSettings::model()->find($criteria); 
            
           return $platform['number_of_months_before_expiration'];
     }
     
     
     /**
      * This is the function that obtains the domains minimum number of months to expiration
      */
     public function getTheDomainMininumNumberOfMonthsToDocumentExpiration($domain_id){
         
         if($this->shouldDomainComplyWithThePlatformMinimumNumberOfMonthsSetting($domain_id)== true){
             return $this->getThePlatformMinimumNumberOfMonthsToDocumentExpiration();
         }else{
             return $this->getDomainSpecificMinimumNumberOfmonthsToDocumentExpiration($domain_id);
         }
     }
     
     
     /**
      * This is the function that determines if a domain should comply with the platform's minimum number of months to expiration policy
      */
     public function shouldDomainComplyWithThePlatformMinimumNumberOfMonthsSetting($domain_id){
         if($this->getDomainSpecificMinimumNumberOfmonthsToDocumentExpiration($domain_id) == -1){
             return true;
         }else{
             return false;
         }
     }
     
     
     /**
      * This is the function that gets the value of the minimum number of months to document expiration
      */
     public function getDomainSpecificMinimumNumberOfmonthsToDocumentExpiration($domain_id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id  and status=:status';
            $criteria->params = array(':id'=>$domain_id, ':status'=>'active');
            $domain = DomainPolicy::model()->find($criteria); 
            
            return $domain['number_of_days_before_document_expiry'];
     }
     
     
     /**
      * This is the function that retrieves close to expire documents
      */
     public function actionclosetoexpirydocuments(){
         $userid = Yii::app()->user->id;
         $domain_id = $this->determineAUserDomainIdGiven($userid);
         if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformChecker")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformVerifier")){ 
             
            $close_to_expire_documents = $this->getAllCloseToExpireDocumentIdsOnThePlatform();
             
             $all_docs = [];
             foreach($close_to_expire_documents as $close){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$close);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
          
         
         }else if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainVerifier")){
             
           $close_to_expire_documents = $this->getAllCloseToExpireDocumentIdsForThisDomain($domain_id);
              
             $all_docs = [];
             foreach($close_to_expire_documents as $close){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$close);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
      
         }else{
         $close_to_expire_documents = $this->getAllCloseToExpireDocumentIdsForThisDomainCreatedByThisUser($domain_id, $userid);
             
             $all_docs = [];
             foreach($close_to_expire_documents as $close){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$close);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
         
             
         }
         
     }
     
     
     /**
      * This is the function that spools all close to expire documents for a particular domain
      */
     public function getAllCloseToExpireDocumentIdsForThisDomain($domain_id){
        
         $min_month = $this->getTheDomainMininumNumberOfMonthsToDocumentExpiration($domain_id);
         return $this->getAllDomainCloseToExpiryDocumentIds($domain_id,$min_month);
        
     }
     
   
     /**
      * This is the function that gets all domains 'close to expiry' documents ids
      */
     public function getAllDomainCloseToExpiryDocumentIds($domain_id,$min_month){
         
         //get all the document ids belonging to this domain
         $all_docs = $this->getAllDomainDocumentIds($domain_id);
         
         $close_to_expiry = [];
         foreach($all_docs as $doc){
             if($this->isThisDocumentCloseToExpiration($doc,$min_month)){
                 $close_to_expiry[] = $doc;
             }
         }
         return $close_to_expiry;
         
     }
     
     /**
      * This is the function that retreives all documents belonging to this domain
      */
     public function getAllDomainDocumentIds($domain_id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_domain_docs = [];
            
            foreach($all_docs as $doc){
                $all_domain_docs[] = $doc['id'];
            }
            return $all_domain_docs;
         
     }
     
     
    
     
     /**
      * This is the function that gets all close to expire documents across the platform
      */
     public function getAllCloseToExpireDocumentIdsOnThePlatform(){
         
         $min_month = $this->getThePlatformMinimumNumberOfMonthsToDocumentExpiration();
         return $this->getAllPlatformCloseToExpiryDocumentIds($min_month);
         
     }
     
     
       /**
      * This is the function that gets all the platforms close to expire documents
      */
     public function getAllPlatformCloseToExpiryDocumentIds($min_month){
         
         //get all the document ids in this platform
         $all_docs = $this->getAllPlatformDocumentIds();
         
         $close_to_expiry = [];
         foreach($all_docs as $doc){
             if($this->isThisDocumentCloseToExpiration($doc,$min_month)){
                 $close_to_expiry[] = $doc;
             }
         }
         return $close_to_expiry;
         
     }
     
     /**
      * This is the function that retrieves all dociument ids on the platform
      */
     public function getAllPlatformDocumentIds(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='domain_id=:id';
           // $criteria->params = array(':id'=>$domain_id);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_domain_docs = [];
            
            foreach($all_docs as $doc){
                $all_domain_docs[] = $doc['id'];
            }
            return $all_domain_docs;
         
     }
     
     
     /**
      * This is the function that spools all close to expiry documents created for a domain by a particular user
      */
     public function getAllCloseToExpireDocumentIdsForThisDomainCreatedByThisUser($domain_id, $userid){
         
         $min_month = $this->getTheDomainMininumNumberOfMonthsToDocumentExpiration($domain_id);
         return $this->getAllDomainCloseToExpiryDocumentIdsCreatedByThisUser($domain_id,$userid,$min_month);
         
         
     }
     
     
     /**
      * This is the function that gets all close to expire documents created by a particular user
      */
     public function getAllDomainCloseToExpiryDocumentIdsCreatedByThisUser($domain_id,$userid,$min_month){
         
         //get all the document ids in this platform
         $all_docs = $this->getAllDomainDocumentIdsCreatedByThisUser($domain_id,$userid);
         
         $close_to_expiry = [];
         foreach($all_docs as $doc){
             if($this->isThisDocumentCloseToExpiration($doc,$min_month)){
                 $close_to_expiry[] = $doc;
             }
         }
         return $close_to_expiry;
         
     }
     
     
     /**
      * This is the function that retreives all document ids created by this user
      */
     public function getAllDomainDocumentIdsCreatedByThisUser($domain_id,$userid){
         
           $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='(domain_id=:id and create_user_id=:userid)';
            $criteria->params = array(':id'=>$domain_id,':userid'=>$userid);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_domain_docs = [];
            
            foreach($all_docs as $doc){
                $all_domain_docs[] = $doc['id'];
            }
            return $all_domain_docs;
         
     }
     
      /**
      * This is the function that retrieves all expired but awaiting destruction documents
      */
     public function actionexpiredbutawaitingdestruction(){
         $userid = Yii::app()->user->id;
         $domain_id = $this->determineAUserDomainIdGiven($userid);
         if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformChecker")||$this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformVerifier")){ 
             
             $expired_documents = $this->getAllExpiredButAwaitingDestructionDocumentIdsOnThePlatform();
             
             $all_docs = [];
             foreach($expired_documents as $expired){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$expired);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
             
         }else if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "domainVerifier")){
             
             $expired_documents = $this->getAllExpiredButAwaitingDestructionDocumentIdsForThisDomain($domain_id);
              
              $all_docs = [];
             foreach($expired_documents as $expired){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$expired);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
 
         }else{
             $expired_documents = $this->getAllExpiredButAwaitingDestructionDocumentIdsForThisDomainCreatedByThisUser($domain_id, $userid);
             
              $all_docs = [];
             foreach($expired_documents as $expired){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$expired);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
             
             
         }
         
     }
     
     /**
      * This is the function that will spool all expired but awaiting destruction documents across platform
      */
     public function getAllExpiredButAwaitingDestructionDocumentIdsOnThePlatform(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_expired_docs = [];
            foreach($all_docs  as $doc){
                if($this->isDocumentExpiredButAwaitsDestruction($doc['id'])){
                    $all_expired_docs[] = $doc['id'];
                }
                
            }
            return $all_expired_docs;
         
     }
     
     
     /**
      * This is the function that will spool all expired but awaiting destruction documents across a domain
      */
     public function getAllExpiredButAwaitingDestructionDocumentIdsForThisDomain($domain_id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_expired_docs = [];
            foreach($all_docs  as $doc){
                if($this->isDocumentExpiredButAwaitsDestruction($doc['id'])){
                    $all_expired_docs[] = $doc['id'];
                }
                
            }
            return $all_expired_docs;
         
     }
     
     
     /**
      * This is the function that will spool all expired but awaiting destruction documents across a domain  created by a particular user
      */
     public function getAllExpiredButAwaitingDestructionDocumentIdsForThisDomainCreatedByThisUser($domain_id, $userid){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='(domain_id=:id and create_user_id=:userid)';
            $criteria->params = array(':id'=>$domain_id,':userid'=>$userid);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_expired_docs = [];
            foreach($all_docs  as $doc){
                if($this->isDocumentExpiredButAwaitsDestruction($doc['id'])){
                    $all_expired_docs[] = $doc['id'];
                }
                
            }
            return $all_expired_docs;
         
     }
     
     
     /**
      * This is the function that determines if a ocument had expired but still awaits destruction
      */
     public function isDocumentExpiredButAwaitsDestruction($id){
         
         if($this->isDestroyedDocuments($id)== false){
             if($this->isDocumentExpired($id) == true){
                 return true;
                 
             }else{
                 return false;
             }
             
         }else{
             return false;
         }
         
     }
     
     
     /**
      * This is the function that determines idf a document has expired
      */
     public function isDocumentExpired($id){
         
         //get the expiry date of this document
         $expiry_date = $this->getTheExpiryDateOfThisDocument($id);
         if($this->isTodayDateGreaterThanTheExpiryDate($expiry_date)){
             return true;
         }else{
             return false;
         }
         
     }
     
     /**
      * This is the function that retrieves the expiry date of a document
      */
     public function getTheExpiryDateOfThisDocument($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            return $doc['document_expiry_date'];
         
     }
     
     /**
      * This is the function that test if today is greater than the expiry date
      */
     public function isTodayDateGreaterThanTheExpiryDate($expiry_date){
         
         if($expiry_date === null){
             return false;
         }else{
               $today =getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
               $day = $today['mday'];
               $month = $today['mon'];
               $year = $today['year'];
               
               $expiry = getdate(strtotime($expiry_date));
               if(($year - $expiry['year']) > 0){
                   return true;
               }else if(($year - $expiry['year']) == 0){
                   if(($month - $expiry['mon']) > 0){
                       return true;
                   }else if(($month - $expiry['mon']) == 0){
                       if(($day - $expiry['mday']) > 0 ){
                           return true;
                       }else{
                           return false;
                       }
                   }else{
                       return false;
                   }
               }else{
                   return false;
               }
         }
                  
     }
     
      /**
      * This is the function that retrieves all already destroyed documents
      */
     public function actiondestroyeddocuments(){
         $userid = Yii::app()->user->id;
         $domain_id = $this->determineAUserDomainIdGiven($userid);
         if($this->determineIfAUserHasThisPrivilegeAssigned($userid,"platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid,"platformChecker")||$this->determineIfAUserHasThisPrivilegeAssigned($userid,"platformVerifier")){ 
             
             $destroyed_documents = $this->getAllDestroyedDocumentIdsOnThePlatform();
             
             $all_docs = [];
             foreach($destroyed_documents as $destroyed){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$destroyed);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
             
         }else if($this->determineIfAUserHasThisPrivilegeAssigned($userid,"domainAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid,"domainVerifier")){
             
             $destroyed_documents = $this->getAllDestroyedDocumentIdsForThisDomain($domain_id);
              
             $all_docs = [];
             foreach($destroyed_documents as $destroyed){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$destroyed);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
 
         }else{
             $destroyed_documents = $this->getAllDestroyedDocumentIdsForThisDomainCreatedByThisUser($domain_id, $userid);
             
             $all_docs = [];
             foreach($destroyed_documents as $destroyed){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$destroyed);
                $doc = Resources::model()->find($criteria);
                
                $all_docs[] = $doc;
             }
              if($all_docs===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $all_docs
                               )
                       );
                       
                }
             
             
         }
         
     }
     
     
     
      /**
      * This is the function that will spool all expired but awaiting destruction documents across platform
      */
     public function getAllDestroyedDocumentIdsOnThePlatform(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$id);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_destroyed_docs = [];
            foreach($all_docs  as $doc){
                if($this->isDestroyedDocuments($doc['id'])){
                    $all_destroyed_docs[] = $doc['id'];
                }
                
            }
            return $all_destroyed_docs;
         
     }
     
     
     /**
      * This is the function that will spool all expired but awaiting destruction documents across a domain
      */
     public function getAllDestroyedDocumentIdsForThisDomain($domain_id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id';
            $criteria->params = array(':id'=>$domain_id);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_destroyed_docs = [];
            foreach($all_docs  as $doc){
                if($this->isDestroyedDocuments($doc['id'])){
                    $all_destroyed_docs[] = $doc['id'];
                }
                
            }
            return $all_destroyed_docs;
         
     }
     
     
     /**
      * This is the function that will spool all expired but awaiting destruction documents across a domain  created by a particular user
      */
     public function getAllDestroyedDocumentIdsForThisDomainCreatedByThisUser($domain_id, $userid){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='(domain_id=:id and create_user_id=:userid)';
            $criteria->params = array(':id'=>$domain_id,':userid'=>$userid);
            $all_docs = Resources::model()->findAll($criteria);
            
            $all_destroyed_docs = [];
            foreach($all_docs  as $doc){
                if($this->isDestroyedDocuments($doc['id'])){
                    $all_destroyed_docs[] = $doc['id'];
                }
                
            }
            return $all_destroyed_docs;
         
     }
     
     
     /**
      * This is the funcyion that determines if a document is already destroyed
      */
     public function isDestroyedDocuments($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['is_destroyed'] == 1){
               return true; 
            }else{
                return false;
            }
         
     }
     
     
      /**
      * This is the function that determines if a document is close to expiration
      */
     public function isThisDocumentCloseToExpiration($doc,$min_month){
         $today =getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
         $day = $today['mday'];
         $month = $today['mon'];
         $year = $today['year'];
         
         $expiry = getdate(strtotime($this->getTheExpiryDateOfThisDocument($doc)));
         if((($expiry['year'] - $year) == 0)){
             if((($expiry['mon'] - $month)> 0) && (($expiry['mon'] - $month)<= $min_month)){
                  return true;
             
             }else{
                 return false;
             }
            
         }else if((($expiry['year'] - $year) > 0)){
             $year_diff = $expiry['year'] - $year;
             $month_diff = $expiry['mon'] - $month;
             $total_month = ($year_diff *12) + $month_diff;
             if($total_month <= $min_month){
                 return true;
             }else{
                 return false;
             }
             
         }else{
             return false;
         }
    
     }
     
     
     
     
     /**
      * This is the function that effects an extended date to the expiry date of a close-to-expiry document
      */
     public function actioneffectExtendedDocumentExpiryDate(){
         
         $userid = Yii::app()->user->id;
         $id = $_POST['id'];
         $new_expiry = date("Y-m-d H:i:s", strtotime($_POST['document_expiry_date']));
         $domain_id = $this->determineAUserDomainIdGiven_old($userid);
         
         //update the resources/document table with the new expiry date
         if($this->isExtendingDocumentExpiryDateSuccessfull($id,$new_expiry,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Expiry Date successfully extended"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "The Expiry date of this document could not be extended"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that does the actual initiation of expiry date extension 
      */
     public function isExtendingDocumentExpiryDateSuccessfull($id,$new_expiry,$domain_id){
         if($this->isInitiatorVerifierRequired($domain_id)){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('resources',
                                  array(
                                   'tentative_document_new_expiry_date'=>$new_expiry,
                                   //'start_date'=>$today,   
                                   'initiate_expiry_date_extension_for_close_to_expiry_doc'=>1, 
                                   'document_expiry_date_extended_by'=>Yii::app()->user->id,
                                    'close_to_expiry_extension_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
             
             
             
         }else{
              $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('resources',
                                  array(
                                   'tentative_document_new_expiry_date'=>null,
                                   'document_expiry_date'=>$new_expiry,   
                                   'initiate_expiry_date_extension_for_close_to_expiry_doc'=>0, 
                                   'document_expiry_date_extended_by'=>Yii::app()->user->id,
                                    'close_to_expiry_extension_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
             
         }
         
     }
     
          
     
     /**
      * This is the function that verifies the extended expiry date of the close-to-expiry document
      */
     public function actionverifyExtendedDocumentExpiryDate(){
         
         $id = $_POST['id'];
         //$new_expiry = $_POST['document_expiry_date'];
         
         //update the resources/document table with the new expiry date
         if($this->isVerifyingTheExtendedDocumentExpiryDateSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Extended Expiry Date change successfully verified"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem verifying this Extended document Expiry Date. Date extension may not had been done"
                               )
                       );
         }
     }
     
     
     /**
      * This is the function that does the actual verification of close-to-expiry document extension
      */
     public function isVerifyingTheExtendedDocumentExpiryDateSuccessfull($id){
         
        if($this->isThisDocumentExpiryDateExtended($id)){
            //get the document new expiry date
            $new_expiry = $this->getThisDocumentNewExpiryDate($id);
            if($this->isExtendedExpiryDateVerified($id,$new_expiry)){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
         
     }
     
     /**
      * This is the function that does the rejection of a new expiry date for a close-to-expire document
      */
     public function actionrejectExtendedDocumentExpiryDate(){
         
         $id = $_POST['id'];
         
         //update the resources/document table with the new expiry date
         if($this->isRejectionOfTheExtendedDocumentExpiryDateSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Rejection of this Expiry Date change was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem rejecting this Extended document Expiry Date. Date extension may not had been done"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that does the actual rejection of the new expiry date
      */
     public function isRejectionOfTheExtendedDocumentExpiryDateSuccessfull($id){
         
         if($this->isThisDocumentExpiryDateExtended($id)){
             if($this->isExtendedExpiryDateRejected($id)){
                return true;
            }else{
                return false;
            }
             
             
         }else{
             return false;
         }
     }
     
     
     
     /**
      * This is the function that does the actual rejection of the new expiry date by the verifier
      */
     public function isExtendedExpiryDateRejected($id){
         
         $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resources',
                                  array(
                                   //'document_expiry_date'=>$new_expiry,
                                   'tentative_document_new_expiry_date'=>null,   
                                   'initiate_expiry_date_extension_for_close_to_expiry_doc'=>0, 
                                   'extended_document_expiry_date_verified_by'=>Yii::app()->user->id,
                                    'verified_close_to_expiry_extension_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that determines if close-to-expiry document expiry date was actually extended
      */
     public function isThisDocumentExpiryDateExtended($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['initiate_expiry_date_extension_for_close_to_expiry_doc'] == 1){
               return true; 
            }else{
                return false;
            }
         
     }
     
     
     /**
      * This is the function that confirms the new expiry date for the document
      */
     public function isExtendedExpiryDateVerified($id,$new_expiry){
         
         $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resources',
                                  array(
                                   'document_expiry_date'=>$new_expiry,
                                   'tentative_document_new_expiry_date'=>null,   
                                   'initiate_expiry_date_extension_for_close_to_expiry_doc'=>0, 
                                   'extended_document_expiry_date_verified_by'=>Yii::app()->user->id,
                                    'verified_close_to_expiry_extension_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
     }
     
     /**
      * This is the function that gets the new expiry date for a document
      */
     public function getThisDocumentNewExpiryDate($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            return $doc['tentative_document_new_expiry_date'];
         
     }
     
      /**
      * This is the function that changes the expiry date of an expired document that is still awaiting destruction
      */
     public function actioneffectChangeOfExpiredDocumentExpiryDate(){
         
         $userid = Yii::app()->user->id;
         $id = $_POST['id'];
         $new_expiry = date("Y-m-d H:i:s", strtotime($_POST['document_expiry_date']));
         $domain_id = $this->determineAUserDomainIdGiven_old($userid);
         
         //update the resources/document table with the new expiry date
         if($this->isEffectedChangeOfExpiredDocumentExpiryDateSuccessfull($id,$new_expiry,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Expiry Date change was successfully"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Expiry document expiry change could not be effected"
                               )
                       );
         }
         
         
     }
     
     
     /**
      * This is the function that does the rejection of a new expiry date for an already expired document
      */
     public function actionrejectNewExpiryDateForExpiredDocument(){
         
          $id = $_POST['id'];
          //$domain_id = $_POST['$domain_id'];
         
         //update the resources/document table with the new expiry date
         if($this->isRejectionOfTheExpiredDocumentExpiryDateSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Rejection of this Expiry Date change was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem rejecting this Extended document Expiry Date. Date extension may not had been done"
                               )
                       );
         }
         
         
     }
     
     
     
     /**
      * This is the function that confirms if the new expiry date change is successful
      */
     public function isRejectionOfTheExpiredDocumentExpiryDateSuccessfull($id){
         
         if($this->isThisExpiredDocumentExpiryDateChanged($id)){
             if($this->isTheChangedExpiryDateRejected($id)){
                return true;
            }else{
                return false;
            }
             
             
         }else{
             return false;
         }
         
     }
     
     
     /**
      * This is the function that determines if the changed expiry date was rejected
      */
     public function isTheChangedExpiryDateRejected($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                                  array(
                                   //'document_expiry_date'=>$new_expiry,
                                   'tentative_document_new_expiry_date'=>null,   
                                   'initiate_expired_document_expiry_date_change'=>0, 
                                   'changed_expired_document_expiry_date_verified_by'=>Yii::app()->user->id,
                                   'verified_expired_document_expiry_changed_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that determines if expiry date change of an expired document is successful
      */
     public function isEffectedChangeOfExpiredDocumentExpiryDateSuccessfull($id,$new_expiry, $domain_id){
         
         if($this->isInitiatorVerifierRequired($domain_id)){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('resources',
                                  array(
                                   'tentative_document_new_expiry_date'=>$new_expiry,
                                   //'start_date'=>$today,   
                                   'initiate_expired_document_expiry_date_change'=>1, 
                                   'expired_document_expiry_date_changed_by'=>Yii::app()->user->id,
                                   'expired_document_expiry_changed_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
             
             
             
         }else{
              $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('resources',
                              array(
                                   'tentative_document_new_expiry_date'=>null,
                                   'document_expiry_date'=>$new_expiry,   
                                   'initiate_expired_document_expiry_date_change'=>0, 
                                   'expired_document_expiry_date_changed_by'=>Yii::app()->user->id,
                                    'expired_document_expiry_changed_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
             
         }
         
     }
     
         
       /**
      * This is the function that confirms the change of the expiry date of an expired but awaiting destruction document
      */
     public function actionconfirmChangeOfExpiredDocumentExpiryDate(){
         
         $id = $_POST['id'];
        // $new_expiry = $_POST['document_expiry_date'];
         
         //update the resources/document table with the new expiry date
         if($this->isConfirmationOfChangeOfThisExpiredDocumentExpiryDateSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Confirmation of this Expiry Date change was successfully"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Confirmation of this Expiry document expiry date could not be done"
                               )
                       );
         }
         
     }
     
    
     
     /**
      * This is the function that does the confirmation of the change in expired document expiry date
      */
     public function isConfirmationOfChangeOfThisExpiredDocumentExpiryDateSuccessfull($id){
         
          if($this->isThisExpiredDocumentExpiryDateChanged($id)){
            //get the document new expiry date
            $new_expiry = $this->getThisDocumentNewExpiryDate($id);
            if($this->isTheChangedExpiryDateVerified($id,$new_expiry)){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
         
     }
     
     
     /**
      * This is teh function that determines if an expired document expiry date was changed
      */
     public function isThisExpiredDocumentExpiryDateChanged($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['initiate_expired_document_expiry_date_change'] == 1){
               return true; 
            }else{
                return false;
            } 
         
     } 
     
     /**
      * This is the function that determines if the new expiry date was effected
      */
     public function isTheChangedExpiryDateVerified($id,$new_expiry){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                                  array(
                                   'document_expiry_date'=>$new_expiry,
                                   'tentative_document_new_expiry_date'=>null,   
                                   'initiate_expired_document_expiry_date_change'=>0, 
                                   'changed_expired_document_expiry_date_verified_by'=>Yii::app()->user->id,
                                   'verified_expired_document_expiry_changed_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
        /**
      * This is the function that initiates a document destruction
      */
     public function actioninitiateThisDocumentDestruction(){
         
          $id = $_POST['id'];
              
         //initiate the destruction of this document
         if($this->isInitiationOfThisDocumentDestructionSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Initiation of this Document destruction was successfully"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Initiation of this document destruction was not successful"
                               )
                       );
         }
     }
     
     
     
     /**
      * This is the function that determines if the destruction of a document is successfully initiated 
      */
      public function isInitiationOfThisDocumentDestructionSuccessfull($id){
          
          if($this->initiatorAcceptedDocumentDestruction($id)){
              return true;
          }else{
              return false;
          }
          
      }
      
      /**
       * This is the function that determines if the document destruction initiation was accepted
       */
      public function initiatorAcceptedDocumentDestruction($id){
          
          $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                                  array(
                                   'is_destruction_accepted_by_initiator'=>1,
                                   'destruction_initiator_user_id'=>Yii::app()->user->id,
                                   'destruction_initiation_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
          
      }
      
      
        /**
      * This is the function that confirms document destruction at the domain level
      */
     public function actionconfirmThisDocumentDestruction(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);    
         //confirm the destruction of this document
         if($this->isConfirmationOfThisDocumentDestructionSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Confirmation of this Document destruction was successfully"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Confirmation of this document destruction was not successful"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that confirms the initiated document destruction request
      */
     public function isConfirmationOfThisDocumentDestructionSuccessfull($id, $domain_id){
         if($this->isInitiatorVerifierRequired($domain_id)){
           if($this->isThisDocumentDestructionRequested($id)){
             if($this->isThisDestructionSuccessfullyConfirmed($id)){
                 return true;
             }else{
                 return false;
             }
             
         }else{
             return false;
         }
         }else{
             return false;
         }
         
     }
     
     
     /**
      * This is that confirms if document destruction was actually initiated
      */
     public function isThisDocumentDestructionRequested($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['is_destruction_accepted_by_initiator'] == 1){
               return true; 
            }else{
                return false;
            } 
     }
     
     
     /**
      * This is the function that confirms if destruction was successfully confirmed
      */
     public function isThisDestructionSuccessfullyConfirmed($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                                  array(
                                   'is_destruction_accepted_by_domain_verifier'=>1,
                                   'destruction_domain_verifier_user_id'=>Yii::app()->user->id,
                                   'domain_destruction_confirmation_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
         
     }
      
    /**
      * This is the function that checked the confirmed document destruction at the platform level
      */
     public function actioncheckConfirmedDocumentDestruction(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);  
         
         //confirm the destruction of this document
         if($this->isCheckedDocumentDestructionSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Checking of Document for destruction was successfully"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Checking this Document for destruction was not successful"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that checks if a document destruction instruction was enforce at the platform level
      */
     public function isCheckedDocumentDestructionSuccessfull($id,$domain_id){
         
       if($this->isDocumentNotAlreadyDestroyed($id)){
          if($this->doesPlatformSupportsCheckerVerifier()){
           if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isDocumentForDestructionSuccessfullyConfirmedAtTheDomainLevel($id)){
               if($this->isDocumentForDestructionCheckedSuccessfully($id)){
                 return true;
               }else{
                    return false;
                }
             }
             
         }else{
             if($this->isThisDocumentDestructionRequested($id)){
                 if($this->isDocumentForDestructionCheckedSuccessfully($id)){
                      return true;
                 }else{
                    return false;
                }
             }else{
                 return false;
             } 
         }
              
          }else{
              
            if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isDocumentForDestructionSuccessfullyConfirmedAtTheDomainLevel($id)){
               if($this->isDocumentCheckLeadToDestructionSuccessfully($id)){
                 return true;
               }else{
                    return false;
                }
             }
             
         }else{
             if($this->isThisDocumentDestructionRequested($id)){
                 if($this->isDocumentCheckLeadToDestructionSuccessfully($id)){
                      return true;
                 }else{
                    return false;
                }
             }else{
                 return false;
             } 
         }
          }        
         
             
       }else{
             return false;
         }
    
          
     }
     
     
     
     /**
      * This is the function that determines if a document is already destroyed
      */
     public function isDocumentNotAlreadyDestroyed($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['is_destroyed'] == 0){
                return true;
            }else{
                return false;
            }
         
     }
     
     /**
      * This is the platform that retrieves a domain id given the document id
      */
     public function getTheDomainIdOfThisDocument($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            return $doc['domain_id'];
         
     }
     
     
     /**
      * This is the function that checks the marked document for destruction
      */
     public function isDocumentForDestructionCheckedSuccessfully($id){
         
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('resources',
                                  array(
                                   'is_destruction_accepted_by_platform_checker'=>1,
                                   'destruction_platform_checker_user_id'=>Yii::app()->user->id,
                                   'platform_destruction_checked_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
 
     }
     
     /**
      * This is the function that determines if checkig a document at the platform level will lead to its final destruction
      */
     public function isDocumentCheckLeadToDestructionSuccessfully($id){
         
           $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('resources',
                                  array(
                                   'is_destroyed'=>1,
                                   'is_destruction_accepted_by_platform_checker'=>1,
                                   'destruction_platform_checker_user_id'=>Yii::app()->user->id,
                                   'platform_destruction_checked_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
     }
     
     /**
      * This is the function that determines if platform verifier is required
      */
     public function isPlatformVerifierRequired(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $settings = PlatformSettings::model()->find($criteria);
            
            if($settings['enable_platform_checker_verifier'] == 1){
               return true; 
            }else{
                return false;
            } 
         
     }
     
     
     /**
      * This is the function that determines if document for destruction is successfully confirmed at the domain level
      */
     public function isDocumentForDestructionSuccessfullyConfirmedAtTheDomainLevel($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['is_destruction_accepted_by_domain_verifier'] == 1){
               return true; 
            }else{
                return false;
            } 
         
     }
     
     
     
      /**
      * This is the function that verifies the checked documents for destruction at the platform level
      */
     public function actionverifyCheckedDocumentDestruction(){
         
         $id = $_POST['id'];
              
         //confirm the destruction of this document
         if($this->isVerifiedDocumentDestructionSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Document destruction was successfully"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Document destruction was not successful"
                               )
                       );
         }
         
     }
     
     
     
     /**
      * This is the function that determines the  success of the verification of checked document for destruction
      */
     public function isVerifiedDocumentDestructionSuccessfull($id){
         if($this->isDocumentCheckedForDestruction($id)){
             if($this->isDocumentSuccessfullyVeried($id)){
                 return true;
             }else{
                 return false;
             }
         }else{
             return false;
         }
         
     }
     
     
     
     /**
      * This is the function that determines if document is checked for destruction
      */
     public function isDocumentCheckedForDestruction($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['is_destruction_accepted_by_platform_checker'] == 1){
               return true; 
            }else{
                return false;
            } 
     }
     
     
     
     /**
      * This is the function that determines if verification of documents for destruction is successful
      */
     public function isDocumentSuccessfullyVeried($id){
         
         $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('resources',
                            array(
                                   'is_destroyed'=>1,
                                   'is_destruction_accepted_by_platform_verifier'=>1,
                                   'destruction_platform_verifier_user_id'=>Yii::app()->user->id,
                                   'platform_destruction_verified_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     /**
      * This is the function that determines if initiator verifier is required by a domain
      */
     public function isInitiatorVerifierRequired($domain_id){
         
         if($this->isDomainVerifierPermittedOnThePlatform()){
             if($this->isDomainInitiatorExemptedFromVerification($domain_id)){
                 return false;
             }else{
                 return true;
             }
             
         }else{
            return false; 
         }
     }
     
     
     
     /**
      * This is the function that determines if domains initiators should be verified
      */
     public function isDomainVerifierPermittedOnThePlatform(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $settings = PlatformSettings::model()->find($criteria);
            
            if($settings['enable_domain_initiator_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
      /**
      * This is the function that determines if domains initiators should be verified
      */
     public function isPlatformCheckerVerifierPermittedOnThePlatform(){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='id=:id';
           // $criteria->params = array(':id'=>$id);
            $settings = PlatformSettings::model()->find($criteria);
            
            if($settings['enable_platform_checker_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
     /**
      * This is the fucntion that determines if domain is exempted from having a verifier 
      */
     public function isDomainInitiatorExemptedFromVerification($id){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:id and status=:status';
            $criteria->params = array(':id'=>$id,':status'=>'active');
            $policy = DomainPolicy::model()->find($criteria);
            
            if($policy['exempt_domain_initiator_verifier']== 1){
                return true;
            }else{
                return false;
            }
         
     }
     
     
      /**
      * This is the function that that rejects documents for destruction at the domain level
      */
     public function actionrejectDestructionOfThisExpiredDocumentAtDomain(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);  
         
         //update the resources/document table with the new expiry date
         if($this->isRejectionOfTheDestructionOfExpiredDocumentAtDomainSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Rejection of this Expiry Date change was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem rejecting the destruction of this document. Destruction initiation may not had been done"
                               )
                       );
         }
         
         
     }
     
     
     /**
      * This is the function that determines if document destruction process was successful at the somain level
      */
     public function isRejectionOfTheDestructionOfExpiredDocumentAtDomainSuccessfull($id,$domain_id){
        if($this->isInitiatorVerifierRequired($domain_id)){
            
          if($this->isThisExpiredDocumentDestructionInitiated($id)){
             if($this->isTheDocumentDestructionInitiationRejected($id)){
                return true;
            }else{
                return false;
            }
             
             
         }else{
             return false;
         }
        }else{
            return false;
        } 
         
     }
     
     
     
     /**
      * This is the function that confirms if the destruction requested was ever initiated
      */
     public function isThisExpiredDocumentDestructionInitiated($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['is_destruction_accepted_by_initiator'] == 1){
               return true; 
            }else{
                return false;
            } 
         
     }
     
     
     
     /**
      * This is the function that determines if document destruction request rejection was successful
      */
     public function isTheDocumentDestructionInitiationRejected($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                                  array(
                                   //'document_expiry_date'=>$new_expiry,
                                   'is_destruction_accepted_by_initiator'=>0,   
                                   'is_destruction_accepted_by_domain_verifier'=>0, 
                                   'destruction_domain_verifier_user_id'=>Yii::app()->user->id,
                                   'domain_destruction_confirmation_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that rejects the destruction of an expired document at the checkers level
      */
     public function actionrejectDestructionOfThisExpiredDocumentAtCheckerLevel(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);
         
         //update the resources/document table with the new expiry date
         if($this->isRejectionOfTheDestructionOfExpiredDocumentAtCheckerLevelSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Rejection of this Expiry Date change was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem rejecting the destruction of this document. Document destruction domain verification may not had been done"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that determines if the document destruction process was discarded at the checker level
      */
 /**    public function isRejectionOfTheDestructionOfExpiredDocumentAtCheckerLevelSuccessfull($id,$domain_id){
         
          if($this->isDocumentNotAlreadyDestroyed($id)){
              
           if($this->isThisExpiredDocumentDestructionConfirmedAtTheDomainLevel($id,$domain_id)){
             if($this->isTheDocumentDestructionConfirmationRejected($id,$domain_id)){
                return true;
            }else{
                return false;
            }
             
             
         }else{
             return false;
         }
              
          }else{
              return false;
          }
         
         
     }
  * 
  */
     
     
     
     /**
      * This is the function that determines if the document destruction process was discarded at the checker level
      */
     public function isRejectionOfTheDestructionOfExpiredDocumentAtCheckerLevelSuccessfull($id,$domain_id){
         
       if($this->isDocumentNotAlreadyDestroyed($id)){
          if($this->doesPlatformSupportsCheckerVerifier()){
           if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isDocumentForDestructionSuccessfullyConfirmedAtTheDomainLevel($id)){
               if($this->isTheDocumentDestructionRejectedAtTheCheckingLevel($id)){
                 return true;
               }else{
                    return false;
                }
             }
             
         }else{
             if($this->isThisDocumentDestructionRequested($id)){
                 if($this->isTheDocumentDestructionRejectedAtTheCheckingLevel($id)){
                      return true;
                 }else{
                    return false;
                }
             }else{
                 return false;
             } 
         }
              
      }else{
              
         if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isDocumentForDestructionSuccessfullyConfirmedAtTheDomainLevel($id)){
               if($this->isTheDocumentDestructionRejectionTheFinal($id)){
                 return true;
               }else{
                    return false;
                }
             }
             
         }else{
             if($this->isThisDocumentDestructionRequested($id)){
                 if($this->isTheDocumentDestructionRejectionTheFinal($id)){
                      return true;
                 }else{
                    return false;
                }
             }else{
                 return false;
             } 
         }
      }        
         
             
       }else{
             return false;
         }
    
          
     }
     
     
     /**
      * This is the function that determines if documennt initiation or confirmation was done before completing the destruction process
      */
     public function isThisExpiredDocumentDestructionConfirmedAtTheDomainLevel($id, $domain_id){
         if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isThisDocumentDestructionConfirmedAtDomain($id)){
                 return true;
             }else{
                 return false;
             }
             
         }else{
             if($this->isThisExpiredDocumentDestructionInitiated($id)){
                 return true;
             }else{
                 return false;
             }
         }
     }
     
     
     
     /**
      * This is the function that will determine if destruction confirmation was done at domain level
      */
     public function isThisDocumentDestructionConfirmedAtDomain($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['is_destruction_accepted_by_domain_verifier'] == 1){
               return true; 
            }else{
                return false;
            } 
     }
     
     
     /**
      * This is the function that effects documents rejection at the checking level
      */
     public function isTheDocumentDestructionRejectedAtTheCheckingLevel($id){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resources',
                                  array(
                                   'is_destruction_accepted_by_initiator'=>0,
                                   'is_destruction_accepted_by_domain_verifier'=>0,
                                   'is_destruction_accepted_by_platform_checker'=>0, 
                                   'destruction_platform_checker_user_id'=>Yii::app()->user->id,
                                   'platform_destruction_checked_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
     
     /**
      * This is the function that ensures that eny rejection is a final step
      */
     public function isTheDocumentDestructionRejectionTheFinal($id){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resources',
                                  array(
                                   'is_destroyed'=>0,     
                                   'is_destruction_accepted_by_initiator'=>0,
                                   'is_destruction_accepted_by_domain_verifier'=>0,
                                   'is_destruction_accepted_by_platform_checker'=>0, 
                                   'destruction_platform_checker_user_id'=>Yii::app()->user->id,
                                   'platform_destruction_checked_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that determines if document destruction confirmation was rejected
      */
     public function isTheDocumentDestructionConfirmationRejected($id,$domain_id){
         if($this->isPlatformCheckerVerifierPermittedOnThePlatform()){
              $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('resources',
                                  array(
                                   //'document_expiry_date'=>$new_expiry,
                                   'is_destruction_accepted_by_platform_checker'=>0, 
                                   'destruction_platform_checker_user_id'=>Yii::app()->user->id,
                                   'platform_destruction_checked_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
             
         }else{
              $cmd =Yii::app()->db->createCommand();
              $result = $cmd->update('resources',
                              array(
                                   'is_destroyed'=>0,      
                                   'is_destruction_accepted_by_platform_checker'=>0, 
                                   'destruction_platform_checker_user_id'=>Yii::app()->user->id,
                                   'platform_destruction_checked_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         }
         
     }
     /**
      * This is the function that rejects the destruction of an expired document at the platform verifier level
      */
     public function actionrejectDestructionOfThisExpiredDocumentAtPlatformVerifierLevel(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);
         
         //update the resources/document table with the new expiry date
         if($this->isRejectionOfTheDestructionOfExpiredDocumentAtVerifierLevelSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Rejection of this Expiry Date change was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem rejecting the destruction of this document. Document destruction checking may not had been done"
                               )
                       );
         }
         
         
     }
     
     
     
     /**
      * This is the function that determines if destruction verification was successful at the platform level
      */
     public function isRejectionOfTheDestructionOfExpiredDocumentAtVerifierLevelSuccessfull($id){
         
         if($this->isThisExpiredDocumentDestructionCheckedAtThePlatformLevel($id)){
             if($this->isTheDocumentDestructionVerificationRejected($id)){
                return true;
            }else{
                return false;
            }
             
             
         }else{
             return false;
         }
         
     }
     
     
     
     /**
      * This is the function that determines if document destruction was checked at the platform level
      */
     public function isThisExpiredDocumentDestructionCheckedAtThePlatformLevel($id){
         
         if($this->isPlatformCheckerVerifierPermittedOnThePlatform()){
             
             if($this->isDocumentForDestructionChecked($id)){
                 return true;
             }else{
                 return false;
             }
             
         }else{
             return false;
         }
     }
     
     
     /**
      * This is the function that confirms if document for destruction was checked before final verification
      */
     public function isDocumentForDestructionChecked($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['is_destruction_accepted_by_platform_checker'] == 1){
               return true; 
            }else{
                return false;
            } 
         
     }
     
     
     /**
      * This is the function that will confirm if document for destruction was successfully rejected
      */
     public function isTheDocumentDestructionVerificationRejected($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                               array(
                                   'is_destroyed'=>0,
                                   'is_destruction_accepted_by_initiator'=>0,
                                   'is_destruction_accepted_by_domain_verifier'=>0,
                                   'is_destruction_accepted_by_platform_checker'=>0, 
                                   'is_destruction_accepted_by_platform_verifier'=>0, 
                                   'destruction_platform_verifier_user_id'=>Yii::app()->user->id,
                                   'platform_destruction_verified_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
     /**
      * This is the function `that initiates the removal of already destroyed document from the platform
      */
     public function actionremoveDestroyedDocumentFromThePlatform(){
         
         $id = $_POST['id'];
          //$domain_id = $_POST['$domain_id'];
         
         //update the resources/document table with the new expiry date
         if($this->isRemovalOfDestroyedDocumentSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Removal of the destroyed document was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Removal of destroyed document is not successful"
                               )
                       );
         }
         
     }
     
     
     
     /**
      * This is the function that determines if the removal of destroyed document is successful
      */
     public function isRemovalOfDestroyedDocumentSuccessfull($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                               array(
                                   'initiate_removal_of_soft_document'=>1,
                                   'removal_of_soft_document_initiated_by'=>Yii::app()->user->id,
                                   'removal_of_soft_document_initiated_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that confirms the removal of destroyed document at the branch level
      */
     public function actionconfirmTheRemovalOfDestroyedDocumentAtDomainLevel(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);
         
         //update the resources/document table with the new expiry date
         if($this->isConfirmedRemovalOfDestroyedDocumentSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Removal of the destroyed document was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Removal of destroyed document is not successful.Possibly removal was not requested"
                               )
                       );
         }
         
     }
     
     
     
     /**
      * This is the function that confirms if removal of soft document is successful
      */
     public function isConfirmedRemovalOfDestroyedDocumentSuccessfull($id,$domain_id){
         
         if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isRemovalOfDocumentInitiated($id)){
                 if($this->isDocumentRemovalConfirmationSuccessful($id)){
                      return true;
                 }else{
                     return false;
                 }
                
             }else{
                 return false;
             }
             
         }else{
             return false;
         }
         
     }
     
     
     /**
      * This is the function that determines if the removal of document is initiated
      */
     public function isRemovalOfDocumentInitiated($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['initiate_removal_of_soft_document'] == 1){
               return true; 
            }else{
                return false;
            } 
         
     }
     
     
     /**
      * This is the function that determines if the confirmation of document removal is successful
      */
     public function isDocumentRemovalConfirmationSuccessful($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                               array(
                                   'confirmed_removal_of_soft_document'=>1,
                                   'removal_of_soft_document_confirmed_by'=>Yii::app()->user->id,
                                   'removal_of_soft_document_confirmed_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
     }
     /**
      * This is the function that checks the removal of destroyed documents at platform level
      */
     public function actioncheckTheRemovalOfDestroyedDocumentAtPlatformLevel(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);
         
         //update the resources/document table with the new expiry date
         if($this->isCheckedRemovalOfDestroyedDocumentSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Removal of the destroyed document was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Removal of destroyed document is not successful. Possibly removal was not requested"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that confirms the success of checking the document for removal
      */
     public function isCheckedRemovalOfDestroyedDocumentSuccessfull($id,$domain_id){
        
         if($this->doesPlatformSupportsCheckerVerifier()){
          if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isThisDocumentRemovalConfirmedAtDomain($id)){
               if($this->isCheckedDocumentRemovalSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
             }else{
                 return false;
             }
             
         }else{
             if($this->isRemovalOfDocumentInitiated($id)){
                  if($this->isCheckedDocumentRemovalSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
             }
            
         }
             
             
         }else{
           if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isThisDocumentRemovalConfirmedAtDomain($id)){
               if($this->isCheckedDocumentLeadToFinalRemovalSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
             }else{
                 return false;
             }
             
         }else{
             if($this->isRemovalOfDocumentInitiated($id)){
                  if($this->isCheckedDocumentLeadToFinalRemovalSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
             }
            
         }
             
         }
        
         
         
         
     }
     
     
     
     /**
      * This is the function that determines if removal confirmation had been done at domain
      */
     public function isThisDocumentRemovalConfirmedAtDomain($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['confirmed_removal_of_soft_document'] == 1){
               return true; 
            }else{
                return false;
            } 
         
     }
     
     
     /**
      * This is the function that confirms if the checking of document removal was suceesful
      */
     public function isCheckedDocumentRemovalSuccessful($id){
         
         $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('resources',
                               array(
                                   'checked_confirmed_removal_of_soft_document'=>1,
                                   'removal_of_soft_document_confirmed_by'=>Yii::app()->user->id,
                                   'removal_of_soft_document_checked_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
             
         
     }
     
     
     /**
      * This is the function that invokes final removal of document at the platform checking level
      */
     public function isCheckedDocumentLeadToFinalRemovalSuccessful($id){
         
         if($this->isDeleteThisMarkedDocumentFromThePlatformSuccessful($id)){
                 return true;
             }else{
                 return false;
             }
         
     }
     
     
     
     /**
      * This is the function that verifies the removal of destroyed documents at the platform level
      */
     public function actionverifyTheRemovalOfDestroyedDocumentAtPlatformLevel(){
         
        $id = $_POST['id'];
        //$domain_id = $this->getTheDomainIdOfThisDocument($id);
         
         //update the resources/document table with the new expiry date
         if($this->isVerificationOfTheRemovalOfDestroyedDocumentSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Removal of the destroyed document was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Removal of destroyed document is not successful.Possibly removal was not requested"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that verifies the removal documents from the platform
      */
     public function isVerificationOfTheRemovalOfDestroyedDocumentSuccessfull($id){
         
          if($this->doesPlatformSupportsCheckerVerifier()){
           if($this->isDeleteThisMarkedDocumentFromThePlatformSuccessful($id)){
                 return true;
             }else{
                 return false;
             }
           
              return true;
              
          }else{
              return false;
          }
         
     }
     
     
     /**
      * This is the function that will delete the soft document from the system
      */
     public function isDeleteThisMarkedDocumentFromThePlatformSuccessful($id){
         
           $cmd =Yii::app()->db->createCommand();  
           $result = $cmd->delete('resources', 'id=:id', array(':id'=>$id));
           
           if($result>0){
               return true;
           }else{
               return false;
           }    
         
     }
     
     
     /**
      * This is the function that does the rejection of initiated document removal
      */
     public function actionrejectionOfInitiatedRemovalOfDestroyedDocument(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);
         
         //update the resources/document table with the new expiry date
         if($this->isRejectionOfTheInitatedDocumentRemovalSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Rejection of document removal was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem rejecting the removal of this document. Document removal initiation may not had been done"
                               )
                       );
         }
         
         
         
     }
     
     
     
     /**
      * This is the function that determines the success of the removal of an initiated document
      */
     public function isRejectionOfTheInitatedDocumentRemovalSuccessfull($id,$domain_id){
        
       if($this->isInitiatorVerifierRequired($domain_id)){
         if($this->isRemovalOfDocumentInitiated($id)){
               if($this->isRejectionOfInitiatedDocumentRemovalSuccessful($id)){
                 return true;
             }else{
                 return false;
             }
             
         }else{
             return false;
         }
         }else{
             return false;
         }
           
         
     }
     
     
     
     /**
      * This is the function that determines if initiated document removal was successful
      */
     public function isRejectionOfInitiatedDocumentRemovalSuccessful($id){
         
         $cmd =Yii::app()->db->createCommand();
         $result = $cmd->update('resources',
                               array(
                                   'initiate_removal_of_soft_document'=>0,
                                   'confirmed_removal_of_soft_document'=>0,
                                   'removal_of_soft_document_confirmed_by'=>Yii::app()->user->id,
                                   'removal_of_soft_document_confirmed_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     /**
      * This is the function that does the rejection of confirmed documents for removal
      */
     public function actionrejectionOfConfirmedRemovalOfDestroyedDocument(){
         
         $id = $_POST['id'];
         $domain_id = $this->getTheDomainIdOfThisDocument($id);
         
         //update the resources/document table with the new expiry date
         if($this->isRejectionOfTheDocumentRemovalAtCheckingLevelSuccessfull($id,$domain_id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Rejection of document removal was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem rejecting the removal of this document. Document removal confirmation may not had been done"
                               )
                       );
         }
     }
     
     
     
     /**
      * This is the function that determines if the rejection of the confirmed document removal was successful
      */
     public function isRejectionOfTheDocumentRemovalAtCheckingLevelSuccessfull($id,$domain_id){
         
        if($this->doesPlatformSupportsCheckerVerifier()){
          if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isThisDocumentRemovalConfirmedAtDomain($id)){
               if($this->isRejectionOfDocumentRemovalAtCheckingSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
             }else{
                 return false;
             }
             
         }else{
             if($this->isRemovalOfDocumentInitiated($id)){
                  if($this->isRejectionOfDocumentRemovalAtCheckingSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
             }
            
         }
             
             
         }else{
           if($this->isInitiatorVerifierRequired($domain_id)){
             if($this->isThisDocumentRemovalConfirmedAtDomain($id)){
               if($this->isRejectionOfDocumentRemovalAtCheckingSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
             }else{
                 return false;
             }
             
         }else{
             if($this->isRemovalOfDocumentInitiated($id)){
                  if($this->isRejectionOfDocumentRemovalAtCheckingSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
             }
            
         }
             
         }
         
     }
     
     
     /**
      * This is the function that determines if the rejection of confirmed documnt removal is successful
      */
     public function isRejectionOfDocumentRemovalAtCheckingSuccessful($id){
         
          $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resources',
                               array(
                                   'initiate_removal_of_soft_document'=>0,
                                   'confirmed_removal_of_soft_document'=>0,
                                   'checked_confirmed_removal_of_soft_document'=>0,
                                   'removal_of_soft_document_confirmed_by'=>Yii::app()->user->id,
                                   'removal_of_soft_document_checked_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
         
     }
     
     /**
      * This is the function that does the rejection of checked document for removal
      */
     public function actionrejectionOfCheckedRemovalOfDestroyedDocument(){
         
         $id = $_POST['id'];
          //$domain_id = $_POST['$domain_id'];
         
         //update the resources/document table with the new expiry date
         if($this->isRejectionOfThisDocumentRemovalAtVerificationLevelSuccessfull($id)){
            
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "msg" => "Rejection of document removal was successful"
                               )
                       );
         }else{
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            
                            "msg" => "Having problem rejecting the removal of this document. Document removal checking may not had been done"
                               )
                       );
         }
         
     }
     
     
     /**
      * This is the function that determines if document removal rejection is successful at the platform's verifier level
      */
     public function isRejectionOfThisDocumentRemovalAtVerificationLevelSuccessfull($id){
         if($this->doesPlatformSupportsCheckerVerifier()){
             if($this->isDocumentRemovalChecked($id)){
                 if($this->isRejectionOfCheckedDocumentRemovalSuccessful($id)){
                     return true;
                 }else{
                     return false;
                 }
                 
             }else{
                 return false;
             }
             
         }else{
             return false;
         }
         
     }
     
     
     /**
      * This is the function that determines if document removal is checked
      */
     public function isDocumentRemovalChecked($id){
         
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $doc = Resources::model()->find($criteria);
            
            if($doc['checked_confirmed_removal_of_soft_document'] == 1){
               return true; 
            }else{
                return false;
            } 
         
     }
     
     
     /**
      * This is the function that determines the success of the checked removal request
      */
     public function isRejectionOfCheckedDocumentRemovalSuccessful($id){
        
         $cmd =Yii::app()->db->createCommand();
          $result = $cmd->update('resources',
                               array(
                                   'initiate_removal_of_soft_document'=>0,
                                   'confirmed_removal_of_soft_document'=>0,
                                   'checked_confirmed_removal_of_soft_document'=>0,
                                   'verify_removal_of_soft_document'=>0,
                                   'removal_of_soft_document_verify_by'=>Yii::app()->user->id,
                                   'removal_of_soft_document_verified_time'=>new CDbExpression('NOW()'),
                                 
                           ),
                        ("id=$id")
			
                        );
                if($result>0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
     /**
      * This is the function that retrieves all documents in a batch or box
      */
     public function actiondocumentsinbatch(){
         
         $batch_id = $_REQUEST['id'];
         
          $criteria = new CDbCriteria();
          $criteria->select = '*';
          $criteria->condition='parent_id=:id';  
          $criteria->params = array(':id'=>$batch_id);
          $resources = Resources::model()->findAll($criteria);
               
          if($resources===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            
                            "document" => $resources)
                       );
                       
                }
         
     }
     
     
         
	/**
	 * Performs the AJAX validation.
	 * @param Resources $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='resources-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
