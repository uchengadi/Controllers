<?php

class VirtualBoxRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','AddRequestForThisVirtualBox','ModifyRequestForThisVirtualBox'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the functin tht add virtual batch request at request
         */
        public function actionAddRequestForThisVirtualBox(){
            
            $model=new VirtualBoxRequest;
            
           $user_id = Yii::app()->user->id;
            $domain_id =  $this->getTheDomainIdOfThisUser($user_id);
            $model->virtual_box_id = $_POST['virtual_box_id'];
            $model->virtual_maximum_requesting_period_in_days = $_POST['virtual_maximum_requesting_period_in_days']; 
            $model->virtual_requesting_domain_id = $domain_id;
            $model->status = strtolower($_POST['status']);
           $model->virtual_requesting_user_id = $user_id;
           if(isset($_POST['virtual_group'])){
               $model->virtual_requesting_group_id = $_POST['virtual_group'];
               $model->virtual_is_group_request = 1;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 0;
           }else if(isset($_POST['virtual_subgroup'])){
               $model->virtual_requesting_subgroup_id = $_POST['virtual_subgroup'];
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 1;
               $model->virtual_is_single_user_request = 0;
           }else{
               $model->virtual_is_group_request = 0;
               $model->virtual_is_subgroup_request = 0;
               $model->virtual_is_single_user_request = 1;
           }
           $model->virtual_request_initiation_date = new CDbExpression('NOW()');
           $model->virtual_request_initiated_by = Yii::app()->user->id;
           $model->virtual_is_request_initiated = 1;
           if(isset($_POST['virtual_is_electronic_instrument_request_included'])){
                    $model->virtual_is_electronic_instrument_request_included = $_POST['virtual_is_electronic_instrument_request_included'];
                }else{
                    $model->virtual_is_electronic_instrument_request_included = 0;
                }
           
           $box_name = $this->getThisBoxName($model->virtual_box_id);
           
            if($this->isThisRequestInConformityWithPolicy($domain_id)){
                
                if($this->thereIsNoPendingRequestOfThisBoxByThisUser($model->virtual_box_id,$model->virtual_request_initiated_by,$model->status)){
                     //initiate the request for this batch
                    if($model->save()){
                        
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "The request for '$box_name' box & folder  is successfully initiated"
                        ));
                    }else{
                         header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => "Request for the '$box_name' box & folder could not be initiated. Probably a validation error"
                        ));
                        
                    }
                    
                    
                }else{
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Request for the virtual '$box_name' box & folder could not be completed. There is an open request of same box & folder that is awaiting activation"
                        ));
                }
                
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => "Your domain policy bars you from requesting for the '$box_name' box & folder. Please contact your domain administrator"
                        ));
            }
            
            
        }
        
        
          /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$user_id);
             $domain = User::model()->find($criteria);   
             
             return $domain['domain_id'];
        }
        
        
          /**
         * This is the function that gets a batch & file title
         */
        public function getThisBoxName($id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$id);
             $box = Resourcegroup::model()->find($criteria); 
             
             return $box['name'];
            
        }
        
        
         /**
      * This is the function that determines if there is a pending request of this batch by this user
      */
     public function thereIsNoPendingRequestOfThisBoxByThisUser($box_id,$request_initiated_by, $status){
         if($this->hasThisUserMadeThisBoxRequestBefore($box_id,$request_initiated_by,$status)){
             if($this->isThereAnyOpenRequestOfThisBoxByThisUser($box_id,$request_initiated_by,$status)){
                 return false;
             }else{
                 return true;
             }
             
         }else{
             return true;
         }
         
     }
        
        
        /**
      * This is the function that determines if this user had made a similar request before
      */
     public function hasThisUserMadeThisBoxRequestBefore($box_id,$request_initiated_by, $status){
         
          $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('virtual_box_request')
                    ->where("box_id = $box_id && request_initiated_by=$request_initiated_by");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
     }
     
     
     /**
      * This is the function that determines if there is any open request of this batch by this user
      */
     public function isThereAnyOpenRequestOfThisBoxByThisUser($box_id,$request_initiated_by,$status){
         
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('virtual_box_request')
                    ->where("(box_id = $box_id && request_initiated_by=$request_initiated_by) &&(is_requested=0 && status='inactive')");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
         
         
     }
     
       /**
     * This is the function that determines if a document request is in conformity with the prevailing domain policy
     */
     public function isThisRequestInConformityWithPolicy($domain_id){
         
         return true;
     }
     
     
     
    
}
