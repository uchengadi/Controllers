<?php

class NetworkController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','ListAllPlatformNetworks'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','createNewDomainNetwork','ListAllDomainNetworks','updateDomainNetwork',
                                    'DeleteOneNetwork','ListAllOtherDomainNetworks','updatememberToDomainNetwork','addmemberToDomainNetwork',
                                    'DeleteOneNetworkMembership','ListAllDomainNetworkMembershipRequests','retrieveNetworkName','ListAllWouldBeMembersToDomainRequests',
                                    'acceptrejectmembershipnetwork','pendnetworkmembership','DeleteOneNetworkMembership','retrieveAllDomainNetworksWithPendingRequest',
                                    'retrieveNetworkAndMemberName','acceptrejectmembershipnetwork','pendnetworkmembership','ListAllDomainNetworkMembers','networkdetailinfo',
                                    'assignToolboxesToDomainNetwork','alreadyAssignedToolboxesToThisNetwork','listAllToolboxesInThisNetwork','retrieveNetworkAndToolboxName',
                                    'removeToolboxFromNetwork','addsingleToolboxToNetwork','modifyStatusOfToolboxInNetwork','removeToolboxesFromDomainNetwork',
                                    'ListAllNetworksForThisDomain','ListAllNetworksConnectedToByDomain','ListAllDomainPartners','ListAllDomainsConnectedToOwnNetworks',
                                    'ListAllmembersInThisNetwork','ListAllPlatformNetworks','ListOnlyThisDomainNetworks','ListAllDomainPartnerNetworks',
                                    'ListAllAwaitingNetworkMembershipRequest','ListAllNetworksConnectedToByDomainMembers','ListAllDomainMemberConnectedNetworks','retrieveextrainfo',
                                    'ListNetworkAllMembers','retrieveextranetworkinfo','requestnetworkmembership','ListAllConnectedNetworksForADomainMember',
                                    'ListAllNetworksConnectedToByThisMember','ListAllNetworkMessagableByThisDomainMember','RetreiveAllMembersOfANetworkGroup'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that creates new domain network 
         */
        public function actionCreateNewDomainNetwork(){
            
            $model=new Network;
            
            //logged in user id is
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            $model->name = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            };
             if(isset($_POST['purpose'])){
                $model->purpose = $_POST['purpose'];
            };
            $model->status = $_POST['status'];
            $model->domain_id = $domainid;
            $model->type = $_POST['type'];
            $model->security_level = $_POST['security_level'];
            $model->issues_and_values_id = $_POST['issues_and_values_id'];
            $model->create_user_id=$userid;
            $model->create_time = new CDbExpression('NOW()');
            
             if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = "'$model->name' Network is succesfully created by this Domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Error Creating the '$model->name' Network by this domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
            
        }
        
        
        /**
         * This is the function that list all networks belonging to a domain
         */
        public function actionListAllDomainNetworks(){
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin")|| $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformNetworkSupport") ){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='domain_id=:domainid';
                //$criteria->params = array(':domainid'=>$domainid);
                $networks = Network::model()->findAll($criteria);
                 
            if($networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $networks
                          
                           
                           
                          
                       ));
                       
                }  
                
            }else{
               $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:domainid';
                $criteria->params = array(':domainid'=>$domainid);
                $networks = Network::model()->findAll($criteria);
                 
            if($networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $networks
                          
                           
                           
                          
                       ));
                       
                } 
            }
            
            
            
        }
        
        
        /**
         * This is the function that retrieves only a domain network
         */
        public function actionListOnlyThisDomainNetworks(){
           
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
              $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:domainid';
                $criteria->params = array(':domainid'=>$domainid);
                $networks = Network::model()->findAll($criteria);
                 
            if($networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $networks
                          
                           
                           
                          
                       ));
                       
                } 
            
        }
        
        
        /**
         * This is the function that list all networks belonging to a domain
         */
        public function actionListAllPlatformNetworks(){
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                //$criteria->condition='domain_id=:domainid';
                //$criteria->params = array(':domainid'=>$domainid);
                $networks = Network::model()->findAll($criteria);
                 
            if($networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $networks
                          
                           
                           
                          
                       ));
                       
                }  
                
            
        }
        
        /**
         * This is the function that updates network's information
         */
        public function actionUpdateDomainNetwork(){
            
            
              //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            $_id = $_POST['id'];
            $model=Network::model()->findByPk($_id);
            
            $model->name = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            };
             if(isset($_POST['purpose'])){
                $model->purpose = $_POST['purpose'];
            };
            $model->status = $_POST['status'];
            $model->domain_id = $domainid;
            $model->type = $_POST['type'];
            $model->security_level = $_POST['security_level'];
            $model->issues_and_values_id = $_POST['issues_and_values_id'];
            $model->update_user_id=$userid;
            $model->update_time = new CDbExpression('NOW()');
            
             if($model->save()) {
                        // $result['success'] = 'true';
                         $msg = "'$model->name' Network is succesfully updated by this Domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                           "success" => mysql_errno() == 0,
                             "msg" => $msg)
                       );
                         
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Error Updating the '$model->name' Network by this domain";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                         
                         
                     }
            
            
            
        }
        
        /**
         * This is the function the deletes one network from a domain
         */
        public function actionDeleteOneNetwork(){
            
            $_id = $_POST['id'];
            $model=Network::model()->findByPk($_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                                      
            }else if($model->delete()){
                    $msg = 'This Network had been deleted successfully'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                       
            } else {
                    $msg = 'Validation Error: This Network was not deleted'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            //"selected" => $selected,
                            "msg" => $msg
                            //"category" =>$category,
                           
                           
                          
                       ));
                            
                }
            
            
        }
        
        /**
         * This is the function that list all other domain networks
         */
        public function actionListAllOtherDomainNetworks(){
            
             //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id!=:domainid';
            $criteria->params = array(':domainid'=>$domainid);
            $networks = Network::model()->findAll($criteria);
                 
            if($networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $networks
                          
                           
                           
                          
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that add a domain to a network
         */
        public function actionaddmemberToDomainNetwork(){
            
            $userid = Yii::app()->user->id;
            
            //the user domain is
            $domainid = $this->determineAUserDomainIdGiven($userid);
            $network_id = $_POST['network'];
             //domain name 
            $network_name = $this->determineNetworkNameGivenItId($network_id);
            $member_privilege = strtolower($_POST['member_privilege']);
            $initiator_request_status = $_POST['initiator_request_status'];
            
            if($this->memberNotAlreadyInTheNetwork($domainid,$network_id)){
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->insert('network_has_members',
                                  array('network_id'=>$network_id,
                                    'member_id'=>$domainid,
                                    'initiator_request_status'=>$initiator_request_status,
                                    'destination_request_status'=>null, 
                                    'member_privilege'=>$member_privilege, 
                                    'member_status'=>"inactive", 
                                    'network_status'=>"pending",  
                                    'create_time'=>new CDbExpression('NOW()'),
                                    'create_user_id'=>$userid
                               
		
                            )
			
                        );
            if($result > 0){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"Domain membership request to '$network_name' network is successful",
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Domain membership request to '$network_name' was not successful"
                    ));
                    } 
                
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Domain already a member of this network"
                    ));
            }
                 
            
        }

        
        /**
         * This is the function that edits network membership
         */
        public function actionupdatememberToDomainNetwork(){
           $userid = Yii::app()->user->id;
            
            //the user domain is
            $domainid = $this->determineAUserDomainIdGiven($userid);
            if(is_numeric($_POST['network'])){
                $network_id = $_POST['network'];
            }else{
                $network_id = $_POST['network_id'];
            }
             //domain name 
            $network_name = $this->determineNetworkNameGivenItId($network_id);
            $member_privilege = strtolower($_POST['member_privilege']);
            $initiator_request_status = $_POST['initiator_request_status'];
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('network_has_members',
                                  array(
                                    'initiator_request_status'=>$initiator_request_status,
                                    'destination_request_status'=>null, 
                                    'member_privilege'=>$member_privilege, 
                                    'member_status'=>"inactive", 
                                    'network_status'=>"pending",  
                                    'update_time'=>new CDbExpression('NOW()'),
                                    'update_user_id'=>$userid
                               
		
                            ),
                     ("network_id=$network_id and member_id=$domainid")
			
                        );
            if($result > 0){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"Domain membership request to '$network_name' network is updated successful",
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Domain membership request to '$network_name' was not updated"
                    ));
                    }      
            
        }
        
        /**
         * This is the function that determines the name of a network given its id
         */
        public function determineNetworkNameGivenItId($network_id){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$network_id);
            $name= Network::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that determines if a domain is already a member of a network
         */
        public function memberNotAlreadyInTheNetwork($domainid,$network_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_members')
                    ->where("network_id = $network_id && member_id =$domainid");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return false;
                }else{
                    return true;
                }
            
            
        }
        
        /**
         * This is the function that deletes a member from a network
         */
        public function actionDeleteOneNetworkMembership(){
            
            $network_id = $_POST['network_id'];
            $member_id = $_POST['member_id'];
            
            $networkname = $this->determineNetworkNameGivenItId($network_id);
            $membername = $this->determineDomainNameGivenItId($member_id);
          
            $cmd =Yii::app()->db->createCommand();  
            $result = $cmd->delete('network_has_members', 'network_id=:networkid and member_id=:memberid', array(':networkid'=>$network_id, ':memberid'=>$member_id ));
            
            if($result>0){
                
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"Domain had been removed from the '$networkname' network successfully",
                       ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Attempted removal of Domain from pending '$networkname' network was unsuccessful",
                       ));
            }
        }
        
        /**
         * This is the function that list all domain's network membership pending request
         */
        public function actionListAllDomainNetworkMembershipRequests(){
            
                //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformNetworkSupport")){
               
                //spool the partners of a domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='network_status=:status';
            $criteria->params = array(':status'=>"pending");
            $members= NetworkHasMembers::model()->findAll($criteria);
            
                if($members===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "member" => $members
                          
                           
                           
                          
                       ));
                       
                }
                
            }else{
               
                //spool the partners of a domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='member_id=:id and network_status=:status';
            $criteria->params = array(':id'=>$domainid,':status'=>"pending");
            $members= NetworkHasMembers::model()->findAll($criteria);
            
                if($members===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "member" => $members
                          
                           
                           
                          
                       ));
                       
                }
                
            }
           
            
        }
        
        /**
         * This is the function that retrieves the name of a network
         */
        public function actionretrieveNetworkName(){
            $network_id = $_REQUEST['id'];
            $networkname = $this->determineNetworkNameGivenItId($network_id);
            
            if($networkname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "networkname" => $networkname
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven_old($userid){
            
            //determine the usertype id of the user
            $typeid = $this->determineAUserUsertypeId($userid);
            //determine the usertype name of this usertypeid
            $typename = $this->determineUserTypeName($typeid);
            
            //determine the domain id given usertype name
            $domainid = $this->determineDomainIdGiveUsertypeName($typename);
            
            //determine the domain name given its id
            $name = $this->determineDomainNameGivenItId($domainid);
            //determine the domain id given its name
            $domainname = $this->determineDomainIdGivenItsName($name);
            
            return $domainname;
            
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        
              
        /**
         * this is the function that retrieves the grouptype id given domain name
         */
        public function determineGrouptypeIdGivenDomainName($domainname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$domainname);
            $grouptypeid= GroupType::model()->find($criteria);
            
            return $grouptypeid['id'];
            
            
        }
           
        /**
         * Determine a users usertype_id
         */
        public function determineAUserUsertypeId($userid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, usertype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$userid);
            $usertype= User::model()->find($criteria);
            
            return $usertype['usertype_id'];
            
            
        }
        
        /*
         * Determine a usertype name given its id
         */
        public function determineUserTypeName($usertypeid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$usertypeid);
            $name= UserType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         *  determine a usertype id given its name
         */
        public function determineUsertypeNameGiveId($usertypename){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= UserType::model()->find($criteria1);
            
            return $id['id'];
        }
        
        /*
         * Determine a domain name given a usetypername
         */
        public function determineDomainNameGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /*
         * Determine a domain id given a usetypername
         */
        public function determineDomainIdGiveUsertypeName($usertypename){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$usertypename);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * Determine a domain id given its name
         */
        public function determineDomainIdGivenItsName($name){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$name);
            $id= ResourcegroupCategory::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        /**
         * Determine a domain name given its id
         */
        public function determineDomainNameGivenItId($domainid){
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= ResourcegroupCategory::model()->find($criteria1);
            
            return $name['name'];
            
            
        }
        
        /**
         * This is the function that retrieves a resource/tool id given its name
         */
        public function determineResourceOrToolId($toolname){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='name=:name';
            $criteria1->params = array(':name'=>$toolname);
            $id= Resources::model()->find($criteria1);
            
            return $id['id'];
            
        }
        
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineResourceOrToolName($toolid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$toolid);
            $name= Resources::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that retrieves a resource/tool name given its id
         */
        public function determineGrouptypeGivenDomainId($domainid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = 'id, name';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$domainid);
            $name= GroupType::model()->find($criteria1);
            
            return $name['name'];
            
        }
        
        /**
         * This is the function the retrieves a group id given the group name
         */
        public function determineGroupIdGivenGroupName($groupname,$domainid){
            
            //obtain the grouptype id given a domain id
            $grouptype_id = $this->determineGrouptypeIdGivenDomainId($domainid);
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name and grouptype_id=:id';
            $criteria->params = array(':name'=>$groupname, ':id'=>$grouptype_id);
            $id= Group::model()->find($criteria);
            
            return $id['id'];
            
            
        }
        
        /**
         * This is the function to retrieve subgroup id given subgroup name
         */
        public function determineSubgroupIdGivenSubgroupName($subgroupname, $domainid){
            //determine the group for this subgroup            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, group_id';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$subgroupname);
            $groups= SubGroup::model()->findAll($criteria);
            
            foreach($groups as $group){
                $groupdomainid = $this->determineDomainIdGivenGroupId($group['group_id']);
                if($groupdomainid == $domainid){
                    $criteria1 = new CDbCriteria();
                    $criteria1->select = 'id, name';
                    $criteria1->condition='name=:name';
                    $criteria1->params = array(':name'=>$subgroupname);
                    $id= SubGroup::model()->find($criteria1);
                    
                     return $id['id'];
                    
                }
                
                
            }
            
           
            
        }
        
        /**
         * This is the function that determines grouptype is given domain id
         */
        public function determineGrouptypeIdGivenDomainId($domainid){
            
            //determine domain name
            $domainname = $this->determineDomainNameGivenItId($domainid);
            //Determine grouptype id given domain name
            $grouptypeid = $this->determineGrouptypeIdGivenDomainName($domainname);
            
            return $grouptypeid;
            
        }
        
        
        /**
         * This is the function that determines domain id given group id
         */
        public function determineDomainIdGivenGroupId($groupid){
            //determine grouptype id given group id
            $grouptypeid = $this->determineGrouptypeIdGivenGroupId($groupid);
            //determine domain id given grouptype id
            $domainid = $this->determineDomainIdGivenGrouptypeId($grouptypeid);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines the grouptypeid given group id
         */
        public function determineGrouptypeIdGivenGroupId($groupid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name, grouptype_id';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$groupid);
            $type= Group::model()->find($criteria);
            
            return $type['grouptype_id'];
            
        }
        
        /**
         * This is the function that returns domain id given grouptype id
         */
        public function determineDomainIdGivenGrouptypeId($grouptypeid){
            
            //determine the grouptype name
            $typename = $this->determineGrouptypeNameGivenGrouptypeId($grouptypeid);
            
            $domainname = $this->determineDomainNameGivenGrouptypeName($typename);
           
            //determine domain id given its id
            $domainid = $this->determineDomainIdGivenItsName($domainname);
            
            return $domainid;
            
            
        }
        
        /**
         * This is the function that determines grouptype name given its id
         **/
        public function determineGrouptypeNameGivenGrouptypeId($typeid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$typeid);
            $type= GroupType::model()->find($criteria);
            
            return $type['name'];
            
        }
        
        /**
         * This is the function that determines domain name given grouptype name
         */
        public function determineDomainNameGivenGrouptypeName($typename){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$typename);
            $domain= ResourcegroupCategory::model()->find($criteria);
            
            return $domain['name'];
            
        }
        
        /**
         * This is the function that obtains a toolbox name given its id 
         */
        public function determineToolboxNameGivenItsId($toolboxid){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolboxid);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['name'];
            
        }
        
        
        /**
         * This is the function that obtains a toolbox id given its name
         */
        public function determineToolboxIdGivenItsName($toolboxname){
            
            $criteria = new CDbCriteria();
            $criteria->select = 'id, name';
            $criteria->condition='name=:name';
            $criteria->params = array(':name'=>$toolboxname);
            $toolbox= Resourcegroup::model()->find($criteria);
            
            return $toolbox['id'];
            
        }
        
        /**
         * This is the function that list all would-be network request from other domains
         */
        public function actionListAllWouldBeMembersToDomainRequests(){
            
               //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            //determine the domain of the logged in user
            $domainid = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformNetworkSupport")){
                
            
                //spool the partners of a domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(network_status=:dest) and (destination_request_status is null or destination_request_status=:request )';
                $criteria->params = array(':dest'=>"pending", ':request'=>"pending");
                $new_members= NetworkHasMembers::model()->findAll($criteria);
                
              
                if($new_members===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "member" =>$new_members
                          
                           
                           
                          
                       ));
                       
                }
                
            }else{
                
                //retrieve all the networks with pending request that belongs to this domain
            $domain_networks = $this->retrieveAllDomainNetworksWithPendingRequest($domainid);
                    
            //get the detail information of those networks as relates to membership
            
            $new_members = [];
            foreach($domain_networks as $network){
            
                //spool the partners of a domain
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(network_id=:id and network_status=:dest) and (destination_request_status is null or destination_request_status=:request )';
                $criteria->params = array(':id'=>$network,':dest'=>"pending", ':request'=>"pending");
                $networks= NetworkHasMembers::model()->findAll($criteria);
                
                $new_members = array_merge($new_members,$networks);
            
             }
            
           
            
                if($new_members===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "member" =>$new_members
                          
                           
                           
                          
                       ));
                       
                }
                
            }
            
            
        }
        
        /**
         * This is the function that retrieves all domains network in a membership
         */
        public function retrieveAllDomainNetworksWithPendingRequest($domainid=1){
            
            //spool all networks in the membership table
            $criteria = new CDbCriteria();
            $criteria->select = '*';
           // $criteria->condition='(member_id !=:id and network_status=:dest) and (destination_request_status=:request or destination_request_status=:request2 )';
            $criteria->condition='(member_id!=:member and network_status=:dest)and (destination_request_status=:request or destination_request_status is null)';
            $criteria->params = array(':member'=>$domainid,':dest'=>"pending",':request'=>"pending");
            $networks= NetworkHasMembers::model()->findAll($criteria);
            
            $own = [];
            foreach($networks as $network){
                if($this->isDomainsNetwork($domainid,$network['network_id'])){
                    $own[] = $network['network_id'];
                }
            }
            $own = array_unique($own);
           return $own;
        }
        
        /**
         * This is the function that determines if network belongs to a domain
         */
        public function isDomainsNetwork($domainid,$network_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network')
                    ->where("id = $network_id && domain_id =$domainid");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        /**
         * This is the function that retrieves both the network and the member names
         */
        public function actionretrieveNetworkAndMemberName(){
            
            $network_id = $_REQUEST['network_id'];
            $member_id = $_REQUEST['member_id'];
            //determine network name
            $networkname = $this->determineNetworkNameGivenItId($network_id);
            
            //determine domain name
            
            $domainname = $this->determineDomainNameGivenItId($member_id);
            
            if($networkname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "networkname" => $networkname,
                           "membername" => $domainname
                          
                           
                           
                          
                       ));
                       
                }
            
            
        }
        
        /**
         * This is the function that accepts or rejects a would-be network member
         */
        public function actionacceptrejectmembershipnetwork(){
            
            $userid = Yii::app()->user->id;
            
            //the user domain is
            //$domainid = $this->determineAUserDomainIdGiven($userid);
            
           $member_id = $_POST['member_id'];  
           $network_id = $_POST['network_id']; 
             //domain and partner name 
            $domain_name = $this->determineDomainNameGivenItId($member_id);
            $network_name = $this->determineNetworkNameGivenItId($network_id);
            
            $member_privilege = strtolower($_POST['member_privilege']);
            $destination_request_status = $_POST['destination_request_status'];
            if($destination_request_status == "accepted"){
                $network_status = "accepted";
                $member_status = "active";
            }elseif($destination_request_status == "rejected"){
                $network_status = "rejected";
                $member_status = "terminated";
            }
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('network_has_members',
                                  array(
                                    'destination_request_status'=>$destination_request_status, 
                                    'network_status'=>$network_status,
                                    'member_privilege'=>$member_privilege,  
                                    'member_status'=>$member_status,
                                    'update_time'=>new CDbExpression('NOW()'),
                                    'update_user_id'=>$userid
                               
		
                            ),
                    ("member_id=$member_id and network_id=$network_id") 
			
                        );
            if($result > 0){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"'$network_name' network membership request is accepted/rejected",
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"'$network_name' network membership request is not accepted/rejected"
                    ));
                    }   
            
            
        }
        
        /**
         * This is the function to pend a would-be network membership request
         */
        public function actionpendnetworkmembership(){
            
            $userid = Yii::app()->user->id;
            
            //the user domain is
            //$domainid = $this->determineAUserDomainIdGiven($userid);
            
           $member_id = $_POST['member_id'];  
           $network_id = $_POST['network_id']; 
             //domain and partner name 
            $domain_name = $this->determineDomainNameGivenItId($member_id);
            $network_name = $this->determineNetworkNameGivenItId($network_id);
            
            $member_privilege = strtolower($_POST['member_privilege']);
            
            if(isset($_POST['destination_request_status'])){
               $destination_request_status = $_POST['destination_request_status'];
                
            }else{
                $destination_request_status = null;
            }
             if($destination_request_status == "pending"){
                $network_status = "pending";
                $member_status = "inactive";
                
                $cmd =Yii::app()->db->createCommand();
               $result = $cmd->update('network_has_members',
                                  array(
                                    'destination_request_status'=>$destination_request_status, 
                                    'network_status'=>$network_status,
                                    'member_privilege'=>$member_privilege,  
                                    'member_status'=>$member_status,
                                    'update_time'=>new CDbExpression('NOW()'),
                                    'update_user_id'=>$userid
                               
		
                            ),
                    ("network_id=$network_id and member_id=$member_id") 
			
                        );
            if($result > 0){
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"'$network_name' network membership request is pended for further review",
                       ));
                    
                    }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"'$network_name' network membership request is not pended as required"
                    ));
                    } 
            }else{
               //remove from the view of the active domain 
                $result = $this->deleteThisWouldBeMembership($member_id, $network_id);
                    if($result>0){
                
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"$network_name network membership request processing is discontinued",
                       ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"$network_name network membership request processing is faulty",
                       ));
            }
                    
                
            }
            
        }
        
        /**
         * This is the function that list all domain network members
         */
        public function actionListAllDomainNetworkMembers(){
            
               //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            
            if($this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformAdmin") || $this->determineIfAUserHasThisPrivilegeAssigned($userid, "platformNetworkSupport")){
                
                //spool all active,inactive or suspended partnerships with this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='member_id=:id and (network_status=:request and member_status!=:status)';
            //$criteria->params = array(':id'=>$domain_id,':status'=>"terminated",':request'=>"accepted");
            $members = NetworkHasMembers::model()->findAll($criteria);
            
                       
            if($members===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "member" => $members
                          
                           
                           
                          
                       ));
                       
                }
                
            }else{
               
                //spool all active,inactive or suspended partnerships with this domain
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='member_id=:id and (network_status=:request and member_status!=:status)';
            $criteria->params = array(':id'=>$domain_id,':status'=>"terminated",':request'=>"accepted");
            $members = NetworkHasMembers::model()->findAll($criteria);
            
                       
            if($members===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "member" => $members
                          
                           
                           
                          
                       ));
                       
                }
                
            }
           
        }
        
        
        /**
         * This is th function that deletes a would be membership
         */
        public function deleteThisWouldBeMembership($member_id, $network_id){
            
            $cmd =Yii::app()->db->createCommand();  
            $result = $cmd->delete('network_has_members', 'member_id=:memberid and network_id=:networkid', array(':memberid'=>$member_id, ':networkid'=>$network_id ));
            
            return $result;
            
            
        }
        
        /**
         * This is the function that retrieves the details of a network
         */
        public function actionnetworkdetailinfo(){
            
            $network_id = $_REQUEST['network_id'];
           
            $userid = Yii::app()->user->id;
            
            //get the logged in user domain
            //$domainid = $this->determineAUserDomainIdGiven($userid);
            
            //get the domain id of the network owner
            $domainid = $this->getThisNetworkDomain($network_id);
                           
                //get the network 0wner 
                $network_owner = $this->determineTheDomainThatOwnsTheNetwork($network_id);
                //get the total networks owned by this domain
                $domain_networks = $this->totalDomainNetworks($domainid);
                //get the total toolboxes in this domain
                $network_toolboxes = $this->totalNetworkToolboxes($network_id);
                
                //get the total number of domains connected to this networks
                $connected_domains = $this->totalDomainsConnectedToNetwork($network_id);
                //get the operating country of the domain that owns the network
                $operating_country = $this->determineTheOperatingCountryOfTheOwnerOfThisNetwork($domainid);
              
                //retreive all the information about the network
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$network_id);
               $networks= Network::model()->findAll($criteria);
            
                if($networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $networks,
                            "owner" => $network_owner,
                            "network_toolboxes" => $network_toolboxes,
                            "domain_networks" => $domain_networks,
                            "connected_domains" => $connected_domains,
                            "operating_country" => $operating_country,
                          
                       
                       ));
                    
                }
            
        }
        
        
        /**
         * This is the function that gets the domain owner of a network
         */
        public function getThisNetworkDomain($id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $network= Network::model()->find($criteria);
               
               return $network['domain_id'];
        }
        
        /**
         * This is the function that determines the domain that owns the network
         */
        public function determineTheDomainThatOwnsTheNetwork($network_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$network_id);
               $network= Network::model()->find($criteria);
            
               //get the domain name
               $domainname = $this->determineDomainNameGivenItId($network['domain_id']);
               
               return $domainname;
            
            
        }
        
        /**
         * This is the function that determines the total toolboxes in a network
         */
        public function totalNetworkToolboxes($network_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_toolboxes')
                    ->where("network_id = $network_id");
                $result = $cmd->queryScalar();
                
               return $result;
            
            
        }
        
        /**
         * This is the function that determines the total networks own by this domain
         */
        public function totalDomainNetworks($domain_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network')
                    ->where("domain_id = $domain_id");
                $result = $cmd->queryScalar();
                
               return $result;
        }
        
        
        /**
         * This is the function that determines the domains in the networks membership
         */
        public function totalDomainsConnectedToNetwork($network_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_members')
                    ->where("network_id = $network_id");
                $result = $cmd->queryScalar();
                
               return $result;
            
        }
        
        /**
         * This is the function that determines the operating country of the domain that owns the network
         */
        public function determineTheOperatingCountryOfTheOwnerOfThisNetwork($domain_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$domain_id);
               $country= ResourceGroupCategory::model()->find($criteria); 
               
               return ($this->getTheCountryNameGivenItsId($country['country_id']));
            
        }
        
        /**
         * This is the function that gets a country name given its id
         */
        public function getTheCountryNameGivenItsId($id){
            
            $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$id);
               $country= Country::model()->find($criteria); 
               
               return $country['name'];
            
            
        }
        
        
        
        
        /**
         * This is the function that assigns selected toolboxes to a network
         */
        public function actionassignToolboxesToDomainNetwork(){
            $network_id = $_POST['network_id'];
            //$network_id = 1;
            //logged in user is
            $userid = Yii::app()->user->id;
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            $network_name = $this->determineNetworkNameGivenItId($network_id);
            $toolboxes = [];
            $discarded_toolboxes= [];
            $result_count = 0;
            $existing_result_count = 0;
            if(isset($_POST['toolbox'])){
                if(is_array($_POST['toolbox'])){
                    //spool all the toolboxes already assigned to this toolbox
                    $existing_toolboxes = $this->alreadyAssignedToolboxesToThisNetwork($network_id);
                    $selected_toolboxes = [];
                    foreach($_POST['toolbox'] as $toolbox_id){
                        
                        $selected_toolboxes[] = $toolbox_id;
                        
                    }   
                    //get the array difference
                    $discarded_toolboxes = array_diff($existing_toolboxes,$selected_toolboxes);
                    
                    //delete all the toolboxes in $discarded_toolboxes array
                    foreach($discarded_toolboxes as $discarded){
                        
                        $this->removeThisToolboxFromThisNetwork($discarded, $network_id);
                    }
                   
                    //get the additional toolboxes that is included
                    $new_toolboxes  = [];
                    $new_toolboxes = array_diff($selected_toolboxes,$existing_toolboxes);
                    
                   //assign the remaining toolboxes to the network
                    foreach($_POST['toolbox'] as $toolbox_id){
                        if(in_array($toolbox_id,$existing_toolboxes)){
                           $existing_result_count = $existing_result_count + 1; 
                            continue;
                        }else{
                            $result_count = $result_count + 1;
                            $cmd =Yii::app()->db->createCommand();
                            $cmd->insert('network_has_toolboxes',
                                  array('network_id'=>$network_id,
                                    'toolbox_id'=>$toolbox_id,
                                    'initiator_request_status'=>"accepted",
                                    'destination_request_status'=>"accepted", 
                                    'status'=>"active", 
                                    'domain_id'=>$domain_id,
                                    'toolbox_request_status'=>"accepted", 
                                    'create_time'=>new CDbExpression('NOW()'),
                                    'create_user_id'=>$userid
                               
		
                            )
			
                            );
                        }
                         
                    }
                 if($result_count > 0 or $existing_result_count > 0 ){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"$result_count new and $existing_result_count existing reserved folders had been assigned to $network_name network",
                       ));
                    
                 }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"'Assignment of folders to $network_name was not successful"
                    ));
                    }   
                    
                    
                }
                    
               
            }else{
              header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"You must select folder(s) for this assignment to be effected",
                       ));  
                
            }
            
            
            
        }
        
        /**
         * This is the function that removes bulk toolboxes from another domains network
         */
        public function actionremoveToolboxesFromDomainNetwork(){
            
            $network_id = $_POST['network_id'];
            //$network_id = 1;
            //logged in user is
            $userid = Yii::app()->user->id;
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            $network_name = $this->determineNetworkNameGivenItId($network_id);
            $toolboxes = [];
            $discarded_toolboxes= [];
            $result_count = 0;
            $existing_result_count = 0;
            //get all the existing toolboxes in this network
            $existing_toolboxes = $this->alreadyAssignedToolboxesToThisNetworkByThisDomain($network_id,$domain_id);
            if(isset($_POST['toolbox'])){
                if(is_array($_POST['toolbox'])){
                    
                    //spool all the toolboxes already assigned to this toolbox
                    $selected_toolboxes = [];
                    foreach($_POST['toolbox'] as $toolbox_id){
                        
                        $selected_toolboxes[] = $toolbox_id;
                        
                    }   
                    //get the array difference
                    $discarded_toolboxes = array_diff($existing_toolboxes,$selected_toolboxes);
                    
                    //delete all the toolboxes in $discarded_toolboxes array
                    foreach($discarded_toolboxes as $discarded){
                        
                        $result = $this->removeThisToolboxFromThisNetwork($discarded, $network_id);
                        $result_count = $result_count + $result;
                    }
                   
                 if($result_count > 0 ){
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"$result_count reserved folder(s) had been removed from '$network_name' network",
                       ));
                    
                 }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Removal of folders from '$network_name' network was not successful"
                    ));
                    }   
                    
                    
                }
                    
               
            }else{
              //spool all the toolboxes from this domain in this network
              $domain_toolboxes = $this->retrieveAllToolboxesFromThisDomainInThisNetwork($network_id,$domain_id);  
              if($domain_toolboxes !== [" "]){
                  $discarded_toolboxes = array_diff($existing_toolboxes,$domain_toolboxes);
                   if($discarded_toolboxes == []){
                      foreach($existing_toolboxes as $toolbox){
                        $result = $this->removeThisToolboxFromThisNetwork($toolbox, $network_id);
                        $result_count = $result_count + $result;
                      }
                       if($result_count > 0 ){
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"$result_count reserved folder(s) had been removed from '$network_name' network",
                       ));
                      
                    }else{
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Removal of folders from '$network_name' network was not successful",
                           )); 
                  }
                  
                    
                 }else{
                    foreach($discarded_toolboxes as $discarded){
                        
                        $result = $this->removeThisToolboxFromThisNetwork($discarded, $network_id);
                        $result_count = $result_count + $result;
                    }
                     
                     if($result_count > 0 ){
                        header('Content-Type: application/json');
                         echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"$result_count reserved folder(s) had been removed from '$network_name' network",
                       ));
                      
                    }else{
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Removal of folders from '$network_name' network was not successful",
                           )); 
                  }
                  
                    }    
                   
              }else{
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is no folder to remove",
                       ));   
              } 
              
            
                 
                 
                  
          
            }
        }
        
        
        /**
         * This is the function that retrieves all toolboxes from this domain in another domain's network
         */
        public function retrieveAllToolboxesFromThisDomainInThisNetwork($network_id,$domain_id){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='network_id=:id and domain_id=:domainid';
               $criteria->params = array(':id'=>$network_id,':domainid'=>$domain_id);
               $toolboxes= NetworkHasToolboxes::model()->findAll($criteria); 
               
               $alltoolboxes = [];
               foreach($toolboxes as $toolbox){
                   $alltoolboxes[] = $toolbox['toolbox_id'];
               }
               
               return $alltoolboxes;
            
            
        }
        
        
        /**
         * This is the function that confirms if a toolbox is already a member of a network
         */
        public function isToolboxAlreadyAssignedToThisNetwork($network_id,$toolbox_id){
            
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('network_has_toolboxes')
                    ->where("network_id = $network_id && toolbox_id =$toolbox_id");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return false;
                }else{
                    return true;
                }
            
            
        }
        
        /**
         * This is the function that spools the already assigned toolboxes to a network
         */
        public function alreadyAssignedToolboxesToThisNetwork($network_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='network_id=:id';
               $criteria->params = array(':id'=>$network_id);
               $toolboxes= NetworkHasToolboxes::model()->findAll($criteria); 
               
               $alltoolboxes = [];
               foreach($toolboxes as $toolbox){
                   $alltoolboxes[] = $toolbox['toolbox_id'];
               }
               
               return $alltoolboxes;
             
        }
        
        /**
         * This is the function that spools the already assigned toolboxes to a network
         */
        public function alreadyAssignedToolboxesToThisNetworkByThisDomain($network_id,$domain_id){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='network_id=:id and domain_id=:domainid';
               $criteria->params = array(':id'=>$network_id,':domainid'=>$domain_id);
               $toolboxes= NetworkHasToolboxes::model()->findAll($criteria); 
               
               $alltoolboxes = [];
               foreach($toolboxes as $toolbox){
                   $alltoolboxes[] = $toolbox['toolbox_id'];
               }
               
               return $alltoolboxes;
             
        }
        
        /*8
         * This is the function that removes a toolbox from a network
         */
        public function removeThisToolboxFromThisNetwork($toolbox_id, $network_id){
            
            $cmd =Yii::app()->db->createCommand();  
            $result = $cmd->delete('network_has_toolboxes', 'network_id=:networkid and toolbox_id=:toolboxid', array(':networkid'=>$network_id, ':toolboxid'=>$toolbox_id ));
            
            return $result;
            
            
        }
        
        
        /**
         * This is the function that retrieves all the toolboxes assigned to a toolbox
         */
        public function actionlistAllToolboxesInThisNetwork(){
            
            $network_id = $_REQUEST['id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='network_id=:id';
            $criteria->params = array(':id'=>$network_id);
            $toolboxes= NetworkHasToolboxes::model()->findAll($criteria);  
            
            if($toolboxes===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $toolboxes,
                           
                       ));
                    
                }
            
        }
        
        /**
         * This is the function that retrieves both the network name and the toolbox name from the database
         */
        public function retrieveNetworkAndToolboxName(){
            
            $network_id = $_REQUEST['network_id'];
            $toolbox_id = $_REQUEST['toolbox_id'];
            
            $networkname = $this->determineNetworkNameGivenItId($network_id);
            $toolboxname = $this->determineToolboxNameGivenItId($toolbox_id);
            
            if($networkname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "networkname" => $networkname,
                           "toolboxname" => $toolboxname
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves a toolbox name
         */
        public function determineToolboxNameGivenItId($toolbox_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$toolbox_id);
            $name= Resourcegroup::model()->find($criteria);  
            
            return $name['name'];
            
        }
        
        /**
         * This is the function that removes a toolbox from a network
         */
        public function actionremoveToolboxFromNetwork(){
           $network_id = $_REQUEST['network_id'];
           $toolbox_id = $_REQUEST['toolbox_id']; 
           
           $networkname = $this->determineNetworkNameGivenItId($network_id);
            $toolboxname = $this->determineToolboxNameGivenItId($toolbox_id);
            
           $result = $this->deleteThisToolboxFromThisNetwork($toolbox_id, $network_id);
           
           if($result>0){
                
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"'$toolboxname' had been removed from the '$networkname' network successfully",
                       ));
            }else{
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"Attempted removal of '$toolboxname' from '$networkname' network was unsuccessful",
                       ));
            }
            
            
            
        }
        
         /**
         * This is th function that deletes a toolbox from a network
         */
        public function deleteThisToolboxFromThisNetwork($toolbox_id, $network_id){
            
            $cmd =Yii::app()->db->createCommand();  
            $result = $cmd->delete('network_has_toolboxes', 'toolbox_id=:toolboxid and network_id=:networkid', array(':toolboxid'=>$toolbox_id, ':networkid'=>$network_id ));
            
            return $result;
            
            
        }
        
        /**
         * This is the function that assigns a single toolbox to a network
         */
        public function actionaddsingleToolboxToNetwork(){
            
            $network_id = $_POST['id'];
            $toolbox_id = $_POST['toolbox'];
            
            $userid = Yii::app()->user->id;
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            //get the names
            $existing_toolboxes = [];
            $networkname = $this->determineNetworkNameGivenItId($network_id);
            $toolboxname = $this->determineToolboxNameGivenItId($toolbox_id);
            //obtain the existing toolboxes in the network if any
            $existing_toolboxes = $this->alreadyAssignedToolboxesToThisNetwork($network_id);
            
            if(in_array($toolbox_id,$existing_toolboxes)){
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"'$toolboxname' folder is already assigned to '$networkname' network"
                    ));
                       
                
            }else{
                $cmd =Yii::app()->db->createCommand();
                   $result = $cmd->insert('network_has_toolboxes',
                                  array('network_id'=>$network_id,
                                    'toolbox_id'=>$toolbox_id,
                                    'initiator_request_status'=>"accepted",
                                    'destination_request_status'=>"accepted", 
                                    'status'=>"active", 
                                    'domain_id'=>$domain_id,
                                    'toolbox_request_status'=>"accepted", 
                                    'create_time'=>new CDbExpression('NOW()'),
                                    'create_user_id'=>$userid
                               
		
                            )
			
                            );
                   
                   if($result>0){
                      header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"'$toolboxname' folder is successfully added to '$networkname' network",
                       ));
                    
                 }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"'Assignment of '$toolboxname' folder to '$networkname' network was not successful"
                    ));
                    }    
                   
                
            }
            
            
            
            
        }
        
        /**
         * This is the function that modifies the status of a toolbox in a network
         */
        public function actionmodifyStatusOfToolboxInNetwork(){
            
           $network_id = $_POST['network_id'];
            $toolbox_id = $_POST['toolbox_id'];
            
            $userid = Yii::app()->user->id;
            $domain_id = $this->determineAUserDomainIdGiven($userid);
            //get the names
            $existing_toolboxes = [];
            $networkname = $this->determineNetworkNameGivenItId($network_id);
            $toolboxname = $this->determineToolboxNameGivenItId($toolbox_id); 
            $status = $_POST['status'];
            $cmd =Yii::app()->db->createCommand();
                   $result = $cmd->update('network_has_toolboxes',
                                  array(
                                    'initiator_request_status'=>"accepted",
                                    'destination_request_status'=>"accepted", 
                                    'status'=>$_POST['status'], 
                                    'domain_id'=>$domain_id,
                                    'toolbox_request_status'=>"accepted", 
                                    'update_time'=>new CDbExpression('NOW()'),
                                    'update_user_id'=>$userid
                               
		
                            ),
                           ("network_id=$network_id and toolbox_id=$toolbox_id")
			
                            );
                   
                   if($result>0){
                      header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                           "msg" =>"The status of '$toolboxname' folder in '$networkname' network is now $status ",
                       ));
                    
                 }else{
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"The status of '$toolboxname' folder in '$networkname' network was not modified"
                    ));
                    }
            
            
        }
        
        /**
         * This is the function that retrieves the toolbox and network name from the server
         */
        public function actionretrieveNetworkAndToolboxName(){
            
             $network_id = $_REQUEST['network_id'];
            $toolbox_id = $_REQUEST['toolbox_id'];
            //determine network name
            $networkname = $this->determineNetworkNameGivenItId($network_id);
            
            //determine domain name
            
            $toolboxname = $this->determineToolboxNameGivenItId($toolbox_id);
            
            if($networkname===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "networkname" => $networkname,
                           "toolboxname" => $toolboxname
                          
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves all networks belonging to a particular domain
         */
        public function actionListAllNetworksForThisDomain(){
            
               //obtain the id of the logged in user
            $userid = Yii::app()->user->id;
            
            $domainid = $_REQUEST['id'];
            
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='domain_id=:domainid';
            $criteria->params = array(':domainid'=>$domainid);
            $networks = Network::model()->findAll($criteria);
                 
            if($networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $networks
                          
                           
                           
                          
                       ));
                       
                }
            
            
        }
        
        /**
         * This is the function that retrieves all the networks connected to by a domain
         */
        public function actionListAllNetworksConnectedToByDomain(){
               
            //retrieve all networks connected to by this domain
            
           $domain_id = $_REQUEST['id'];
             //$domain_id = 2;
            $networks = $this->retrieveAllNetworksConnectedToByThisDomain($domain_id);
            $allnetworks = [];
            foreach($networks as $network){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$network);
               $connected_network= Network::model()->find($criteria);
               $allnetworks[] = $connected_network;
                
            }
            
            if($allnetworks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $allnetworks
                          
                           
                           
                          
                       ));
                       
                }
            
            
            
        }
        
        /**
         * This is the function that retrieves the networks that a domain connectes to
         */
        public function retrieveAllNetworksConnectedToByThisDomain($domain_id){
            $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='member_id=:id';
               $criteria->params = array(':id'=>$domain_id);
               $networks= NetworkHasMembers::model()->findAll($criteria);
               
               $allnetworks = [];
               foreach($networks as $network){
                   $allnetworks[] =$network['network_id'];
               }
            return $allnetworks;
        }
        
        /**
         * This is the function that list all domains connected to domain networks
         */
        public function actionListAllDomainsConnectedToOwnNetworks(){
            
            //retrieve all domain connected to this domain networks
            
            $domain_id = $_REQUEST['id'];
             //$domain_id = 2;
            $domain_networks = $this->retrieveAllDomainNetworksForThisDomain($domain_id);
            //get all the members connected to each of this networks
            $allmembers = [];
            $network_members = [];
            foreach($domain_networks as $network){
                //get the members for this domain
                $network_members = $this->retrieveThisNetworkMembers($network);
                foreach($network_members as $member){
                    if(in_array($member,$allmembers)){
                        continue;
                    }else{
                         $allmembers[] = $member;  
                    }
                   
                }
               
            }
            //retrieve the detail of this members
            $alldomains = [];
            foreach($allmembers as $dismember){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$dismember);
               $domains= ResourceGroupCategory::model()->find($criteria);
               $alldomains[] = $domains;
                
            }
            
            if($alldomains===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "domain" => $alldomains,
                           "networks"=>$domain_networks
                          
                           
                           
                          
                       ));
                       
                }
            
            
            
            
        }
        
        /**
         * This is the function that retrieves a domain's network
         */
        public function retrieveAllDomainNetworksForThisDomain($domain_id){
            $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='domain_id=:id';
               $criteria->params = array(':id'=>$domain_id);
               $networks= Network::model()->findAll($criteria);
               
               $allnetworks = [];
               foreach($networks as $network){
                   $allnetworks[] = $network['id'];
               }
               return $allnetworks;
            
        }
        
        /**
         * This is the function that retrieves this network members
         */
        public function retrieveThisNetworkMembers($network){
            
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='network_id=:id';
               $criteria->params = array(':id'=>$network);
               $members= NetworkHasMembers::model()->findAll($criteria);
               
               $allmembers = [];
               foreach($members as $member){
                   
                   $allmembers[] = $member['member_id'];
               }
            
               return $allmembers;
        }
        
        /**
         * This is the function that list all members in a network
         */
        public function actionListAllmembersInThisNetwork(){
            
             //retrieve all networks connected to by this domain
            
           $network_id = $_REQUEST['id'];
             //$domain_id = 2;
            $members = $this->retrieveThisNetworkMembers($network_id);
            $allmembers = [];
            foreach($members as $member){
               $criteria = new CDbCriteria();
               $criteria->select = '*';
               $criteria->condition='id=:id';
               $criteria->params = array(':id'=>$member);
               $network_members= ResourceGroupCategory::model()->find($criteria);
               $allmembers[] = $network_members;
                
            }
            
            if($allmembers===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "member" => $allmembers
                          
                           
                           
                          
                       ));
                       
                }
            
            
            
            
        }
        
        
          /**
         * This is a function that determines if a user has a particular privilege assigned to him
         */
        public function determineIfAUserHasThisPrivilegeAssigned($userid, $privilegename){
            
             $allprivileges = [];
            //spool all the privileges assigned to a user
                $criteria7 = new CDbCriteria();
                $criteria7->select = 'itemname, userid';
                $criteria7->condition='userid=:userid';
                $criteria7->params = array(':userid'=>$userid);
                $priv= AuthAssignment::model()->find($criteria7);
                
                //retrieve all the children of the role
                
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$priv['itemname']);
                $allprivs= Authitemchild::model()->findAll($criteria);
                 
                //check to see if this privilege exist for this user
                foreach($allprivs as $pris){
                    if($this->privilegeType($pris['child'])== 0){
                        $allprivileges[] = $pris['child'];
                        
                    }elseif($this->privilegeType($pris['child'])== 1){
                        
                       $allprivileges[] = $this->retrieveAllTaskPrivileges($pris['child']); 
                    }elseif($this->privilegeType($pris['child'])== 2){
                        
                        $allprivileges[] = $this->retrieveAllRolePrivileges($pris['child']);
                    }
                    
                    
                    
                    
                }
               
                
                if(in_array($privilegename, $allprivileges)){
                    
                    return true;
                     
                }else{
                    
                    return false;
                     
                }
      
        }
        
        
          /**
         * This is the function that determines a privilege type
         */
        public function privilegeType($privname){
            
            $criteria7 = new CDbCriteria();
                $criteria7->select = 'name, type';
                $criteria7->condition='name=:name';
                $criteria7->params = array(':name'=>$privname);
                $privs= Authitem::model()->find($criteria7);
                
                return $privs['type'];
                
                
        }
        
        
         /**
         * This is the function that returns all member privileges of a task
         */
        public function retrieveAllTaskPrivileges($task){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$task);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
               
            
        }
        
        /**
         * This is the function that returns all members in a role
         */
        public function retrieveAllRolePrivileges($role){
            
            $member = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = 'child';
                $criteria->condition='parent=:parent';
                $criteria->params = array(':parent'=>$role);
                $allprivs= Authitemchild::model()->findAll($criteria);
                
                foreach($allprivs as $privs){
                    if($this->privilegeType($privs['child'])== 0){
                         $member[] = $privs['child'];
                        
                    }elseif($this->privilegeType($privs['child'])== 1){
                        
                        $member[] = $this->retrieveAllTaskPrivileges($privs['child']); 
                    }elseif($this->privilegeType($privs['child'])== 2){
                        
                        $member[] = $this->retrieveAllRolePrivileges($privs['child']); 
                    }
                   
                    
                }
              return $member;
                
            
        }
        
       
	/**
         * This is the function that retrieves all the networks of a partner domain
         */
        public function actionListAllDomainPartnerNetworks(){
            
            $model = new Resourcegroupcategory;
            $userid = Yii::app()->user->id;
            
            $user_domain_id = $this->determineAUserDomainIdGiven($userid);
            $country_id = $_REQUEST['country'];
            $domain_type = strtolower($_REQUEST['domain_type']);
            $search_string = $_REQUEST['search_string'];
            $domain = $_REQUEST['domain'];
            $start = $_REQUEST['start'];
            $limit = $_REQUEST['limit'];
            
             //get all the partners of this domain
            $domain_partners = $this->getAllThePartnersOfThisDomain($user_domain_id);
            
            if($search_string ==""){//search string was not provided
                //if the industry was not given
                if($domain == "" or $domain==0){//this is for all domains
                   if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type
                                            
                       $all_partner_networks = [];
                       $count = 0;
                                                 
                            foreach($domain_partners as $partner){
                                if($model->isDomainOfTheRequiredDomainType($partner,$domain_type)){
                                    $criteria = new CDbCriteria();
                                    $criteria->select = '*';
                                    $criteria->condition='domain_id=:domain';   
                                    $criteria->params = array(':domain'=>$partner);
                                    $criteria->order = "name";
                                    $criteria->offset = $start;
                                    //$criteria->limit = $limit;     
                                    $networks = Network::model()->findAll($criteria);
                                
                                    foreach($networks as $network){
                                       //if($this->isThisNetworkAvailableForThisMember($userid,$network['id'],$network['domain_id'],$network['security_level_weight'])){
                                             $all_partner_networks[] = $network;
                                             $count = $count + 1;
                                       // }
                                        
                                    }
                                   
                                }
                                
                            }
                     
                       
                       if($domain_partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_partner_networks,
                                    "results"=>$count
                                   
                    
                            ));
                       
                         }
                      
                        
                        
                    }else{//country was provided
                       $all_partner_networks = [];
                       $count = 0;
                                             
                            foreach($domain_partners as $partner){
                                
                              if($model->isDomainOfTheRequiredDomainTypeAndCountry($partner,$domain_type,$country_id)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='domain_id=:domain';   
                                  $criteria->params = array(':domain'=>$partner);
                                  $criteria->order = "name";
                                  $criteria->offset = $start;
                                 // $criteria->limit = $limit;  
                                  $networks = Network::model()->findAll($criteria);
                                
                                  foreach($networks as $network){
                                          if($model->isThisNetworkAvailableForThisMember($userid,$network['id'],$network['domain_id'])){
                                             $all_partner_networks[] = $network;
                                             $count = $count + 1;
                                        }
                                    }
                                  
                              }
                                
                            }
                       
                       
                       if($domain_partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_partner_networks,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                        
                    }
                    
                    
                    
                    
                }else{//a single domain was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){ //country was not provided
                       $all_partner_networks = [];
                       $count = 0;
                                             
                        if($model->isDomainOfTheRequiredDomainType($domain,$domain_type)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='domain_id=:domain';   
                                  $criteria->params = array(':domain'=>$domain);
                                  $criteria->order = "name";
                                  $criteria->offset = $start;
                                 // $criteria->limit = $limit;  
                                  $networks = Network::model()->findAll($criteria);
                                
                                  foreach($networks as $network){
                                          if($model->isThisNetworkAvailableForThisMember($userid,$network['id'],$network['domain_id'])){
                                             $all_partner_networks[] = $network;
                                             $count = $count + 1;
                                        }
                                    }
                                  
                              }
                                
                            
                       
                       
                       if($domain_partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_partner_networks,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                    }else{
                        $all_partner_networks = [];
                        $count = 0;
                                             
                                                         
                              if($model->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='domain_id=:domain';   
                                  $criteria->params = array(':domain'=>$domain);
                                  $criteria->order = "name";
                                  $criteria->offset = $start;
                                 // $criteria->limit = $limit;  
                                  $networks = Network::model()->findAll($criteria);
                                
                                  foreach($networks as $network){
                                         if($model->isThisNetworkAvailableForThisMember($userid,$network['id'],$network['domain_id'])){
                                             $all_partner_networks[] = $network;
                                             $count = $count + 1;
                                        }
                                    }
                                  
                              }
                                
                           
                       
                       
                       if($domain_partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_partner_networks,
                                    "results"=>$count
                    
                            ));
                       
                         }
						
                    }
                    
                    
                    
                    
                }
    
            }//end of the empty search string variable
        }
        
        
         /**
         * This is the function that retreives all partners of a domain
         */
        public function getAllThePartnersOfThisDomain($user_domain_id){
            $model = new DomainHasPartners;
            return $model->getAllThePartnersOfThisDomain($user_domain_id);
        }
        
        
        /**
         * This is the function that list all awaiting network membership request
         */
        public function actionListAllAwaitingNetworkMembershipRequest(){
            
             $model = new Network;
            $userid = Yii::app()->user->id;
            
            $user_domain_id = $this->determineAUserDomainIdGiven($userid);
            $country_id = $_REQUEST['country'];
            $domain_type = strtolower($_REQUEST['domain_type']);
            $search_string = $_REQUEST['search_string'];
            $domain = $_REQUEST['domain'];
            $start = $_REQUEST['start'];
            $limit = $_REQUEST['limit'];
            
             //get all the network owned by  user
            $user_networks = $model->getAllTheNetworksOwnedByUser($userid);
            
            if($search_string ==""){//search string was not provided
                //if the industry was not given
                if($domain == "" or $domain==0){//this is for all domains
                   if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type
                                            
                       $awaiting_networks_members = [];
                       $count = 0;
                                                 
                            foreach($user_networks as $network){
                                if($model->isNetworkDomainOfTheRequiredDomainType($network,$domain_type)){
                                    $criteria = new CDbCriteria();
                                    $criteria->select = '*';
                                    $criteria->condition='network_id=:netid and membership_status=:status';   
                                    $criteria->params = array(':netid'=>$network,':status'=>"pending");
                                    $criteria->order = "network_id";
                                    $networks = NetworkHasMembers::model()->findAll($criteria);
                                    foreach($networks as $network){
                                         $awaiting_networks_members[] = $network;
                                         $count = $count + 1;
                                    }
                                   
                                }
                                
                            }
                     
                       
                       if($user_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $awaiting_networks_members,
                                    "results"=>$count
                                   
                    
                            ));
                       
                         }
                      
                        
                        
                    }else{//country was provided
                       $awaiting_networks_members = [];
                       $count = 0;
                                             
                            foreach($user_networks as $network){
                                
                              if($model->isNetworkDomainOfTheRequiredDomainTypeAndCountry($network,$domain_type,$country_id)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='network_id=:netid and membership_status=:status';   
                                  $criteria->params = array(':netid'=>$network,':status'=>"pending");
                                  $criteria->order = "network_id";
                                  $networks = NetworkHasMembers::model()->findAll($criteria);
                                
                                   foreach($networks as $network){
                                         $awaiting_networks_members[] = $network;
                                         $count = $count + 1;
                                    }
                                  
                              }
                                
                            }
                       
                       
                       if($user_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $awaiting_networks_members,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                        
                    }
                    
                    
                    
                    
                }else{//a single domain was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){ //country was not provided
                       $awaiting_networks_members = [];
                       $count = 0;
                       
                      
                        foreach($user_networks as $network){
                              if($this->isDomainOfTheRequiredDomainType($domain,$domain_type)){
                                  
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='network_id=:netid and membership_status=:status';   
                                  $criteria->params = array(':netid'=>$network,':status'=>"pending");
                                  $criteria->order = "network_id";
                                  $requesters = NetworkHasMembers::model()->findAll($criteria);
                                
                                  foreach($requesters as $request){
                                      if($model->isThisNetworkForThisDomain($request['network_id'],$domain)){
                                          $awaiting_networks_members[] = $network;
                                          $count = $count + 1;
                                      }
                                        
                                    }
                                  
                                  
                              }
                              
                            
                        }
                          
                                  
                              
                                
                            
                       
                       
                       if($user_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $awaiting_networks_members,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                    }else{
                        $awaiting_networks_members = [];
                        $count = 0;
                                             
                                                         
                          foreach($user_networks as $network){
                              if($this->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id)){
                                  
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='network_id=:netid and membership_status=:status';   
                                  $criteria->params = array(':netid'=>$network,':status'=>"pending");
                                  $criteria->order = "network_id";
                                  $requesters = NetworkHasMembers::model()->findAll($criteria);
                                
                                  foreach($requesters as $request){
                                      if($model->isThisNetworkForThisDomain($request['network_id'],$domain)){
                                          $awaiting_networks_members[] = $network;
                                          $count = $count + 1;
                                      }
                                        
                                    }
                                  
                                  
                              }
                              
                            
                        }
                                
                           
                       
                       
                       if($user_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $awaiting_networks_members,
                                    "results"=>$count
                    
                            ));
                       
                         }
						
                    }
                    
                    
                    
                    
                }
                
                
                
                
                
                
                
            }//end of the empty search string variable
            
        }
        
        
        /**
         * This is the function that determines if a domain is of the required domain type
         */
        public function isDomainOfTheRequiredDomainType($domain,$domain_type){
            $model = new Resourcegroupcategory;
            return $model->isDomainOfTheRequiredDomainType($domain,$domain_type);
        }
        
        
         /**
         * This is the function that determines if a domain is of the required domain type and country
         */
        public function isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id){
            $model = new Resourcegroupcategory;
            return $model->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id);
        }
        
        
        /**
         * This is the function that retrieves all the network a member connects to
         */
        public function actionListAllNetworksConnectedToByDomainMembers(){
            
            $model = new Resourcegroupcategory;
            $userid = Yii::app()->user->id;
            
            $user_domain_id = $this->determineAUserDomainIdGiven($userid);
            $country_id = $_REQUEST['country'];
            $domain_type = strtolower($_REQUEST['domain_type']);
            $search_string = $_REQUEST['search_string'];
            $domain = $_REQUEST['domain'];
            $start = $_REQUEST['start'];
            $limit = $_REQUEST['limit'];
            
             //get all the partners of this domain
            $domain_partners = $this->getAllThePartnersOfThisDomain($user_domain_id);
            
            if($search_string ==""){//search string was not provided
                //if the industry was not given
                if($domain == "" or $domain==0){//this is for all domains
                   if($country_id =="" or $country_id==0){//country was not provided
                        //retrieve the domains based on the domain type
                                            
                       $all_partner_networks = [];
                       $count = 0;
                                                 
                            foreach($domain_partners as $partner){
                                if($model->isDomainOfTheRequiredDomainType($partner,$domain_type)){
                                    $criteria = new CDbCriteria();
                                    $criteria->select = '*';
                                    $criteria->condition='domain_id=:domain';   
                                    $criteria->params = array(':domain'=>$partner);
                                    $criteria->order = "name";
                                    $criteria->offset = $start;
                                    //$criteria->limit = $limit;     
                                    $networks = Network::model()->findAll($criteria);
                                
                                    foreach($networks as $network){
                                       if($this->isMemberConnectedToThisNetwork($userid,$network['id'])){
                                            $all_partner_networks[] = $network;
                                            $count = $count + 1;
                                       }
                                        
                                    }
                                   
                                }
                                
                            }
                     
                       
                       if($domain_partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_partner_networks,
                                    "results"=>$count
                                   
                    
                            ));
                       
                         }
                      
                        
                        
                    }else{//country was provided
                       $all_partner_networks = [];
                       $count = 0;
                                             
                            foreach($domain_partners as $partner){
                                
                              if($model->isDomainOfTheRequiredDomainTypeAndCountry($partner,$domain_type,$country_id)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='domain_id=:domain';   
                                  $criteria->params = array(':domain'=>$partner);
                                  $criteria->order = "name";
                                  $criteria->offset = $start;
                                 // $criteria->limit = $limit;  
                                  $networks = Network::model()->findAll($criteria);
                                
                                  foreach($networks as $network){
                                       if($this->isMemberConnectedToThisNetwork($userid,$network['id'])){
                                            $all_partner_networks[] = $network;
                                            $count = $count + 1;
                                       }
                                        
                                    }
                              }
                                
                            }
                       
                       
                       if($domain_partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_partner_networks,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                        
                    }
                    
                    
                    
                    
                }else{//a single domain was provided
                    //if the country was not provided
                    if($country_id == "" or $country_id==0){ //country was not provided
                       $all_partner_networks = [];
                       $count = 0;
                                             
                        if($model->isDomainOfTheRequiredDomainType($domain,$domain_type)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='domain_id=:domain';   
                                  $criteria->params = array(':domain'=>$domain);
                                  $criteria->order = "name";
                                  $criteria->offset = $start;
                                 // $criteria->limit = $limit;  
                                  $networks = Network::model()->findAll($criteria);
                                
                                  foreach($networks as $network){
                                       if($this->isMemberConnectedToThisNetwork($userid,$network['id'])){
                                            $all_partner_networks[] = $network;
                                            $count = $count + 1;
                                       }
                                        
                                    }
                                  
                              }
                                
                            
                       
                       
                       if($domain_partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_partner_networks,
                                    "results"=>$count
                    
                            ));
                       
                         }
                        
                    }else{
                        $all_partner_networks = [];
                        $count = 0;
                                             
                                                         
                              if($model->isDomainOfTheRequiredDomainTypeAndCountry($domain,$domain_type,$country_id)){
                                  $criteria = new CDbCriteria();
                                  $criteria->select = '*';
                                  $criteria->condition='domain_id=:domain';   
                                  $criteria->params = array(':domain'=>$domain);
                                  $criteria->order = "name";
                                  $criteria->offset = $start;
                                 // $criteria->limit = $limit;  
                                  $networks = Network::model()->findAll($criteria);
                                
                                 foreach($networks as $network){
                                       if($this->isMemberConnectedToThisNetwork($userid,$network['id'])){
                                            $all_partner_networks[] = $network;
                                            $count = $count + 1;
                                       }
                                        
                                    }
                                  
                              }
                                
                           
                       
                       
                       if($domain_partners===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_partner_networks,
                                    "results"=>$count
                    
                            ));
                       
                         }
						
                    }
                    
                    
                    
                    
                }
                
                
                
                
                
                
                
            }//end of the empty search string variable
            
        }
        
        /**
         * This is the function that confirms if a member is connected to a network
         */
        public function isMemberConnectedToThisNetwork($userid,$network_id){
            $model = new NetworkHasMembers;
            return $model->isMemberConnectedToThisNetwork($userid,$network_id);
        }
        
        
        /**
         * This is the function that confirms if a network is available for a member
         */
        public function isThisNetworkAvailableForThisMember($member_id,$network_id,$network_domain_id,$network_security_level_weight){
            $model = new Network;
            return $model->isThisNetworkAvailableForThisMember($member_id,$network_id,$network_domain_id,$network_security_level_weight);
        }
        
        
        
        /**
         * This is the function that retrieves all the networks that a domain member is connected to
         */
        public function actionListAllDomainMemberConnectedNetworks(){
            
            $model = new NetworkHasMembers;
            
            $userid = Yii::app()->user->id;
             
            $member = $_REQUEST['member'];
            
            //get the domain of the networks in this domain
            $member_networks = $model->getAllTheNetworksWhereThisMemberIsConnectedTo($member);
            
            $all_network_members = [];
            
            foreach($member_networks as $network){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$network);
                $networks= Network::model()->findAll($criteria);
                
                foreach($networks as $network){
                    $all_network_members[] = $network;
                }
                
            }
            if($member_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $all_network_members,
                                    //"results"=>$count
                    
                            ));
                       
                         }
            
        }
        
        
        /**
         * This is the function that retrieves extra information on a network
         */
        public function actionretrieveextrainfo(){
            
            $country_name = $this->getThisCountryName($_REQUEST['city']);
            $domain_name = $this->getThisDomainName($_REQUEST['domain']);
            $issue = $this->getTheIssuesAndValuesForThisNetwork($_REQUEST['issue']);
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "country" => $country_name,
                                    "domain"=>$domain_name,
                                    "issue"=>$issue
                    
                            ));
        }
        
        
        /**
         * This is the functon that retrieves a country'a name
         */
        public function getThisCountryName($country_id){
            $model = new City;
            return $model->getThisCountryName($country_id);
        }
        
        
        /**
         * This is the functon that retrieves a country'a name
         */
        public function getThisDomainName($domain_id){
            $model = new Resourcegroupcategory;
            return $model->getThisDomainName($domain_id);
        }
        
        /**
         * This is the function that gets the issues name for a network
         */
        public function getTheIssuesAndValuesForThisNetwork($issue){
            $model = new IssuesAndValues;
            return $model->getTheIssuesAndValuesForThisNetwork($issue);
        }
        
        
        /**
         * This is the function that retrieves all members in a network
         */
        public function actionListNetworkAllMembers(){
            
           $model = new NetworkHasMembers;
            
            $network_id = $_REQUEST['network'];
            
            //get the domain of the networks in this domain
            $network_members = $model->getAllTheMembersOfThisNetwork($network_id);
            
            $all_members = [];
            
            foreach($network_members as $member){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$member);
                $members= User::model()->findAll($criteria);
                
                foreach($members as $mem){
                    $all_members[] = $mem;
                }
                
            }
            if($all_members===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "member" => $all_members,
                                    //"results"=>$count
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that retrieves extra parameters for a network
         */
        public function actionretrieveextranetworkinfo(){
            
            $model = new Network;
            
            $network_id = $_REQUEST['network'];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$network_id);
             $network_details= Network::model()->findAll($criteria);
             
             //get this network domain
             $domain = $model->getTheDomainOfThisNetwork($network_id);
             
             //get the isues and values of this network
             $issue = $model->getTheIssuesAndValuesOfThisNetwork($network_id);
             
              if($network_details===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $network_details,
                                    "domain"=>$domain,
                                    "issue"=>$issue
                                    //"results"=>$count
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that requests for network membership
         */
        public function actionrequestnetworkmembership(){
            
            $model = new NetworkHasMembers;
            
            $userid = Yii::app()->user->id;
            
            $network_id = $_REQUEST['id'];
            
            $target_network_name = $this->getTheNameOfThisNetwork($network_id);
            
            if($model->isRequesterEligibleToMakeMembershipRequestToThisNetwork($userid, $network_id)){
                if($model->isNetworkMembershipRequestSuccessfullyInitiated($userid,$network_id)){
                    
                    $msg = "Your request for membership into the '$target_network_name' had been sent";
                  header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                   
                    
                            ));
                    
                }else{
                      $msg = "Your request for membership into the '$target_network_name' could not be sent. Please try again or Contact Customer Service for assistance";
                  header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                   
                    
                            ));
                    
                }
                
                
            }else{
                $msg = "It appears that you are having a pending request to '$target_colleague_name' network. Please be patient or contact Customer Service for assistance";
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                   
                    
                            ));
            
                }
            
        }
        
        
        /**
         * This is the function tthat rejects a network membership request 
         */
        public function actionrejectingnetwormmembershiprequest(){
            
            $model = new NetworkHasMembers;
            $userid = Yii::app()->user->id;
            
            $network_id = $_REQUEST['id'];
          
             $target_network_name = $this->getTheNameOfThisNetwork($network_id);
            
            if($model->isTheRejectionOfThisNetworkMembershipRequestASuccess($userid,$network_id)){
                 $msg = "You have successfully rejected the membership request to the  '$target_network_name' network. No further action is required";
                  header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                   
                    
                            ));
            }else{
                 $msg = "The attempt to reject the network membership request into the  '$target_network_name' was not successful. Please try again or Contact Customer Service for assistance";
                  header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                   
                    
                            ));
            }
        }
        
        
        /**
         * This is the function that accepts network mrmbership request
         */
        public function actionacceptingnetwormmembershiprequest(){
            
            $model = new NetworkHasMembers;
            $userid = Yii::app()->user->id;
            
            $network_id = $_REQUEST['id'];
         
            $target_network_name = $this->getTheNameOfThisNetwork($network_id);
            
            if($model->isTheAcceptanceOfThisNetworkMembershipRequestASuccess($userid,$network_id)){
                 $msg = "You have successfully accepted the request for the '$target_network_name' membership.";
                  header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                   
                    
                            ));
            }else{
                 $msg = "The attempt to accept the network membership request into '$target_network_name' was not successful. Please try again or Contact Customer Service for assistance";
                  header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                   
                    
                            ));
            }
        }

      
        /**
         * This is the function that retrieves the name of a network
         */
        public function getTheNameOfThisNetwork($network_id){
            $model = new Network;
            return $model->getTheNameOfThisNetwork($network_id);
        }
        
        
        /**
         * This is the function that list all networks connected to by a domain member
         * 
         */
         
        public function actionListAllNetworksConnectedToByThisMember(){
            
            $model = new NetworkHasMembers;
            $member_id = Yii::app()->user->id;
            
            $connected_networks = $model->getAllTheNetworksWhereThisMemberIsConnectedTo($member_id);
            
            $member_networks =[];
            foreach($connected_networks as $net){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';   
                $criteria->params = array(':id'=>$net);
                $criteria->order = "name";
                $network = Network::model()->find($criteria);
                
                $member_networks[] = $network;
            }
            
            
             if($connected_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $member_networks,
                                    "all_networks"=>$connected_networks
                                   
                    
                            ));
                       
                         }
        }
        
        
        
         
        /**
         * This is the function that lista the networks that a user can send email or an anniucement to
         */
        public function actionListAllNetworkMessagableByThisDomainMember(){
            
            $model = new NetworkHasMembers;
            $user_id = Yii::app()->user->id;
            
             //get the domain id of the logged in user
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $preference = $_REQUEST['preference'];
            
            if($preference == strtolower('staff')){
                
                $private_networks =$model->getAllThePrivateNetworkThatThisMemberIsConnectedTo($user_id,$domain_id);
                $target = [];
                //retrieve private same domain networks here
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:domainid and type=:type';   
                $criteria->params = array(':domainid'=>$domain_id,':type'=>"private");
                $criteria->order = "name";
                $networks = Network::model()->findAll($criteria);
                
                foreach($networks as $net){
                    if(in_array($net['id'],$private_networks )){
                        $target[] = $net;
                    }
                }
                 if($private_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $target,
                                    "connected"=>$private_networks
                                   
                            ));
                       
                         }
                
                
            }else if($preference == strtolower('client')){
                //retrieve public same domain network
                 $public_networks =$model->getAllThePublicNetworkThatThisMemberIsConnectedTo($user_id,$domain_id);
                $target = [];
                //retrieve private same domain networks here
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='domain_id=:domainid and type=:type';   
                $criteria->params = array(':domainid'=>$domain_id,':type'=>"public");
                $criteria->order = "name";
                $networks = Network::model()->findAll($criteria);
                
                foreach($networks as $net){
                    if(in_array($net['id'],$public_networks )){
                        $target[] = $net;
                    }
                }
                 if($public_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $target
                                   
                            ));
                       
                         }
            }else if($preference == strtolower('partner')){
                 //retrieve public  domain and oethe partner domain networks
                $partner_networks =$model->getAllTheOtherDomainNetworksThatThisMemberIsConnectedTo($user_id,$domain_id);
                $target = [];
                //retrieve private same domain networks here
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='type=:type';   
                $criteria->params = array(':type'=>"public");
                $criteria->order = "name";
                $networks = Network::model()->findAll($criteria);
                
                foreach($networks as $net){
                    if(in_array($net['id'],$partner_networks )){
                        $target[] = $net;
                    }
                }
                 if($partner_networks===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "network" => $target
                                   
                            ));
                       
                         }
            }
            
        }
        
        
        /**
         * This is the function that retrieves all the members of a network
         */
        public function actionRetreiveAllMembersOfANetworkGroup(){
            
            $model = new NetworkHasMembers;
            $group_id = $_REQUEST['network_id'];
            
             //get all members of this networks
            $network_members = $model->getAllTheMembersOfThisNetwork($group_id);
            
            $all_members = [];
            
            foreach($network_members as $member){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$member);
                $members= User::model()->findAll($criteria);
                
                foreach($members as $mem){
                    $all_members[] = $mem;
                }
                
            }
            if($all_members===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "member" => $all_members,
                                    //"results"=>$count
                    
                            ));
                       
                         }
            
            
        }
         
        
      
}
