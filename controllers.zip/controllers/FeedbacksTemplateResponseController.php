<?php

class FeedbacksTemplateResponseController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','submittinguserfeedback','retrievefeedbackresponsedetails'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that captures feedback responses
         */
        public function actionsubmittinguserfeedback(){
            $model = new FeedbacksTemplateResponse;
            
            $user_id = Yii::app()->user->id;
            
            $model->template_id = $_REQUEST['feedback_id'];
            $model->user_id = $_REQUEST['user_id'];
            if(isset($_REQUEST['first_feedback_response_boolean'])){
                $model->first_feedback_response_boolean = $_REQUEST['first_feedback_response_boolean'];
            }
            $model->first_feedback_response_text = $_REQUEST['first_feedback_response_text'];
            $model->first_feedback_response_integer = $_REQUEST['first_feedback_response_integer'];
            $model->first_feedback_response_double = $_REQUEST['first_feedback_response_double'];
            if(isset($_REQUEST['second_feedback_response_boolean'])){
                $model->second_feedback_response_boolean = $_REQUEST['second_feedback_response_boolean'];
            }
            $model->second_feedback_response_text = $_REQUEST['second_feedback_response_text'];
            $model->second_feedback_response_integer = $_REQUEST['second_feedback_response_integer'];
            $model->second_feedback_response_double = $_REQUEST['second_feedback_response_double'];
            if(isset($_REQUEST['third_feedback_response_boolean'])){
                $model->third_feedback_response_boolean = $_REQUEST['third_feedback_response_boolean'];
            }
            $model->third_feedback_response_text = $_REQUEST['third_feedback_response_text'];
            $model->third_feedback_response_integer = $_REQUEST['third_feedback_response_integer'];
            $model->third_feedback_response_double = $_REQUEST['third_feedback_response_double'];
            if(isset($_REQUEST['fourth_feedback_response_boolean'])){
                $model->fourth_feedback_response_boolean = $_REQUEST['fourth_feedback_response_boolean'];
            }
            $model->fourth_feedback_response_text = $_REQUEST['fourth_feedback_response_text'];
            $model->fourth_feedback_response_integer = $_REQUEST['fourth_feedback_response_integer'];
            $model->fourth_feedback_response_double = $_REQUEST['fourth_feedback_response_double'];
            if(isset($_REQUEST['fifth_feedback_response_boolean'])){
                $model->fifth_feedback_response_boolean = $_REQUEST['fifth_feedback_response_boolean'];
            }
            $model->fifth_feedback_response_text = $_REQUEST['fifth_feedback_response_text'];
            $model->fifth_feedback_response_integer = $_REQUEST['fifth_feedback_response_integer'];
            $model->fifth_feedback_response_double = $_REQUEST['fifth_feedback_response_double'];
            $model->date_provided = new CDbExpression('NOW()');
            
            if($model->isFeedbackResponseLimitReached($_REQUEST['maximum_feedback_required'],$model->template_id)== false){
                
                if($model->isThisUserLegibleToProvideFeedbackResponse($user_id,$model->template_id,$_REQUEST['is_multiple_feedback_responses_allowed'])){
                    
                       if($model->save()){
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" =>"Your feedback is very valuable to us. Thank you very much"
                        ));
                
                
                    }else{
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"There is possibly a validation error on your input data. Please correct it and try again. If the problem persist, contact customer service for assistance"
                        ));  
                    }
                }else{
                     header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"This feedback was not received. It is possible you are not legible to provide feedback on this product or service"
                        ));  
                }
                
                
                
            }else{
                
                header('Content-Type: application/json');
                            echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                           "msg" =>"No more feedback is allowed on this product or service using this feedback template as the limit had already been reached"
                        ));
            }
            
        }
        
        
        
        /**
         * This is the function that retrieves feedback response details
         */
        public function actionretrievefeedbackresponsedetails(){
            
            $user_id = Yii::app()->user->id;
                      
            $response_id = $_REQUEST['response_id'];
            $template_id = $_REQUEST['template_id'];
            //get the feedback response details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$response_id);
            $response = FeedbacksTemplateResponse::model()->find($criteria); 
            
            //get the feedback template details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$template_id);
            $template = FeedbackTemplate::model()->find($criteria); 
            
            if($response===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "template" =>$template,
                                    "response"=>$response,
                          
                            ));
                       
                         }
        }
}
