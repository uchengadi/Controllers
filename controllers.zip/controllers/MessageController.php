<?php

class MessageController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','sendingemailmessage','retrieveAllEmailsInUsersInbox','retrieveAllEmailsInUsersOutbox',
                                    'retrieveAllAnnouncementsInUsersInbox','retrieveAllAnnouncementsInUsersOutbox','broadcastingannouncementmessage',
                                    'retrieveAllBucketsForThisMessage','forwardingemailmessagetoexternalemail','getEmailMessageDetails',
                                    'replyingemailmessage','retrieveThisMemberAllColleagues','retrieveThisMemberAllColleagues','retrieveThisMemberAllChatMessagesBasedOnIssuesAndValues',
                                    'retrieveThisMemberAllIssuesAndValuesBasedOnPreference','retrieveAllMemberConnectedNetworksBasedOnIssuesAndValues',
                                    'sendchatmessagetocolleaguesofthismember','getExtraInformationAboutChatMessage','retrieveallassetsforthischatmessage',
                                    'retrievethisMessageAssetContent','retrievethisMessageContent','deletemessagefromtheworkboard','retrieveAllChatMessagesToThisUserNetworkGroups',
                                    'replyingtoachatmessagetoColleagues','replyingtoachatmessagetousergroupmembers','sendchatmessagetomembernetworkgroup',
                                    'deletemessagefromtheworkboard','deletegroupmessagefromtheworkboard','deletegroupmessagefromtheworkboard'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that sends email messages
         */
        public function actionsendingemailmessage(){
           
           $model = new Message;
           $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainIdGiven($user_id);
           $counter = 0;
           //get all the recepients on the to list
           $mail_recepients = [];
          if($_REQUEST['is_to_list_a_network'] == 0){
                foreach($_REQUEST['to'] as $to){
                    $mail_recepients[] = $to;
                    $is_to_list_a_network = 0;
                }
           }else{
                foreach($_REQUEST['to_network'] as $tonet){
                    $mail_recepients[] = $tonet;
                    $is_to_list_a_network = 1;
                }
           }
           
           
           //get all the recepients on the cc list
           
          
         
             $cc_recepients = []; 
             if($_REQUEST['is_cc_list_a_network'] == 0){
                foreach($_REQUEST['cc'] as $cc){
                    $cc_recepients[] = $cc;
                    $is_cc_list_a_network = 0;
                }
            }else{
                foreach($_REQUEST['cc_network'] as $ccnet){
                    $cc_recepients[] = $ccnet;
                    $is_cc_list_a_network = 1;
                }
           }
           
           //to recepients names
           $to_names = [];
           $cc_names = [];
           if(!empty($mail_recepients)){
               if($_REQUEST['is_to_list_a_network'] == 0){
                foreach($mail_recepients as $res){
                    $to_names[] = $this->getTheNameOfThisMember($res);
                 }
               }else{
                   foreach($mail_recepients as $res){
                    $to_names[] = $this->getTheNameOfThisNetwork($res);
                 }
               }
               
           }
            if(!empty($cc_recepients)){
                if($_REQUEST['is_cc_list_a_network'] == 0){
                    foreach($cc_recepients as $cc){
                        $cc_names[] = $this->getTheNameOfThisMember($cc);
                    }
                }else{
                    foreach($cc_recepients as $cc){
                        $cc_names[] = $this->getTheNameOfThisNetwork($cc);
                    }
                }
               
           }
            
           //$cc_recepient_extra = array_diff($cc_recepients,$mail_recepients);
           $model->from = $user_id;
           $model->issues_and_values_id = $_REQUEST['issue']; 
           $model->subject = $_REQUEST['subject'];
           if(isset($_REQUEST['is_forwardable'])){
               $model->is_message_forwardable = $_REQUEST['is_forwardable'];
           }else{
              $model->is_message_forwardable = 0; 
           }
           $model->message = $_REQUEST['message'];
           $model->is_to_list_a_network = $is_to_list_a_network;
           $model->is_cc_list_a_network = $is_cc_list_a_network;
           $model->to_recepients_list = implode(',',$to_names); 
           $model->cc_recepients_list = implode(',',$cc_names); 
           $model->from_domain_id = $domain_id;
           $model->category = strtolower("email");
           $model->type = strtolower("inbox");
           $model->code =generateTheCodeForThisMessage($user_id,$domain_id,$model->issues_and_values_id,$model->category);
           $model->date_sent = new CDbExpression('NOW()');
           $model->date_recieved = new CDbExpression('NOW()');
          
           $counter = 0;
           $bucket_counter = 0;
           //include the asset buckets
           $buckets = [];
           if(is_numeric($_REQUEST['buckets'])){
             if(!empty($_REQUEST['buckets'])){
               foreach($_REQUEST['buckets'] as $buck){
                    $buckets[] = $buck;
                }
                $is_bucket_empty = false;
           }else{
               $is_bucket_empty = true;
           }
               
           }else{
              $is_bucket_empty = true; 
           }
           
   
     //start sending the mails to the users or networks
           $to_message = [];
           $recepient = [];
           $to_net_message = [];
           $network_members = [];
           $all_to_network_members = [];
           if($_REQUEST['is_to_list_a_network'] == 0){
              foreach($mail_recepients as $rec){
                 $model->to_domain_id = $this->determineAUserDomainIdGiven($rec); 
                 $model->to = $rec;
                 $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                 //$recepient[] = $rec;
                 $counter = $counter + 1;
              
              // $message_id = $model->executeTheSendingOfEmailToRecepient($model);  
              
               
           }
           
           //insert the buckets to the messages
         if($is_bucket_empty == false){
           foreach($to_message as $mess){
                      $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                  }
           }
               
           }else{
               
               foreach($mail_recepients as $net){
                   $network_members = $this->getAllTheMembersOfThisNetwork($net);
                   foreach($network_members as $netuser){
                      $model->to_domain_id = $this->determineAUserDomainIdGiven($netuser); 
                       $model->to = $netuser;
                       $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                       $counter = $counter + 1;
                        $all_to_network_members[] = $netuser;
                       
                   }
                    //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach($to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    }
                   
                 
                   
                  
                }
               
           }
           
           //cc mails
          
           $to_message = [];
           if($_REQUEST['is_cc_list_a_network'] == 0){
                foreach($cc_recepients as $cc_reciever){
                       $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_reciever); 
                       $model->to = $cc_reciever;
                       if(in_array($cc_reciever,$mail_recepients) == false){
                            $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                       
                    
                 }//end of the foreach
                //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach( $to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    } 
                
                
            }else{
                 $to_net_message = [];
                 foreach($cc_recepients as $cc_net){
                    $cc_network_members = $this->getAllTheMembersOfThisNetwork($cc_net);
                    if($_REQUEST['is_to_list_a_network'] == 0){
                      foreach($cc_network_members as $cc_netuser){
                       if(in_array($cc_netuser,$mail_recepients) == false){
                            $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_netuser); 
                            $model->to = $cc_netuser;
                            $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                      
                       
                     }
                        
                    }else{
                      foreach($cc_network_members as $cc_netuser){
                       if(in_array($cc_netuser,$all_to_network_members) == false){
                            $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_netuser); 
                            $model->to = $cc_netuser;
                            $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                      
                       
                     }
                        
                    }
                    
                     //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach($to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    }
                   
                  
                     
                 }
                
                
            }
               
   
            
        //write to the outbox here
         $model->writeTheseEmailMessageToTheSenderOutbox($model,$buckets,$is_bucket_empty);        
            
            if($counter>0){
                 $added_buckets = $bucket_counter/$counter;
            }
            $msg = "Email had been sent to $counter recepient(s) and  $added_buckets asset buckets were successfully added to each of the message recepients";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    "recepients"=>$mail_recepients,
                                  "is_bucket"=>$is_bucket_empty,
                                    "message_id"=>$to_message,
                                   "net_members"=>$network_members,
                                  "cc_rece"=>$cc_recepients
                                        
                                   
                            ));
            
        }
        
        
         /**
         * Determine a domain id of a user given his user id 
         */
        public function determineAUserDomainIdGiven($userid){
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$userid);
            $user= User::model()->find($criteria1);
            
            return $user['domain_id'];
        }
        
        /**
         * This is the function that gets all the members of a network
         */
        public function getAllTheMembersOfThisNetwork($network_id){
            $model = new NetworkHasMembers;
            return $model->getAllTheMembersOfThisNetwork($network_id);
        }
        
        
        /**
         * This is the function that attaches the assets in buckets to main
         */
        public function attachTheAssetsInTheBucket($message_id,$buckets){
            $model = new MessageHasBuckets;
            return $model->attachTheAssetsInTheBucket($message_id,$buckets);
            
        }
        
        
        /**
         * This is the function that retrieves the name of a user
         */
        public function getTheNameOfThisMember($user_id){
            $model = new User;
            return $model->getTheNameOfThisMember($user_id);
        }
        
        /**
         * This is the function that retrieves the name of networks
         */
        public function getTheNameOfThisNetwork($network_id){
            $model = new Network;
            return $model->getTheNameOfThisNetwork($network_id);
        }
        
        
        /**
         * This is the function that retrieves all the mails in a user's inbox
         */
        public function actionretrieveAllEmailsInUsersInbox(){
            
            $user_id = Yii::app()->user->id;
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='(`to`=:id and category=:cat) and `type`=:type';
            $criteria1->params = array(':id'=>$user_id,':cat'=>"email",':type'=>"inbox");
            $messages= Message::model()->findAll($criteria1);
            
            if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $messages,
                           
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves all the mails in a user's outbox
         */
        public function actionretrieveAllEmailsInUsersOutbox(){
            
            $user_id = Yii::app()->user->id;
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='(`from`=:id and category=:cat) and `type`=:type';
            $criteria1->params = array(':id'=>$user_id,':cat'=>"email",':type'=>"outbox");
            $messages= Message::model()->findAll($criteria1);
            
            if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $messages,
                           
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        /**
         * This is the function that retrieves all the announcements in a user's inbox
         */
        public function actionretrieveAllAnnouncementsInUsersInbox(){
            
            $user_id = Yii::app()->user->id;
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='(`to`=:id and category=:cat) and `type`=:type';
            $criteria1->params = array(':id'=>$user_id,':cat'=>"announcement",':type'=>"inbox");
            $messages= Message::model()->findAll($criteria1);
            
            if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $messages,
                           
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
         /**
         * This is the function that retrieves all the announcements in a user's outbox
         */
        public function actionretrieveAllAnnouncementsInUsersOutbox(){
            
            $user_id = Yii::app()->user->id;
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='(`from`=:id and category=:cat) and `type`=:type';
            $criteria1->params = array(':id'=>$user_id,':cat'=>"announcement",':type'=>"outbox");
            $messages= Message::model()->findAll($criteria1);
            
            if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $messages,
                           
                           
                           
                          
                       ));
                       
                }
            
        }
        
        
        //dealing with annoucement messages
        
        /**
         * This is the function that sends announcement messages
         */
        public function actionbroadcastingannouncementmessage(){
           
           $model = new Message;
           $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainIdGiven($user_id);
           $counter = 0;
           //get all the recepients on the to list
           $mail_recepients = [];
          if($_REQUEST['is_to_list_a_network'] == 0){
                foreach($_REQUEST['to'] as $to){
                    $mail_recepients[] = $to;
                    $is_to_list_a_network = 0;
                }
           }else{
                foreach($_REQUEST['to_network'] as $tonet){
                    $mail_recepients[] = $tonet;
                    $is_to_list_a_network = 1;
                }
           }
           
           
           //get all the recepients on the cc list
           
          
         
             $cc_recepients = []; 
             if($_REQUEST['is_cc_list_a_network'] == 0){
                foreach($_REQUEST['cc'] as $cc){
                    $cc_recepients[] = $cc;
                    $is_cc_list_a_network = 0;
                }
            }else{
                foreach($_REQUEST['cc_network'] as $ccnet){
                    $cc_recepients[] = $ccnet;
                    $is_cc_list_a_network = 1;
                }
           }
           
           //to recepients names
           $to_names = [];
           $cc_names = [];
           if(!empty($mail_recepients)){
               if($_REQUEST['is_to_list_a_network'] == 0){
                foreach($mail_recepients as $res){
                    $to_names[] = $this->getTheNameOfThisMember($res);
                 }
               }else{
                   foreach($mail_recepients as $res){
                    $to_names[] = $this->getTheNameOfThisNetwork($res);
                 }
               }
               
           }
            if(!empty($cc_recepients)){
                if($_REQUEST['is_cc_list_a_network'] == 0){
                    foreach($cc_recepients as $cc){
                        $cc_names[] = $this->getTheNameOfThisMember($cc);
                    }
                }else{
                    foreach($cc_recepients as $cc){
                        $cc_names[] = $this->getTheNameOfThisNetwork($cc);
                    }
                }
               
           }
            
           //$cc_recepient_extra = array_diff($cc_recepients,$mail_recepients);
           $model->from = $user_id;
           $model->issues_and_values_id = $_REQUEST['issue']; 
           $model->subject = $_REQUEST['subject'];
           if(isset($_REQUEST['is_forwardable'])){
               $model->is_message_forwardable = $_REQUEST['is_forwardable'];
           }else{
              $model->is_message_forwardable = 0; 
           }
           $model->message = $_REQUEST['message'];
           $model->is_to_list_a_network = $is_to_list_a_network;
           $model->is_cc_list_a_network = $is_cc_list_a_network;
           $model->to_recepients_list = implode(',',$to_names); 
           $model->cc_recepients_list = implode(',',$cc_names); 
           $model->from_domain_id = $domain_id;
           $model->category = strtolower("announcement");
           $model->type = strtolower("inbox");
           $model->code =$model->generateTheCodeForThisMessage($user_id,$domain_id,$model->issues_and_values_id,$model->category);
           $model->date_sent = new CDbExpression('NOW()');
           $model->date_recieved = new CDbExpression('NOW()');
          
           $counter = 0;
           $bucket_counter = 0;
           //include the asset buckets
           $buckets = [];
           if(empty($_REQUEST['bucket']) == false){
               foreach($_REQUEST['bucket'] as $buck){
                    $buckets[] = $buck;
                }
                $is_bucket_empty = false;
           }else{
               $is_bucket_empty = true;
           }
           
   
     //start sending the mails to the users or networks
           $to_message = [];
           $recepient = [];
           $to_net_message = [];
           $network_members = [];
           $all_to_network_members = [];
           if($_REQUEST['is_to_list_a_network'] == 0){
              foreach($mail_recepients as $rec){
                 $model->to_domain_id = $this->determineAUserDomainIdGiven($rec); 
                 $model->to = $rec;
                 $to_message[] = $model->executeTheSendingOfAnnouncementToRecepient($model);
                 //$recepient[] = $rec;
                 $counter = $counter + 1;
              
                        
               
           }
           
           //insert the buckets to the messages
         if($is_bucket_empty == false){
           foreach($to_message as $mess){
                      $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                  }
           }
               
           }else{
               
               foreach($mail_recepients as $net){
                   $network_members = $this->getAllTheMembersOfThisNetwork($net);
                   foreach($network_members as $netuser){
                      $model->to_domain_id = $this->determineAUserDomainIdGiven($netuser); 
                       $model->to = $netuser;
                       $to_message[] = $model->executeTheSendingOfAnnouncementToRecepient($model);
                       $counter = $counter + 1;
                        $all_to_network_members[] = $netuser;
                       
                   }
                    //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach($to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    }
                   
                 
                   
                  
                }
               
           }
           
           //cc mails
          
           $to_message = [];
           if($_REQUEST['is_cc_list_a_network'] == 0){
                foreach($cc_recepients as $cc_reciever){
                       $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_reciever); 
                       $model->to = $cc_reciever;
                       if(in_array($cc_reciever,$mail_recepients) == false){
                            $to_message[] = $model->executeTheSendingOfAnnouncementToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                       
                    
                 }//end of the foreach
                //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach( $to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    } 
                
                
            }else{
                 $to_net_message = [];
                 foreach($cc_recepients as $cc_net){
                    $cc_network_members = $this->getAllTheMembersOfThisNetwork($cc_net);
                    if($_REQUEST['is_to_list_a_network'] == 0){
                      foreach($cc_network_members as $cc_netuser){
                       if(in_array($cc_netuser,$mail_recepients) == false){
                            $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_netuser); 
                            $model->to = $cc_netuser;
                            $to_message[] = $model->executeTheSendingOfAnnouncementToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                      
                       
                     }
                        
                    }else{
                      foreach($cc_network_members as $cc_netuser){
                       if(in_array($cc_netuser,$all_to_network_members) == false){
                            $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_netuser); 
                            $model->to = $cc_netuser;
                            $to_message[] = $model->executeTheSendingOfAnnouncementToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                      
                       
                     }
                        
                    }
                    
                     //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach($to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    }
                   
                  
                     
                 }
                
                
            }
               
   
            
        //write to the outbox here
        $model->writeTheseAnnouncementMessageToTheSenderOutbox($model,$buckets,$is_bucket_empty);    
            
            if($counter>0){
                 $added_buckets = $bucket_counter/$counter;
            }
            $msg = "This Announcement had been sent to $counter recepient(s) and  $added_buckets asset buckets were successfully added to each of the announcement message recepients";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    "recepients"=>$mail_recepients,
                                  // "for_inbox"=>$recepient,
                                    "message_id"=>$to_message,
                                   "net_members"=>$network_members,
                                  "cc_rece"=>$cc_recepients
                                        
                                   
                            ));
            
        }
        
        
        /**
         * This is the function that retrieves all asset buckets for a message
         */
        public function actionretrieveAllBucketsForThisMessage(){
            
            $model = new MessageHasBuckets;
            
            $message_id = $_REQUEST['message_id'];
            
            $message_buckets = $model->getAllBucketsForThisMessage($message_id);
            $targets = [];
            foreach($message_buckets as $bucket){
                $criteria1 = new CDbCriteria();
                $criteria1->select = '*';
                $criteria1->condition='id=:id';
                $criteria1->params = array(':id'=>$bucket);
                $buck= AssetsBuckets::model()->find($criteria1);
                
                $targets[] = $buck;
                
            }
            
             if($message_buckets===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "bucket" => $targets,
                     
                       ));
                       
                }
            
            
        }
        
        
        /**
         * This is the function that forwards message to a user's externall mail box
         */
        public function actionforwardingemailmessagetoexternalemail(){
            
            $model = new Message;
            
            $user_id = Yii::app()->user->id;
            $message_id = $_REQUEST['message_id'];
            
            if($model->isTheForwardingOfThisEmailMessageASuccess($message_id,$user_id)){
               $msg = "Message had been forwarded to your external email box successfully";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "msg" => $msg,
                     
                       ));
            }else{
                $msg= "There was an issue trying to forward this message to your email box. Please contact customer service for assistance or try again";
                header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                            "msg" => $msg,
                     
                       ));
            }
            
            
        }
        
        
        /**
         * This is the function that gets an extra email message details
         */
        public function actiongetEmailMessageDetails(){
            $model = new IssuesAndValues;
            $message_id = $_REQUEST['id'];
            
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='id=:id';
            $criteria1->params = array(':id'=>$message_id);
            $message= Message::model()->find($criteria1);
            
            //get the issue and value of this message
            $issues = $model->getTheIssuesAndvaluesForThisMessage($message['issues_and_values_id']);
             header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "issue" => $issues,
                     
                       ));
        }
        
        
        /**
         * This is the function that replies an email message
         */
        public function actionreplyingemailmessage(){
            
            $model = new Message;
           $user_id = Yii::app()->user->id;            
           $domain_id =  $this->determineAUserDomainIdGiven($user_id);
           $counter = 0;
           //get all the recepients on the to list
           $mail_recepients = [];
          if($_REQUEST['is_to_list_a_network'] == 0){
              
                    $mail_recepients[] = $_REQUEST['reply_to'];
                    $is_to_list_a_network = 0;
              
           }else{
                foreach($_REQUEST['to_network'] as $tonet){
                    $mail_recepients[] = $tonet;
                    $is_to_list_a_network = 1;
                }
           }
        
           //get all the recepients on the cc list
           
             $cc_recepients = []; 
             if($_REQUEST['is_cc_list_a_network'] == 0){
                foreach($_REQUEST['cc'] as $cc){
                    $cc_recepients[] = $cc;
                    $is_cc_list_a_network = 0;
                }
            }else{
                foreach($_REQUEST['cc_network'] as $ccnet){
                    $cc_recepients[] = $ccnet;
                    $is_cc_list_a_network = 1;
                }
           }
           
           //to recepients names
           $to_names = [];
           $cc_names = [];
           if(!empty($mail_recepients)){
               if($_REQUEST['is_to_list_a_network'] == 0){
                foreach($mail_recepients as $res){
                    $to_names[] = $this->getTheNameOfThisMember($res);
                 }
               }else{
                   foreach($mail_recepients as $res){
                    $to_names[] = $this->getTheNameOfThisNetwork($res);
                 }
               }
               
           }
            if(!empty($cc_recepients)){
                if($_REQUEST['is_cc_list_a_network'] == 0){
                    foreach($cc_recepients as $cc){
                        $cc_names[] = $this->getTheNameOfThisMember($cc);
                    }
                }else{
                    foreach($cc_recepients as $cc){
                        $cc_names[] = $this->getTheNameOfThisNetwork($cc);
                    }
                }
               
           }
            
           //$cc_recepient_extra = array_diff($cc_recepients,$mail_recepients);
           $model->from = $user_id;
           $model->issues_and_values_id = $_REQUEST['issues_and_values_id']; 
           $model->subject = $_REQUEST['subject'];
           if(isset($_REQUEST['is_forwardable'])){
               $model->is_message_forwardable = $_REQUEST['is_forwardable'];
           }else{
              $model->is_message_forwardable = 0; 
           }
           $model->message = $_REQUEST['reply_message'];
           $model->is_to_list_a_network = $is_to_list_a_network;
           $model->is_cc_list_a_network = $is_cc_list_a_network;
           $model->to_recepients_list = implode(',',$to_names); 
           $model->cc_recepients_list = implode(',',$cc_names); 
           $model->from_domain_id = $domain_id;
           $model->parent_id = $_REQUEST['id'];
           $model->category = strtolower("email");
           $model->type = strtolower("inbox");
           $model->code =$model->getTheCodeOfThisMessage($_REQUEST['id']);
           $model->date_sent = new CDbExpression('NOW()');
           $model->date_recieved = new CDbExpression('NOW()');
          
           $counter = 0;
           $bucket_counter = 0;
           //include the asset buckets
           $buckets = [];
          if(is_numeric($_REQUEST['buckets'])){
             if(!empty($_REQUEST['buckets'])){
               foreach($_REQUEST['buckets'] as $buck){
                    $buckets[] = $buck;
                }
                $is_bucket_empty = false;
           }else{
               $is_bucket_empty = true;
           }
               
           }else{
              $is_bucket_empty = true; 
           }
           
   
     //start sending the mails to the users or networks
           $to_message = [];
           $recepient = [];
           $to_net_message = [];
           $network_members = [];
           $all_to_network_members = [];
           if($_REQUEST['is_to_list_a_network'] == 0){
              foreach($mail_recepients as $rec){
                 $model->to_domain_id = $this->determineAUserDomainIdGiven($rec); 
                 $model->to = $rec;
                 $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                 //$recepient[] = $rec;
                 $counter = $counter + 1;
              
              // $message_id = $model->executeTheSendingOfEmailToRecepient($model);  
              
               
           }
           
           //insert the buckets to the messages
         if($is_bucket_empty == false){
           foreach($to_message as $mess){
                      $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                  }
           }
               
           }else{
               
               foreach($mail_recepients as $net){
                   $network_members = $this->getAllTheMembersOfThisNetwork($net);
                   foreach($network_members as $netuser){
                      $model->to_domain_id = $this->determineAUserDomainIdGiven($netuser); 
                       $model->to = $netuser;
                       $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                       $counter = $counter + 1;
                        $all_to_network_members[] = $netuser;
                       
                   }
                    //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach($to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    }
                   
                 
                   
                  
                }
               
           }
           
           //cc mails
          
           $to_message = [];
           if($_REQUEST['is_cc_list_a_network'] == 0){
                foreach($cc_recepients as $cc_reciever){
                       $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_reciever); 
                       $model->to = $cc_reciever;
                       if(in_array($cc_reciever,$mail_recepients) == false){
                            $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                       
                    
                 }//end of the foreach
                //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach( $to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    } 
                
                
            }else{
                 $to_net_message = [];
                 foreach($cc_recepients as $cc_net){
                    $cc_network_members = $this->getAllTheMembersOfThisNetwork($cc_net);
                    if($_REQUEST['is_to_list_a_network'] == 0){
                      foreach($cc_network_members as $cc_netuser){
                       if(in_array($cc_netuser,$mail_recepients) == false){
                            $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_netuser); 
                            $model->to = $cc_netuser;
                            $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                      
                       
                     }
                        
                    }else{
                      foreach($cc_network_members as $cc_netuser){
                       if(in_array($cc_netuser,$all_to_network_members) == false){
                            $model->to_domain_id = $this->determineAUserDomainIdGiven($cc_netuser); 
                            $model->to = $cc_netuser;
                            $to_message[] = $model->executeTheSendingOfEmailToRecepient($model);
                            //$recepient[] = $rec;
                            $counter = $counter + 1;
                       }
                      
                       
                     }
                        
                    }
                    
                     //insert the buckets to the messages
                    if($is_bucket_empty == false){
                        foreach($to_message as $mess){
                            $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($mess,$buckets);
                        }
                    }
                   
                  
                     
                 }
                
                
            }
               
   
            
        //write to the outbox here
         $model->writeTheseEmailMessageToTheSenderOutbox($model,$buckets,$is_bucket_empty);        
            
           if($counter>0){
                 $added_buckets = $bucket_counter/$counter;
            }
            $msg = "Email had been sent to $counter recepient(s) and  $added_buckets asset buckets were successfully added to each of the message recepients";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    "recepients"=>$mail_recepients,
                                  // "for_inbox"=>$recepient,
                                    "message_id"=>$to_message,
                                   "net_members"=>$network_members,
                                  "cc_rece"=>$cc_recepients
                                        
                                   
                            ));
            
        }
        
        
        /**
         * This is the function that retrieves the colleagues of this member
         */
        public function actionretrieveThisMemberAllColleagues(){

	$model = new MemberHasColleagues();
        
        $user_id = Yii::app()->user->id;
        
        $colleagues = $model->getAllTheColleaguesOfThisMember($user_id);
        
        $targets = [];
        
        foreach($colleagues as $col){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$col);
            $user= User::model()->find($criteria);
            $targets[] = $user;
            
        }
         if($colleagues===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "colleague" => $targets,
                     
                       ));
                       
                }
        


        }
        
        
        /**
         * This is the function that gets all the networks of this user depending on issues and values
         */
        public function actionretrieveAllMemberConnectedNetworksBasedOnIssuesAndValues(){
            $model = new NetworkHasMembers;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $issue = $_REQUEST['issues_and_values'];
            
            $preference = $_REQUEST['preference'];
            
            $targets = [];
            
            $member_networks = $model->getAllTheNetworksWhereThisMemberIsConnectedTo($user_id);
            
        if($issue !=""){
             foreach($member_networks as $net){
                 if($preference == strtolower("own_domain")){
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='id=:id';
                        $criteria->params = array(':id'=>$net);
                        $network= Network::model()->find($criteria);
                        if($this->isThisNetworkForThisIssueAndValue($network['issues_and_values_id'],$issue)){
                            if($network['domain_id'] == $domain_id){
                                $targets[] = $network;
                            }
                        }
                        
                
                }else if($preference ==strtolower("other_domain") ){
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='id=:id';
                        $criteria->params = array(':id'=>$net);
                        $network= Network::model()->find($criteria);
                        if($this->isThisNetworkForThisIssueAndValue($network['issues_and_values_id'],$issue)){
                             if($network['domain_id'] != $domain_id){
                                $targets[] = $network;
                            }
                        }
                    
                }
                 
                
                
            }
            if($member_networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $targets,
                     
                       ));
                       
                }
                
            
            
        }else{
             foreach($member_networks as $net){
                 if($preference == strtolower("own_domain")){
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='id=:id';
                        $criteria->params = array(':id'=>$net);
                        $network= Network::model()->find($criteria);
                       if($network['domain_id'] == $domain_id){
                           $targets[] = $network;
                       }
                         
                        
                
                }else if($preference ==strtolower("other_domain") ){
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='id=:id and domain_id!=:domainid';
                        $criteria->params = array(':id'=>$net,':domainid'=>$domain_id);
                        $network= Network::model()->find($criteria);
                          if($network['domain_id'] != $domain_id){
                           $targets[] = $network;
                            }
                    
                }
              
            }
             if($member_networks===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "network" => $targets,
                           "member_network"=>$member_networks
                     
                       ));
                       
                }
            
        }
           
                      
            
        }
        
        
        /**
         * This is the function that determines if networks issue and values is the same as the issue and value under consideration
         */
        public function isThisNetworkForThisIssueAndValue($network_issues_and_values_id,$discussed_issue){
            if($network_issues_and_values_id ==$discussed_issue ){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that retrieves all the available issues and values for a member for chat messages
         */
        public function actionretrieveThisMemberAllIssuesAndValuesBasedOnPreference(){
            
            $model = new IssuesAndValues;
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $preference = $_REQUEST['preference'];
            
                       
            $targets = [];
            
                    
           if($preference == strtolower("own_domain")){
                        $criteria = new CDbCriteria();
                        $criteria->select = '*';
                        $criteria->condition='domain_id=:domainid';
                        $criteria->params = array(':domainid'=>$domain_id);
                        $values= IssuesAndValues::model()->findAll($criteria);
                        foreach($values as $value){
                            if($model->isThisIssueAndValueAvailableForAMemberOrColleagues($value['id'],$user_id)){
                                $targets[] = $value;
                            }
                            
                        }
                    
           }else if($preference == strtolower("other_domain")){
               
               //get all partners of this domain
               $partners = $this->getAllThePartnersOfThisDomain($domain_id);
               foreach($partners as $partner){
                   $criteria = new CDbCriteria();
                   $criteria->select = '*';
                   $criteria->condition='domain_id=:domainid and domain_id!=:owndomainid';
                   $criteria->params = array(':domainid'=>$partner,':owndomainid'=>$domain_id);
                   $values= IssuesAndValues::model()->findAll($criteria);
                   foreach($values as $value){
                           if($model->isThisIssueAndValueAvailableForAMemberOrColleagues($value['id'],$user_id)){
                                $targets[] = $value;
                            }
                        }
               }
           }
               
           if($values===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "issue" => $targets,
                          
                     
                       ));
                       
                }
                    
        
            
        }
        
        
        /**
         * This is the function that retrieves all partners of a domain
         */
        public function getAllThePartnersOfThisDomain($domain_id){
            $model = new DomainHasPartners;
            return $model->getAllThePartnersOfThisDomain($domain_id);
        }
        
        
        
        
        /**
         * This is the function that retrieves all chat messages for a user based on the issues and values
         */
        public function actionretrieveThisMemberAllChatMessagesBasedOnIssuesAndValues(){
            
            $model = new IssuesAndValues;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            
            $issue = $_REQUEST['issues_and_values'];
                       
            if($issue>0){
                
                //get all the chat messages a user sent
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='((is_group_messaging=:groupmess and issues_and_values_id=:issue) and (category=:cat and (`from`=:from and type=:type) or (category=:cat and (type=:ttype and `to`=:to))))';
                $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':issue'=>$issue,':ttype'=>"inbox",':to'=>$user_id,':groupmess'=>0);
                $criteria->order='id,parent_id';
                $messages= Message::model()->findAll($criteria);
                
                if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $messages,
                     
                       ));
                       
                }
                
            }else{
                //get all the chat messages a user sent
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(is_group_messaging=:groupmess and (category=:cat and (`from`=:from and type=:type) or (category=:cat and (type=:ttype and `to`=:to))))';
                $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':to'=>$user_id,':ttype'=>"inbox",':groupmess'=>0);
                $criteria->order='id,parent_id';
                $messages= Message::model()->findAll($criteria);
                
                if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $messages,
                     
                       ));
                       
                }
            }
        }
        
        
        /**
         * This is the function that sends a chat message to the colleagues of a member
         */
        public function actionsendchatmessagetocolleaguesofthismember(){
           $model = new Message;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $issue = $_REQUEST['issues_and_values'];
            $message = $_REQUEST['message'];
            $bucket_counter = 0;
            $counter = 0;
            $category = strtolower('chat');
            $is_group = 0;
           $code = $model->generateTheCodeForThisMessage($user_id,$domain_id,$issue,$category);
        
           //include the asset buckets
            $buckets = [];
           if(empty($_REQUEST['buckets']) == false){
               foreach($_REQUEST['buckets'] as $buck){
                   if(!is_numeric($buck)){
                       $is_bucket_empty = true;
                   }else{
                      $buckets[] = $buck; 
                      $is_bucket_empty = false;
                   }
                    
                }
                
           
           }else{
              $is_bucket_empty = true; 
           }
          
        
           
           $file_error_counter = 0;
           
           
           //move the mesage file if available
      if($message == ""){
                if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeAndSizeAcceptable()){
                        
                      $filename = $_FILES['filename']['name'];
                      $filename_size = $_FILES['filename']['size'];
                      $file_type =  $_FILES['filename']['type'];
                      
                      if($file_type == "application/pdf"){
                          $content_type = "document";
                      }else if($file_type == "image/png"){
                          $content_type = "image";
                      }else if($file_type == "image/jpg"){
                           $content_type = "image";
                      }else if($file_type == "image/jpeg"){
                          $content_type = "image";
                      }else if($file_type == "video/mp4"){
                          $content_type = "video";
                      }else if($file_type == "audio/mp3"){
                          $content_type = "audio";
                      }else{
                         $content_type = "text"; 
                      }
                        
                    }else{
                       
                        $file_error_counter = $file_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $filename =null;
                   $filename_size = 0;
                   $content_type = "text";
                   $file_error_counter = 0;
             
                }
                
               
            }else{
                 $content_type = "text";
                 $filename = null;
                 $file_error_counter = 0;
                 $filename_size = 0;
            }
            
        if($file_error_counter == 0){
            //move this file asset to its location and return a unique filename
            if($content_type !== "text"){
                 $filename_for_use = $model->moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type);
            }else{
                $filename_for_use=null;
            }
           
            $filesize = $filename_size;
            
        }
      
                //get all the colleagues of this member
          $colleagues = $this->getAllTheColleaguesOfThisMember($user_id);
        
            //send the chat message to all eligible colleagues
        foreach($colleagues as $col){
            if($col != $user_id){
                if($this->isThisColleagueEligibleForThisMessage($issue,$col)){
                 $message_id =$model->executesendingChatMessageToThisColleague($issue,$col,$message,$code,$user_id,$domain_id,$content_type,$filesize,$filename_for_use,$is_group);
                    $counter = $counter + 1;
                    
                    //insert the buckets to the message if available
                   if($is_bucket_empty == false){
                        $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($message_id,$buckets);
                    }
                   
             }
            }
             
        }
                
                 
       
             //write to the chat message outbox here
        $model->writeThisChatMessageToTheSenderOutbox($issue,$message,$code,$buckets,$is_bucket_empty,$user_id,$domain_id,$content_type,$filesize,$filename_for_use,$is_group);        
            if($counter>0){
                 $added_buckets = $bucket_counter/$counter;
            }else{
                $added_buckets=0;
            }
       
     
          
                                 
            $msg = "Chat messages had  been sent to authorised recepients";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                                                      
                            ));
            
            
            
        }
        
        
        /**
         * This is the function that retrieves the colleagues of a user 
         */
        public function getAllTheColleaguesOfThisMember($user_id){
            $model = new MemberHasColleagues;
            return $model->getAllTheColleaguesOfThisMember($user_id);
        }
        
        
        /**
         * This is the function to generate message code
         */
        public function generateTheCodeForThisMessage($user_id,$domain_id,$issue,$category){
            $model = new Message;
            return $model->generateTheCodeForThisMessage($user_id, $domain_id, $issue, $category);
        }
        
        
        /**
         * This is the function that determines if a colleague is eligible for a chat message reciept
         */
        public function isThisColleagueEligibleForThisMessage($issue_id,$member_id){
            $model = new IssuesForMember;
            return $model->isThisColleagueEligibleForThisMessage($issue_id,$member_id);
        }
        
        
        /**
         * This is the function that retrieves all the assets attached to a chat message
         */
        public function actionretrieveallassetsforthischatmessage(){
            
            $model = new MessageHasBuckets();
            
            $message_id = $_REQUEST['message_id'];
            
            //get all the buckets in this message
            $buckets = $model->getAllBucketsForThisMessage($message_id);
            
            $targets = [];
            
            foreach($buckets as $bucket){
               //get all the assets in this bucket
                $assets =$this->retrieveAllAssetsForThisBucket($bucket);
                foreach($assets as $asset){
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='id=:id';
                     $criteria->params = array(':id'=>$asset);
                     $asset= DomainAssets::model()->find($criteria);
                     
                     $targets[] = $asset;
                }
                
            }
             if($buckets===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "asset" => $targets,
                     
                       ));
                       
                }
            
            
        }
        
        /**
         * This is the function that retrieves all assets in a bucket
         */
        public function retrieveAllAssetsForThisBucket($bucket){
            $model = new BucketHasAssets;
            return $model->retrieveAllAssetsForThisBucket($bucket);
        }
        
       
        /**
         * This is the function that replies to a chat
         */
        public function actionreplyingtoachatmessagetoColleagues(){
            
            $model = new Message;
            
            $user_id = Yii::app()->user->id;
            
            $message_id = $_REQUEST['message_id'];
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $issue = $model->getTheIssueAndValueIdOfThisMessage($message_id);
            $message = $_REQUEST['message'];
            $bucket_counter = 0;
            $counter = 0;
            $category = strtolower('chat');
            $is_group = 0;
            $code = $model->getTheCodeOfThisMessage($message_id);
           //include the asset buckets
            $buckets = [];
            
          if(empty($_REQUEST['buckets']) == false){
               foreach($_REQUEST['buckets'] as $buck){
                   if(!is_numeric($buck)){
                       $is_bucket_empty = true;
                   }else{
                      $buckets[] = $buck; 
                      $is_bucket_empty = false;
                   }
                    
                }
                
           
           }else{
              $is_bucket_empty = true; 
           }
           
           
           $file_error_counter = 0;
            
                //move the mesage file if available
      if($message == ""){
                if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeAndSizeAcceptable()){
                        
                      $filename = $_FILES['filename']['name'];
                      $filename_size = $_FILES['filename']['size'];
                      $file_type =  $_FILES['filename']['type'];
                      
                      if($file_type == "application/pdf"){
                          $content_type = "document";
                      }else if($file_type == "image/png"){
                          $content_type = "image";
                      }else if($file_type == "image/jpg"){
                           $content_type = "image";
                      }else if($file_type == "image/jpeg"){
                          $content_type = "image";
                      }else if($file_type == "video/mp4"){
                          $content_type = "video";
                      }else if($file_type == "audio/mp3"){
                          $content_type = "audio";
                      }else{
                         $content_type = "text"; 
                      }
                        
                    }else{
                       
                        $file_error_counter = $file_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $filename =null;
                   $filename_size = 0;
                   $content_type = "text";
                   $file_error_counter = 0;
             
                }
                
               
            }else{
                 $content_type = "text";
                 $filename = null;
                 $file_error_counter = 0;
                 $filename_size = 0;
            }
            
        if($file_error_counter == 0){
            //move this file asset to its location and return a unique filename
            if($content_type !== "text"){
                 $filename_for_use = $model->moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type);
            }else{
                $filename_for_use=null;
            }
           
            $filesize = $filename_size;
            
        }
           
           //get all the colleagues of this member
            $colleagues = $this->getAllTheColleaguesOfThisMember($user_id);
            
            //send the chat message to all eligible colleagues
            foreach($colleagues as $col){
                if($col != $user_id){
                  if($this->isThisColleagueEligibleForThisMessage($issue,$col)){
                    $new_message_id =$model->replyingThisChatMessageToThisColleague($message_id,$issue,$col,$message,$code,$user_id,$domain_id,$filename_for_use,$content_type,$filesize,$is_group);
                    $counter = $counter + 1;
                }
                
                 //insert the buckets to the message if available
                    if($is_bucket_empty == false){
                        $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($new_message_id,$buckets);
                    }
                }
             
            }
            
             //write to the chat message outbox here
         $model->writeTheReplyToChatMessageToTheSenderOutbox($message_id,$issue,$message,$code,$buckets,$is_bucket_empty,$user_id,$domain_id,$filename_for_use,$content_type,$filesize,$is_group);        
          
        
            $added_buckets = $bucket_counter/($counter +1);
            $msg = "Chat Message had been sent to $counter recepient(s) and  $added_buckets asset buckets were successfully added to each of the message recepients";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    
                                  
                                   
                            ));
            
            
            
        }
        
        
        /**
         * This is the function that retreives an extra data for a chat message
         */
        public function actiongetExtraInformationAboutChatMessage(){
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "user_from" => "Uche Ngadi",
                                    "from_domain"=>"Platform"
                                    
                                  
                                   
                            ));
        }
        
        
        /**
         * This is the function that retrieves a message assets content
         */
        public function actionretrievethisMessageAssetContent(){
            $model = new DomainAssets;
            $asset_id = $_REQUEST['asset_id'];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$asset_id);
             $asset= DomainAssets::model()->find($criteria);
            
            if($asset===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "asset" => $asset,
                     
                       ));
                       
                }
             
             
        }
        
        /**
         * This is the function that retrieves a message content
        */
        public function actionretrievethisMessageContent(){
            $message_id = $_REQUEST['message_id'];
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='id=:id';
             $criteria->params = array(':id'=>$message_id);
             $message= Message::model()->find($criteria);
            
            if($message===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $message,
                     
                       ));
                       
                }
        }
        
        
        /**
         * This is the platform that deletes a message from the workboard
         */
        public function actiondeletemessagefromtheworkboard(){
           // $model = new Message;
                      
           $message_id = $_REQUEST['message_id'];
           
            $model=Message::model()->findByPk($message_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "msg" => $msg
                
                       ));
                                      
            }else if($model->isTheMessageOnDeliberation($message_id) == false){
               if($model->isMessageWithAssets($message_id) == false){
                    
                 if($model->delete()){
                    $msg = "This message is successfully deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                               "msg" => $msg
                          
                          
                       ));
                 }else{
                     $msg = "Message could not be deleted"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                     
                 }    
                    
                }else{
                   if($model->isRemovalOfAllAssetsFromMessageSuccessful($message_id)){
                        if($model->delete()){
                            $msg = "This message is successfully deleted"; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                 "msg" => $msg
                          
                          
                         ));
                        }else{
                             $msg = "Message could not be deleted"; 
                            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() != 0,
                                "msg" => $msg
                          
                          
                            ));
                     
                 }  
                }else{
                    $msg = "Message could not be deleted as the detachment of assets from the message was not successful"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                    
                } 
              }
                
            
                
               
                       
            }else {
                    $msg = "This message could not be deleted because deliberation had already commenced on it"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                             "msg" => $msg
                          
                       ));
                            
                }
            
            
        }
        
        
        /**
         * This is the function tat confirms if the deletion of message deliberation is a success
         */
        public function isTheRemovalOfTheDeliberationOfThisMessageASuccess($message_id){
            $model = new MessageDeliberation;
            return $model->isTheRemovalOfTheDeliberationOfThisMessageASuccess($message_id);
        }
        
        
        /**
         * This is the function that retrieves all chat messages sent to a user connected network groups 
         */
        public function actionretrieveAllChatMessagesToThisUserNetworkGroups(){
            $model = new NetworkHasMessages;
            
            $user_id = Yii::app()->user->id;
            
            $group_id = $_REQUEST['group_id'];
            
             $issue = $_REQUEST['issues_and_values'];
            if($group_id == 0){
              if($issue == 0){
                    //retrieve all group messages based on all issues
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(is_group_messaging=:groupmess and (category=:cat and (`from`=:from and type=:type) or (category=:cat and (type=:ttype and `to`=:to))))';
                $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':to'=>$user_id,':ttype'=>"inbox",':groupmess'=>1);
                $criteria->order='id,parent_id';
                $messages= Message::model()->findAll($criteria);
             }else{
                    //retrieve all group messages based on a particular issues
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='((is_group_messaging=:groupmess and issues_and_values_id=:issue) and (category=:cat and (`from`=:from and type=:type) or (category=:cat and (type=:ttype and `to`=:to))))';
                $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':issue'=>$issue,':ttype'=>"inbox",':to'=>$user_id,':groupmess'=>1);
                $criteria->order='id,parent_id';
                $messages= Message::model()->findAll($criteria);
                }
                 if($messages===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $messages,
                     
                       ));
                       
                }
          }else{
              $targets = [];
              //get all messages to a particular group
              $group_messages = $model->getAllTheMesagesForThisGroup($group_id);
             if($issue == 0){
                    //retrieve all particular group messages based on all issues
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='(is_group_messaging=:groupmess and (category=:cat and (`from`=:from and type=:type) or (category=:cat and (type=:ttype and `to`=:to))))';
                $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':to'=>$user_id,':ttype'=>"inbox",':groupmess'=>1);
                $criteria->order='id,parent_id';
                $messages= Message::model()->findAll($criteria);
                foreach($messages as $mess){
                    if(in_array($mess['id'],$group_messages)){
                        $targets[] = $mess;
                    }
                }
             }else{
                    //retrieve all particular group messages based on a particular issues
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='((is_group_messaging=:groupmess and issues_and_values_id=:issue) and (category=:cat and (`from`=:from and type=:type) or (category=:cat and (type=:ttype and `to`=:to))))';
                $criteria->params = array(':cat'=>"chat",':from'=>$user_id,':type'=>"outbox",':issue'=>$issue,':ttype'=>"inbox",':to'=>$user_id,':groupmess'=>1);
                $criteria->order='id,parent_id';
                $messages= Message::model()->findAll($criteria);
                foreach($messages as $mess){
                    if(in_array($mess['id'],$group_messages)){
                        $targets[] = $mess;
                    }
                }
              }
               if($targets===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                }else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "message" => $targets,
                           "group_mesages"=>$group_messages,
                           "all_messages"=>$messages
                     
                       ));
                       
                }
                
            }
            
           
        }
        
        
          /**
         * This is the function that sends a chat message to a members group
         */
        public function actionsendchatmessagetomembernetworkgroup(){
           $model = new Message;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $issue = $_REQUEST['issues_and_values'];
            $group_id = $_REQUEST['group_id'];
            $message = $_REQUEST['message'];
            $bucket_counter = 0;
            $counter = 0;
            $category = strtolower('chat');
            
           $code = $model->generateTheCodeForThisMessage($user_id,$domain_id,$issue,$category);
        
           //include the asset buckets
            $buckets = [];
           if(empty($_REQUEST['buckets']) == false){
               foreach($_REQUEST['buckets'] as $buck){
                   if(!is_numeric($buck)){
                       $is_bucket_empty = true;
                   }else{
                      $buckets[] = $buck; 
                      $is_bucket_empty = false;
                   }
                    
                }
                
           
           }else{
              $is_bucket_empty = true; 
           }
          
        
           
           $file_error_counter = 0;
           
           
           //move the mesage file if available
      if($message == ""){
                if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeAndSizeAcceptable()){
                        
                      $filename = $_FILES['filename']['name'];
                      $filename_size = $_FILES['filename']['size'];
                      $file_type =  $_FILES['filename']['type'];
                      
                      if($file_type == "application/pdf"){
                          $content_type = "document";
                      }else if($file_type == "image/png"){
                          $content_type = "image";
                      }else if($file_type == "image/jpg"){
                           $content_type = "image";
                      }else if($file_type == "image/jpeg"){
                          $content_type = "image";
                      }else if($file_type == "video/mp4"){
                          $content_type = "video";
                      }else if($file_type == "audio/mp3"){
                          $content_type = "audio";
                      }else{
                         $content_type = "text"; 
                      }
                        
                    }else{
                       
                        $file_error_counter = $file_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $filename =null;
                   $filename_size = 0;
                   $content_type = "text";
                   $file_error_counter = 0;
             
                }
                
               
            }else{
                 $content_type = "text";
                 $filename = null;
                 $file_error_counter = 0;
                 $filename_size = 0;
            }
            
        if($file_error_counter == 0){
            //move this file asset to its location and return a unique filename
            if($content_type !== "text"){
                 $filename_for_use = $model->moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type);
            }else{
                $filename_for_use=null;
            }
           
            $filesize = $filename_size;
            
        }
      
                    
     if($group_id > 0){
               //get all the members of a group
          $group_members = $this->getAllTheMembersOfThisMemberGroup($group_id);
          $is_group=1;
                   //send the chat message to all eligible colleagues
        foreach($group_members as $col){
              if($this->isThisColleagueEligibleForThisMessage($issue,$col)){
                 $message_id =$model->executesendingChatMessageToThisColleague($issue,$col,$message,$code,$user_id,$domain_id,$content_type,$filesize,$filename_for_use,$is_group);
                    $counter = $counter + 1;
                    
                    //insert the buckets to the message if available
                   if($is_bucket_empty == false){
                        $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($message_id,$buckets);
                    }
                    //add message to a group
                    if($message_id>0){
                         $this->addThisMessageToTheGroup($message_id,$group_id);
                    }
                   
             }
            
            
        }
                
                 
       
             //write to the chat message outbox here
       $outbox_message_id= $model->writeThisChatMessageToTheSenderOutbox($issue,$message,$code,$buckets,$is_bucket_empty,$user_id,$domain_id,$content_type,$filesize,$filename_for_use,$is_group);        
        //add  this message to the group
       if($outbox_message_id>0){
           $this->addThisMessageToTheGroup($outbox_message_id,$group_id);   
       }
        
       if($counter>0){
                 $added_buckets = $bucket_counter/$counter;
            }else{
                $added_buckets=0;
            }
       
     
          
                                 
            $msg = "Chat messages had  been sent to authorised recepients";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                                                      
                            ));
              
          }else{
               $msg = "You have not identified the group to send this message to as no group is currently selected";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                                                      
                            ));
          }
        
       
            
            
            
        }
        
        
        /**
         * This is the function that retrieves all members of a group
         */
        public function getAllTheMembersOfThisMemberGroup($group_id){
            $model = new NetworkHasMembers;
            return $model->getAllTheMembersOfThisNetwork($group_id);
        }
       
        
        /**
         * This is the function that replies to a chat
         */
        public function actionreplyingtoachatmessagetousergroupmembers(){
            
            $model = new Message;
            
            $user_id = Yii::app()->user->id;
            
            $message_id = $_REQUEST['message_id'];
            
            $domain_id = $this->determineAUserDomainIdGiven($user_id);
            $issue = $model->getTheIssueAndValueIdOfThisMessage($message_id);
            $group_id = $_REQUEST['group_id'];
            $message = $_REQUEST['message'];
            $bucket_counter = 0;
            $counter = 0;
            $category = strtolower('chat');
            $is_group = 1;
            $code = $model->getTheCodeOfThisMessage($message_id);
           //include the asset buckets
            $buckets = [];
            
           if(empty($_REQUEST['buckets']) == false){
               foreach($_REQUEST['buckets'] as $buck){
                   if(!is_numeric($buck)){
                       $is_bucket_empty = true;
                   }else{
                      $buckets[] = $buck; 
                      $is_bucket_empty = false;
                   }
                    
                }
                
           
           }else{
              $is_bucket_empty = true; 
           }
           
           
           $file_error_counter = 0;
            
                //move the mesage file if available
      if($message == ""){
                if($_FILES['filename']['name'] != ""){
                    if($model->isFileTypeAndSizeAcceptable()){
                        
                      $filename = $_FILES['filename']['name'];
                      $filename_size = $_FILES['filename']['size'];
                      $file_type =  $_FILES['filename']['type'];
                      
                      if($file_type == "application/pdf"){
                          $content_type = "document";
                      }else if($file_type == "image/png"){
                          $content_type = "image";
                      }else if($file_type == "image/jpg"){
                           $content_type = "image";
                      }else if($file_type == "image/jpeg"){
                          $content_type = "image";
                      }else if($file_type == "video/mp4"){
                          $content_type = "video";
                      }else if($file_type == "audio/mp3"){
                          $content_type = "audio";
                      }else{
                         $content_type = "text"; 
                      }
                        
                    }else{
                       
                        $file_error_counter = $file_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $filename =null;
                   $filename_size = 0;
                   $content_type = "text";
                   $file_error_counter = 0;
             
                }
                
               
            }else{
                 $content_type = "text";
                 $filename = null;
                 $file_error_counter = 0;
                 $filename_size = 0;
            }
            
        if($file_error_counter == 0){
            //move this file asset to its location and return a unique filename
            if($content_type !== "text"){
                 $filename_for_use = $model->moveThisFileToItsLocationAndReturnTheUniqueFilename($model,$filename,$content_type);
            }else{
                $filename_for_use=null;
            }
           
            $filesize = $filename_size;
            
        }
           
        if($group_id>0){
              //get all the members of a group
          $group_members = $this->getAllTheMembersOfThisMemberGroup($group_id);
            
            //send the chat message to all eligible colleagues
            foreach($group_members as $col){
               
                    if($this->isThisColleagueEligibleForThisMessage($issue,$col)){
                    $new_message_id =$model->replyingThisChatMessageToThisColleague($message_id,$issue,$col,$message,$code,$user_id,$domain_id,$filename_for_use,$content_type,$filesize,$is_group);
                    $counter = $counter + 1;
                    
                    //add message to network
                    
                }
                
                 //insert the buckets to the message if available
                    if($is_bucket_empty == false){
                        $bucket_counter = $bucket_counter +  $this->attachTheAssetsInTheBucket($new_message_id,$buckets);
                    }
                    
                     //add  this message to the group
                    if($new_message_id>0){
                         $this->addThisMessageToTheGroup($new_message_id,$group_id);
                    }
                
                
                   
            }
            
             //write to the chat message outbox here
         $outbox_new_message_id = $model->writeTheReplyToChatMessageToTheSenderOutbox($message_id,$issue,$message,$code,$buckets,$is_bucket_empty,$user_id,$domain_id,$filename_for_use,$content_type,$filesize,$is_group);        
            
          //add  this message to the group
         if($outbox_new_message_id>0){
               $this->addThisMessageToTheGroup($outbox_new_message_id,$group_id);
         }
         
           
            if($counter>0){
                 $added_buckets = $bucket_counter/$counter;
            }else{
                $added_buckets=0;
            }
       
            $msg = "Chat Message had been sent to $counter recepient(s) and  $added_buckets asset buckets were successfully added to each of the message recepients";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "msg" => $msg,
                                    
                                  
                                   
                            ));
            
            
        }else{
            $msg = "You have not identified the group to send this message to as no group is currently selected";
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg,
                                                                      
                            ));
        }
           
            
            
            
        }
        
        
        /**
         * This is the function that adds messages to network group
         */
        public function addThisMessageToTheGroup($new_message_id,$group_id){
            $model = new NetworkHasMessages;
            return $model->addThisMessageToTheGroup($new_message_id,$group_id);
        }
        
        
        
         /**
         * This is the platform that deletes a group message from the workboard
         */
        public function actiondeletegroupmessagefromtheworkboard(){
            $model = new Message;
                      
           $message_id = $_REQUEST['message_id'];
           
           $group_id = $_REQUEST['group_id'];
           
            $model=Message::model()->findByPk($message_id);
            if($model === null){
                 $msg = 'No Such Record Exist'; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "msg" => $msg
                
                       ));
                                      
            }else if($this->isThisMessageAvailableInThisGroup($message_id,$group_id)){
                if($model->isTheMessageOnDeliberation($message_id) == false){
                    if($this->isMessageRemovedFromNetwork($message_id,$group_id)){
                      if($model->isMessageWithAssets($message_id) == false){
                    
                        if($model->delete()){
                            $msg = "This message is successfully deleted"; 
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                "success" => mysql_errno() == 0,
                               "msg" => $msg
                          
                          
                            ));
                     }else{
                        $msg = "Message could not be deleted"; 
                        header('Content-Type: application/json');
                        echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                     
                 }    
                    
                }else{
                   if($model->isRemovalOfAllAssetsFromMessageSuccessful($message_id)){
                        if($model->delete()){
                            $msg = "This message is successfully deleted"; 
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                 "msg" => $msg
                          
                          
                         ));
                        }else{
                             $msg = "Message could not be deleted"; 
                            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() != 0,
                                "msg" => $msg
                          
                          
                            ));
                     
                 }  
                }else{
                    $msg = "Message could not be deleted as the detachment of assets from the message was not successful"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                               "msg" => $msg
                          
                          
                       ));
                    
                } 
              }
                
            
                
               
                       
            }else {
                     $msg = "This message could not be removed from this group. Please contact customer service for assistance"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                             "msg" => $msg
                          
                       ));
                            
                }
                    
                    
                    
                }else{
                   $msg = "This message could not be deleted because deliberation had already commenced on it"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                             "msg" => $msg
                          
                       ));
                }
                
                
                
            }else{
                $msg = "This message could not be deleted because it is has no bearing with the selected group"; 
                    header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                             "msg" => $msg
                          
                       ));
                
            }
            
            
        }
        
        /**
         * This is the message that confirms if a message is available to a group
         */
        public function isThisMessageAvailableInThisGroup($message_id,$group_id){
            $model = new NetworkHasMessages;
            return $model->isThisMessageAlreadyInThisGroup($message_id,$group_id);
        }
        
        
        /**
         * This is the function that removes a message from a network
         */
        public function isMessageRemovedFromNetwork($message_id,$group_id){
            $model = new NetworkHasMessages;
            return $model->isMessageRemovedFromNetwork($message_id,$group_id);
        }
}
