<?php

class VerificationCodeConsumedByUserController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listThisConsumedUserCodes','listAllConsumedVerificationCodes','listThisConsumedUserfeedbackCodes',
                                    'listThisConsumedUserEngagementCodes','listThisConsumedUserFeedbackEngagementCodes','listThisConsumedUserProductAuthenticityCode',
                                    'listThisDomainConsumedUserIdcardCodes','listThisDomainConsumedUserBusinesscardCodes'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all user codes consumed 
         */
        public function actionlistThisConsumedUserCodes(){
            $model = new VerificationCodeConsumedByUser;
            
            $user_id = Yii::app()->user->id;
            
            $targets = [];
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $codes = VerificationCodeConsumedByUser::model()->findAll($criteria);
            
            foreach($codes as $code){
                if($model->isThisCodeGeneratedByThisUser($code['verification_code_id'],$user_id)){
                     If($this->isThisAProductMessageCode($code['verification_code_id'])){
                         $targets[] = $code;
                    }
                }
            }
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$targets,
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that list all consumed verification codes
         */
        public function actionlistAllConsumedVerificationCodes(){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $codes = VerificationCodeConsumedByUser::model()->findAll($criteria);
                                 
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$codes,
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that list all user feedback codes consumed 
         */
        public function actionlistThisConsumedUserfeedbackCodes(){
            $model = new VerificationCodeConsumedByUser;
            
            $user_id = Yii::app()->user->id;
            
            $targets = [];
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $codes = VerificationCodeConsumedByUser::model()->findAll($criteria);
            
            foreach($codes as $code){
                if($model->isThisCodeGeneratedByThisUser($code['verification_code_id'],$user_id)){
                    If($this->isThisAProductFeedbackCode($code['verification_code_id'])){
                         $targets[] = $code;
                    }
                   
                }
            }
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$targets,
                                    
                    
                            ));
                       
                         }
        }
        
        
        
         /**
         * This is the function that list all user engagement codes consumed 
         */
        public function actionlistThisConsumedUserEngagementCodes(){
            $model = new VerificationCodeConsumedByUser;
            
            $user_id = Yii::app()->user->id;
            
            $targets = [];
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $codes = VerificationCodeConsumedByUser::model()->findAll($criteria);
            
            foreach($codes as $code){
                if($model->isThisCodeGeneratedByThisUser($code['verification_code_id'],$user_id)){
                    If($this->isThisAProductEngagementCode($code['verification_code_id'])){
                         $targets[] = $code;
                    }
                   
                }
            }
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$targets,
                                    
                    
                            ));
                       
                         }
        }
        
        
         /**
         * This is the function that list all user aftertaste codes consumed 
         */
        public function actionlistThisConsumedUserFeedbackEngagementCodes(){
            $model = new VerificationCodeConsumedByUser;
            
            $user_id = Yii::app()->user->id;
            
            $targets = [];
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $codes = VerificationCodeConsumedByUser::model()->findAll($criteria);
            
            foreach($codes as $code){
                if($model->isThisCodeGeneratedByThisUser($code['verification_code_id'],$user_id)){
                    If($this->isThisAProductFeedbackEngagementCode($code['verification_code_id'])){
                         $targets[] = $code;
                    }
                   
                }
            }
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$targets,
                                    
                    
                            ));
                       
                         }
        }
        
        
         /**
         * This is the function that list all user product authenticity codes consumed 
         */
        public function actionlistThisConsumedUserProductAuthenticityCode(){
            $model = new VerificationCodeConsumedByUser;
            
            $user_id = Yii::app()->user->id;
            
            $targets = [];
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $codes = VerificationCodeConsumedByUser::model()->findAll($criteria);
            
            foreach($codes as $code){
                if($model->isThisCodeGeneratedByThisUser($code['verification_code_id'],$user_id)){
                    If($this->isThisAProductAuthenticityCode($code['verification_code_id'])){
                         $targets[] = $code;
                    }
                   
                }
            }
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$targets,
                                    
                    
                            ));
                       
                         }
        }
        
        
        /**
         * This is the function that list a domain id card codes that were consumed 
         */
        public function actionlistThisDomainConsumedUserIdcardCodes(){
            $model = new VerificationCodeConsumedByUser;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $targets = [];
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $codes = VerificationCodeConsumedByUser::model()->findAll($criteria);
            
            foreach($codes as $code){
                if($model->isThisCodeGeneratedByAMemberOfThisUserDomain($code['verification_code_id'],$domain_id)){
                   If($this->isThisAnIdCardCode($code['verification_code_id'])){
                         $targets[] = $code;
                   }
                   
                }
            }
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$targets,
                                    
                    
                            ));
                       
                         }
        }
        
        
         /**
         * This is the function that list a domain business card codes that were consumed 
         */
        public function actionlistThisDomainConsumedUserBusinesscardCodes(){
            $model = new VerificationCodeConsumedByUser;
            
            $user_id = Yii::app()->user->id;
            
            $domain_id = $this->getTheDomainIdOfThisUser($user_id);
            
            $targets = [];
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $codes = VerificationCodeConsumedByUser::model()->findAll($criteria);
            
            foreach($codes as $code){
                if($model->isThisCodeGeneratedByAMemberOfThisUserDomain($code['verification_code_id'],$domain_id)){
                    If($this->isThisABusinessCardCode($code['verification_code_id'])){
                         $targets[] = $code;
                    }
                   
                }
            }
            
            if($codes===null) {
                            http_response_code(404);
                             $data['error'] ='No record found';
                             echo CJSON::encode($data);
                        }else {
                             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "code" =>$targets,
                                    
                    
                            ));
                       
                         }
        }
        
        
         /**
         * This is the function that gets the domain id of a user
         */
        public function getTheDomainIdOfThisUser($user_id){
            $model = new User;
            return $model->determineAUserDomainIdGiven($user_id);
        }
        
        
         /**
         * This is the function that determine if a code belongs to business card type
         */
        public function isThisABusinessCardCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisABusinessCardCode($code_id);
        }
        
        
         /**
         * This is the function that determine if a code belongs to id card type
         */
        public function isThisAnIdCardCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisAnIdCardCode($code_id);
        }
        
        /**
         * This is the function that determine if a code belongs to product feedback type
         */
        public function isThisAProductFeedbackCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisAProductFeedbackCode($code_id);
        }
        
        
         /**
         * This is the function that determine if a code belongs to product engagement type
         */
        public function isThisAProductEngagementCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisAProductEngagementCode($code_id);
        }
        
        
          /**
         * This is the function that determine if a code belongs to product after taste type
         */
        public function isThisAProductFeedbackEngagementCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisAProductFeedbackEngagementCode($code_id);
        }
        
        
          /**
         * This is the function that determine if a code belongs to product authenticity type
         */
        public function isThisAProductAuthenticityCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisAProductAuthenticityCode($code_id);
        }
        
        
            /**
         * This is the function that determine if a code belongs to message authenticity type
         */
        public function isThisAProductMessageCode($code_id){
            $model = new EnlistmentVerificationCode;
            return $model->isThisAProductMessageCode($code_id);
        }
}
