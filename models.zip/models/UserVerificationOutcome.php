<?php

/**
 * This is the model class for table "user_verification_outcome".
 *
 * The followings are the available columns in table 'user_verification_outcome':
 * @property string $id
 * @property string $user_id
 * @property integer $is_name_verification_requested
 * @property integer $is_address_verification_requested
 * @property integer $is_bvn_verification_requested
 * @property integer $is_nin_verification_requested
 * @property integer $is_pvc_verification_requested
 * @property integer $is_pension_pin_verification_requested
 * @property integer $is_driver_licence_number_verification_requested
 * @property integer $is_website_verification_requested
 * @property integer $is_email_verification_requested
 * @property integer $is_wechat_verification_requested
 * @property integer $is_telegram_verification_requested
 * @property integer $is_whatsapp_verification_requested
 * @property integer $is_facebook_verification_requested
 * @property integer $is_tweeter_verification_requested
 * @property integer $is_youtube_verification_requested
 * @property integer $is_picture_verification_requested
 * @property integer $is_mobile_number_verification_requested
 * @property integer $is_name_verified
 * @property integer $is_address_verified
 * @property integer $is_bvn_verified
 * @property integer $is_nin_verified
 * @property integer $is_pvc_verified
 * @property integer $is_pension_pin_verified
 * @property integer $is_international_passport_number_verified
 * @property integer $is_drivers_licence_number_verified
 * @property integer $is_website_verified
 * @property integer $is_email_verified
 * @property integer $is_wechat_verified
 * @property integer $is_telegram_verified
 * @property integer $is_whatsapp_verified
 * @property integer $is_facebook_verified
 * @property integer $is_tweeter_verified
 * @property integer $is_youtube_verified
 * @property integer $is_picture_verified
 * @property integer $is_mobile_number_verified
 * @property string $date_name_was_verified
 * @property integer $name_was_verified_by
 * @property string $date_address_was_verified
 * @property integer $address_was_verified_by
 * @property string $date_website_was_verified
 * @property integer $website_was_verified_by
 * @property string $date_email_was_verified
 * @property integer $email_was_verified_by
 * @property string $date_wechat_was_verified
 * @property integer $wechat_was_verified_by
 * @property string $date_telegram_was_verified
 * @property integer $telegram_was_verified_by
 * @property string $date_whatsapp_was_verified
 * @property integer $whatsapp_was_verified_by
 * @property string $date_facebook_was_verified
 * @property integer $facebook_was_verified_by
 * @property string $date_tweeter_was_verified
 * @property integer $tweeter_was_verified_by
 * @property string $date_youtube_was_verified
 * @property integer $youtube_was_verified_by
 * @property string $date_picture_was_verified
 * @property integer $picture_was_verified_by
 * @property string $date_bvn_was_verified
 * @property integer $bvn_was_verified_by
 * @property string $date_nin_was_verified
 * @property integer $nin_was_verified_by
 * @property string $date_pvc_was_verified
 * @property integer $pvc_was_verified_by
 * @property string $date_pension_pin_was_verified
 * @property integer $pension_pin_was_verified_by
 * @property string $date_international_passport_number_was_verified
 * @property integer $international_passport_number_was_verified_by
 * @property string $date_driver_licence_number_was_verified
 * @property integer $driver_licence_number_was_verified_by
 * @property string $date_mobile_number_was_verified
 * @property integer $mobile_number_was_verified_by
 * @property string $date_name_verification_was_requested
 * @property integer $name_was_verification_was_requested_by
 * @property string $date_address_verification_was_requested
 * @property integer $address_verification_request_was_requested_by
 * @property string $date_website_verification_was_request
 * @property integer $website_verification_was_requested_by
 * @property string $date_email_verification_was_requested
 * @property integer $email_verification_was_requested_by
 * @property string $date_wechat_verification_was_requested
 * @property integer $wechat_verification_was_requested_by
 * @property string $date_telegram_verification_was_requested
 * @property integer $telegram_verification_was_requested_by
 * @property string $date_whatsapp_verification_was_requested
 * @property integer $whatsapp_verification_was_requested_by
 * @property string $date_facebook_verification_was_requested
 * @property integer $facebook_verification_was_requested_by
 * @property string $date_tweeter_verification_was_requested
 * @property integer $tweeter_verification_was_requested_by
 * @property string $date_youtube_verification_was_requested
 * @property integer $youtube_verification_was_requested_by
 * @property string $date_picture_verification_was_requested
 * @property integer $picture_verification_was_requested_by
 * @property string $date_bvn_verification_was_requested
 * @property integer $bvn_verification_was_requested_by
 * @property string $date_nin_verification_was_requested
 * @property integer $nin_verification_was_requested_by
 * @property string $date_pvc_verification_was_requested
 * @property integer $pvc_verification_was_requested_by
 * @property string $date_pension_pin_verification_was_requested
 * @property integer $pension_pin_verification_was_requested_by
 * @property string $date_international_passport_number_verification_was_requested
 * @property integer $international_passport_number_verification_was_requested_by
 * @property string $date_driver_licence_number_verification_was_requested
 * @property integer $driver_licence_number_verification_was_requested_by
 * @property string $date_mobile_number_verification_was_requested
 * @property integer $mobile_number_verification_was_requested_by
 * @property integer $is_linkedin_verification_requested
 * @property integer $is_linkedin_verified
 * @property string $date_linkedin_was_verified
 * @property integer $linkedin_was_verified_by
 * @property string $date_linkedin_verification_was_requested
 * @property integer $linkedin_verification_was_requested_by
 * @property integer $is_instagram_verification_requested
 * @property integer $is_instagram_verified
 * @property string $date_instagram_was_verified
 * @property integer $instagram_was_verified_by
 * @property string $date_instagram_verification_was_requested
 * @property integer $instagram_verification_was_requested_by
 * @property integer $is_driver_licence_expiry_verification_requested
 * @property integer $is_residency_expiry_date_verified
 * @property integer $is_international_passport_expiry_verified
 * @property integer $is_drivers_licence_expiry_verified
 * @property integer $is_website_expiry_verified
 * @property integer $is_residency_expiry_verification_requested
 * @property string $date_residency_expiry_verification_was_request
 * @property integer $residency_expiry_verification_was_requested_by
 * @property integer $is_international_passport_number_verification_requested
 * @property integer $is_international_passport_expiry_verification_requested
 * @property string $date_website_expiry_verification_was_request
 * @property integer $website_expiry_verification_was_requested_by
 * @property string $date_international_passport_expiry_verification_was_requested
 * @property integer $international_passport_expiry_verification_was_requested_by
 * @property string $date_driver_licence_expiry_verification_was_requested
 * @property integer $driver_licence_expiry_verification_was_requested_by
 * @property integer $is_website_expiry_verification_requested
 */
class UserVerificationOutcome extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user_verification_outcome';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('user_id', 'required'),
			array('is_name_verification_requested, is_address_verification_requested, is_bvn_verification_requested, is_nin_verification_requested, is_pvc_verification_requested, is_pension_pin_verification_requested, is_driver_licence_number_verification_requested, is_website_verification_requested, is_email_verification_requested, is_wechat_verification_requested, is_telegram_verification_requested, is_whatsapp_verification_requested, is_facebook_verification_requested, is_tweeter_verification_requested, is_youtube_verification_requested, is_picture_verification_requested, is_mobile_number_verification_requested, is_name_verified, is_address_verified, is_bvn_verified, is_nin_verified, is_pvc_verified, is_pension_pin_verified, is_international_passport_number_verified, is_drivers_licence_number_verified, is_website_verified, is_email_verified, is_wechat_verified, is_telegram_verified, is_whatsapp_verified, is_facebook_verified, is_tweeter_verified, is_youtube_verified, is_picture_verified, is_mobile_number_verified, name_was_verified_by, address_was_verified_by, website_was_verified_by, email_was_verified_by, wechat_was_verified_by, telegram_was_verified_by, whatsapp_was_verified_by, facebook_was_verified_by, tweeter_was_verified_by, youtube_was_verified_by, picture_was_verified_by, bvn_was_verified_by, nin_was_verified_by, pvc_was_verified_by, pension_pin_was_verified_by, international_passport_number_was_verified_by, driver_licence_number_was_verified_by, mobile_number_was_verified_by, name_was_verification_was_requested_by, address_verification_request_was_requested_by, website_verification_was_requested_by, email_verification_was_requested_by, wechat_verification_was_requested_by, telegram_verification_was_requested_by, whatsapp_verification_was_requested_by, facebook_verification_was_requested_by, tweeter_verification_was_requested_by, youtube_verification_was_requested_by, picture_verification_was_requested_by, bvn_verification_was_requested_by, nin_verification_was_requested_by, pvc_verification_was_requested_by, pension_pin_verification_was_requested_by, international_passport_number_verification_was_requested_by, driver_licence_number_verification_was_requested_by, mobile_number_verification_was_requested_by, is_linkedin_verification_requested, is_linkedin_verified, linkedin_was_verified_by, linkedin_verification_was_requested_by, is_instagram_verification_requested, is_instagram_verified, instagram_was_verified_by, instagram_verification_was_requested_by, is_driver_licence_expiry_verification_requested, is_residency_expiry_date_verified, is_international_passport_expiry_verified, is_drivers_licence_expiry_verified, is_website_expiry_verified, is_residency_expiry_verification_requested, residency_expiry_verification_was_requested_by, is_international_passport_number_verification_requested, is_international_passport_expiry_verification_requested, website_expiry_verification_was_requested_by, international_passport_expiry_verification_was_requested_by, driver_licence_expiry_verification_was_requested_by, is_website_expiry_verification_requested', 'numerical', 'integerOnly'=>true),
			array('user_id', 'length', 'max'=>10),
			array('date_name_was_verified, date_address_was_verified, date_website_was_verified, date_email_was_verified, date_wechat_was_verified, date_telegram_was_verified, date_whatsapp_was_verified, date_facebook_was_verified, date_tweeter_was_verified, date_youtube_was_verified, date_picture_was_verified, date_bvn_was_verified, date_nin_was_verified, date_pvc_was_verified, date_pension_pin_was_verified, date_international_passport_number_was_verified, date_driver_licence_number_was_verified, date_mobile_number_was_verified, date_name_verification_was_requested, date_address_verification_was_requested, date_website_verification_was_request, date_email_verification_was_requested, date_wechat_verification_was_requested, date_telegram_verification_was_requested, date_whatsapp_verification_was_requested, date_facebook_verification_was_requested, date_tweeter_verification_was_requested, date_youtube_verification_was_requested, date_picture_verification_was_requested, date_bvn_verification_was_requested, date_nin_verification_was_requested, date_pvc_verification_was_requested, date_pension_pin_verification_was_requested, date_international_passport_number_verification_was_requested, date_driver_licence_number_verification_was_requested, date_mobile_number_verification_was_requested, date_linkedin_was_verified, date_linkedin_verification_was_requested, date_instagram_was_verified, date_instagram_verification_was_requested, date_residency_expiry_verification_was_request, date_website_expiry_verification_was_request, date_international_passport_expiry_verification_was_requested, date_driver_licence_expiry_verification_was_requested', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, user_id, is_name_verification_requested, is_address_verification_requested, is_bvn_verification_requested, is_nin_verification_requested, is_pvc_verification_requested, is_pension_pin_verification_requested, is_driver_licence_number_verification_requested, is_website_verification_requested, is_email_verification_requested, is_wechat_verification_requested, is_telegram_verification_requested, is_whatsapp_verification_requested, is_facebook_verification_requested, is_tweeter_verification_requested, is_youtube_verification_requested, is_picture_verification_requested, is_mobile_number_verification_requested, is_name_verified, is_address_verified, is_bvn_verified, is_nin_verified, is_pvc_verified, is_pension_pin_verified, is_international_passport_number_verified, is_drivers_licence_number_verified, is_website_verified, is_email_verified, is_wechat_verified, is_telegram_verified, is_whatsapp_verified, is_facebook_verified, is_tweeter_verified, is_youtube_verified, is_picture_verified, is_mobile_number_verified, date_name_was_verified, name_was_verified_by, date_address_was_verified, address_was_verified_by, date_website_was_verified, website_was_verified_by, date_email_was_verified, email_was_verified_by, date_wechat_was_verified, wechat_was_verified_by, date_telegram_was_verified, telegram_was_verified_by, date_whatsapp_was_verified, whatsapp_was_verified_by, date_facebook_was_verified, facebook_was_verified_by, date_tweeter_was_verified, tweeter_was_verified_by, date_youtube_was_verified, youtube_was_verified_by, date_picture_was_verified, picture_was_verified_by, date_bvn_was_verified, bvn_was_verified_by, date_nin_was_verified, nin_was_verified_by, date_pvc_was_verified, pvc_was_verified_by, date_pension_pin_was_verified, pension_pin_was_verified_by, date_international_passport_number_was_verified, international_passport_number_was_verified_by, date_driver_licence_number_was_verified, driver_licence_number_was_verified_by, date_mobile_number_was_verified, mobile_number_was_verified_by, date_name_verification_was_requested, name_was_verification_was_requested_by, date_address_verification_was_requested, address_verification_request_was_requested_by, date_website_verification_was_request, website_verification_was_requested_by, date_email_verification_was_requested, email_verification_was_requested_by, date_wechat_verification_was_requested, wechat_verification_was_requested_by, date_telegram_verification_was_requested, telegram_verification_was_requested_by, date_whatsapp_verification_was_requested, whatsapp_verification_was_requested_by, date_facebook_verification_was_requested, facebook_verification_was_requested_by, date_tweeter_verification_was_requested, tweeter_verification_was_requested_by, date_youtube_verification_was_requested, youtube_verification_was_requested_by, date_picture_verification_was_requested, picture_verification_was_requested_by, date_bvn_verification_was_requested, bvn_verification_was_requested_by, date_nin_verification_was_requested, nin_verification_was_requested_by, date_pvc_verification_was_requested, pvc_verification_was_requested_by, date_pension_pin_verification_was_requested, pension_pin_verification_was_requested_by, date_international_passport_number_verification_was_requested, international_passport_number_verification_was_requested_by, date_driver_licence_number_verification_was_requested, driver_licence_number_verification_was_requested_by, date_mobile_number_verification_was_requested, mobile_number_verification_was_requested_by, is_linkedin_verification_requested, is_linkedin_verified, date_linkedin_was_verified, linkedin_was_verified_by, date_linkedin_verification_was_requested, linkedin_verification_was_requested_by, is_instagram_verification_requested, is_instagram_verified, date_instagram_was_verified, instagram_was_verified_by, date_instagram_verification_was_requested, instagram_verification_was_requested_by, is_driver_licence_expiry_verification_requested, is_residency_expiry_date_verified, is_international_passport_expiry_verified, is_drivers_licence_expiry_verified, is_website_expiry_verified, is_residency_expiry_verification_requested, date_residency_expiry_verification_was_request, residency_expiry_verification_was_requested_by, is_international_passport_number_verification_requested, is_international_passport_expiry_verification_requested, date_website_expiry_verification_was_request, website_expiry_verification_was_requested_by, date_international_passport_expiry_verification_was_requested, international_passport_expiry_verification_was_requested_by, date_driver_licence_expiry_verification_was_requested, driver_licence_expiry_verification_was_requested_by, is_website_expiry_verification_requested', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'user_id' => 'User',
			'is_name_verification_requested' => 'Is Name Verification Requested',
			'is_address_verification_requested' => 'Is Address Verification Requested',
			'is_bvn_verification_requested' => 'Is Bvn Verification Requested',
			'is_nin_verification_requested' => 'Is Nin Verification Requested',
			'is_pvc_verification_requested' => 'Is Pvc Verification Requested',
			'is_pension_pin_verification_requested' => 'Is Pension Pin Verification Requested',
			'is_driver_licence_number_verification_requested' => 'Is Driver Licence Number Verification Requested',
			'is_website_verification_requested' => 'Is Website Verification Requested',
			'is_email_verification_requested' => 'Is Email Verification Requested',
			'is_wechat_verification_requested' => 'Is Wechat Verification Requested',
			'is_telegram_verification_requested' => 'Is Telegram Verification Requested',
			'is_whatsapp_verification_requested' => 'Is Whatsapp Verification Requested',
			'is_facebook_verification_requested' => 'Is Facebook Verification Requested',
			'is_tweeter_verification_requested' => 'Is Tweeter Verification Requested',
			'is_youtube_verification_requested' => 'Is Youtube Verification Requested',
			'is_picture_verification_requested' => 'Is Picture Verification Requested',
			'is_mobile_number_verification_requested' => 'Is Mobile Number Verification Requested',
			'is_name_verified' => 'Is Name Verified',
			'is_address_verified' => 'Is Address Verified',
			'is_bvn_verified' => 'Is Bvn Verified',
			'is_nin_verified' => 'Is Nin Verified',
			'is_pvc_verified' => 'Is Pvc Verified',
			'is_pension_pin_verified' => 'Is Pension Pin Verified',
			'is_international_passport_number_verified' => 'Is International Passport Number Verified',
			'is_drivers_licence_number_verified' => 'Is Drivers Licence Number Verified',
			'is_website_verified' => 'Is Website Verified',
			'is_email_verified' => 'Is Email Verified',
			'is_wechat_verified' => 'Is Wechat Verified',
			'is_telegram_verified' => 'Is Telegram Verified',
			'is_whatsapp_verified' => 'Is Whatsapp Verified',
			'is_facebook_verified' => 'Is Facebook Verified',
			'is_tweeter_verified' => 'Is Tweeter Verified',
			'is_youtube_verified' => 'Is Youtube Verified',
			'is_picture_verified' => 'Is Picture Verified',
			'is_mobile_number_verified' => 'Is Mobile Number Verified',
			'date_name_was_verified' => 'Date Name Was Verified',
			'name_was_verified_by' => 'Name Was Verified By',
			'date_address_was_verified' => 'Date Address Was Verified',
			'address_was_verified_by' => 'Address Was Verified By',
			'date_website_was_verified' => 'Date Website Was Verified',
			'website_was_verified_by' => 'Website Was Verified By',
			'date_email_was_verified' => 'Date Email Was Verified',
			'email_was_verified_by' => 'Email Was Verified By',
			'date_wechat_was_verified' => 'Date Wechat Was Verified',
			'wechat_was_verified_by' => 'Wechat Was Verified By',
			'date_telegram_was_verified' => 'Date Telegram Was Verified',
			'telegram_was_verified_by' => 'Telegram Was Verified By',
			'date_whatsapp_was_verified' => 'Date Whatsapp Was Verified',
			'whatsapp_was_verified_by' => 'Whatsapp Was Verified By',
			'date_facebook_was_verified' => 'Date Facebook Was Verified',
			'facebook_was_verified_by' => 'Facebook Was Verified By',
			'date_tweeter_was_verified' => 'Date Tweeter Was Verified',
			'tweeter_was_verified_by' => 'Tweeter Was Verified By',
			'date_youtube_was_verified' => 'Date Youtube Was Verified',
			'youtube_was_verified_by' => 'Youtube Was Verified By',
			'date_picture_was_verified' => 'Date Picture Was Verified',
			'picture_was_verified_by' => 'Picture Was Verified By',
			'date_bvn_was_verified' => 'Date Bvn Was Verified',
			'bvn_was_verified_by' => 'Bvn Was Verified By',
			'date_nin_was_verified' => 'Date Nin Was Verified',
			'nin_was_verified_by' => 'Nin Was Verified By',
			'date_pvc_was_verified' => 'Date Pvc Was Verified',
			'pvc_was_verified_by' => 'Pvc Was Verified By',
			'date_pension_pin_was_verified' => 'Date Pension Pin Was Verified',
			'pension_pin_was_verified_by' => 'Pension Pin Was Verified By',
			'date_international_passport_number_was_verified' => 'Date International Passport Number Was Verified',
			'international_passport_number_was_verified_by' => 'International Passport Number Was Verified By',
			'date_driver_licence_number_was_verified' => 'Date Driver Licence Number Was Verified',
			'driver_licence_number_was_verified_by' => 'Driver Licence Number Was Verified By',
			'date_mobile_number_was_verified' => 'Date Mobile Number Was Verified',
			'mobile_number_was_verified_by' => 'Mobile Number Was Verified By',
			'date_name_verification_was_requested' => 'Date Name Verification Was Requested',
			'name_was_verification_was_requested_by' => 'Name Was Verification Was Requested By',
			'date_address_verification_was_requested' => 'Date Address Verification Was Requested',
			'address_verification_request_was_requested_by' => 'Address Verification Request Was Requested By',
			'date_website_verification_was_request' => 'Date Website Verification Was Request',
			'website_verification_was_requested_by' => 'Website Verification Was Requested By',
			'date_email_verification_was_requested' => 'Date Email Verification Was Requested',
			'email_verification_was_requested_by' => 'Email Verification Was Requested By',
			'date_wechat_verification_was_requested' => 'Date Wechat Verification Was Requested',
			'wechat_verification_was_requested_by' => 'Wechat Verification Was Requested By',
			'date_telegram_verification_was_requested' => 'Date Telegram Verification Was Requested',
			'telegram_verification_was_requested_by' => 'Telegram Verification Was Requested By',
			'date_whatsapp_verification_was_requested' => 'Date Whatsapp Verification Was Requested',
			'whatsapp_verification_was_requested_by' => 'Whatsapp Verification Was Requested By',
			'date_facebook_verification_was_requested' => 'Date Facebook Verification Was Requested',
			'facebook_verification_was_requested_by' => 'Facebook Verification Was Requested By',
			'date_tweeter_verification_was_requested' => 'Date Tweeter Verification Was Requested',
			'tweeter_verification_was_requested_by' => 'Tweeter Verification Was Requested By',
			'date_youtube_verification_was_requested' => 'Date Youtube Verification Was Requested',
			'youtube_verification_was_requested_by' => 'Youtube Verification Was Requested By',
			'date_picture_verification_was_requested' => 'Date Picture Verification Was Requested',
			'picture_verification_was_requested_by' => 'Picture Verification Was Requested By',
			'date_bvn_verification_was_requested' => 'Date Bvn Verification Was Requested',
			'bvn_verification_was_requested_by' => 'Bvn Verification Was Requested By',
			'date_nin_verification_was_requested' => 'Date Nin Verification Was Requested',
			'nin_verification_was_requested_by' => 'Nin Verification Was Requested By',
			'date_pvc_verification_was_requested' => 'Date Pvc Verification Was Requested',
			'pvc_verification_was_requested_by' => 'Pvc Verification Was Requested By',
			'date_pension_pin_verification_was_requested' => 'Date Pension Pin Verification Was Requested',
			'pension_pin_verification_was_requested_by' => 'Pension Pin Verification Was Requested By',
			'date_international_passport_number_verification_was_requested' => 'Date International Passport Number Verification Was Requested',
			'international_passport_number_verification_was_requested_by' => 'International Passport Number Verification Was Requested By',
			'date_driver_licence_number_verification_was_requested' => 'Date Driver Licence Number Verification Was Requested',
			'driver_licence_number_verification_was_requested_by' => 'Driver Licence Number Verification Was Requested By',
			'date_mobile_number_verification_was_requested' => 'Date Mobile Number Verification Was Requested',
			'mobile_number_verification_was_requested_by' => 'Mobile Number Verification Was Requested By',
			'is_linkedin_verification_requested' => 'Is Linkedin Verification Requested',
			'is_linkedin_verified' => 'Is Linkedin Verified',
			'date_linkedin_was_verified' => 'Date Linkedin Was Verified',
			'linkedin_was_verified_by' => 'Linkedin Was Verified By',
			'date_linkedin_verification_was_requested' => 'Date Linkedin Verification Was Requested',
			'linkedin_verification_was_requested_by' => 'Linkedin Verification Was Requested By',
			'is_instagram_verification_requested' => 'Is Instagram Verification Requested',
			'is_instagram_verified' => 'Is Instagram Verified',
			'date_instagram_was_verified' => 'Date Instagram Was Verified',
			'instagram_was_verified_by' => 'Instagram Was Verified By',
			'date_instagram_verification_was_requested' => 'Date Instagram Verification Was Requested',
			'instagram_verification_was_requested_by' => 'Instagram Verification Was Requested By',
			'is_driver_licence_expiry_verification_requested' => 'Is Driver Licence Expiry Verification Requested',
			'is_residency_expiry_date_verified' => 'Is Residency Expiry Date Verified',
			'is_international_passport_expiry_verified' => 'Is International Passport Expiry Verified',
			'is_drivers_licence_expiry_verified' => 'Is Drivers Licence Expiry Verified',
			'is_website_expiry_verified' => 'Is Website Expiry Verified',
			'is_residency_expiry_verification_requested' => 'Is Residency Expiry Verification Requested',
			'date_residency_expiry_verification_was_request' => 'Date Residency Expiry Verification Was Request',
			'residency_expiry_verification_was_requested_by' => 'Residency Expiry Verification Was Requested By',
			'is_international_passport_number_verification_requested' => 'Is International Passport Number Verification Requested',
			'is_international_passport_expiry_verification_requested' => 'Is International Passport Expiry Verification Requested',
			'date_website_expiry_verification_was_request' => 'Date Website Expiry Verification Was Request',
			'website_expiry_verification_was_requested_by' => 'Website Expiry Verification Was Requested By',
			'date_international_passport_expiry_verification_was_requested' => 'Date International Passport Expiry Verification Was Requested',
			'international_passport_expiry_verification_was_requested_by' => 'International Passport Expiry Verification Was Requested By',
			'date_driver_licence_expiry_verification_was_requested' => 'Date Driver Licence Expiry Verification Was Requested',
			'driver_licence_expiry_verification_was_requested_by' => 'Driver Licence Expiry Verification Was Requested By',
			'is_website_expiry_verification_requested' => 'Is Website Expiry Verification Requested',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('is_name_verification_requested',$this->is_name_verification_requested);
		$criteria->compare('is_address_verification_requested',$this->is_address_verification_requested);
		$criteria->compare('is_bvn_verification_requested',$this->is_bvn_verification_requested);
		$criteria->compare('is_nin_verification_requested',$this->is_nin_verification_requested);
		$criteria->compare('is_pvc_verification_requested',$this->is_pvc_verification_requested);
		$criteria->compare('is_pension_pin_verification_requested',$this->is_pension_pin_verification_requested);
		$criteria->compare('is_driver_licence_number_verification_requested',$this->is_driver_licence_number_verification_requested);
		$criteria->compare('is_website_verification_requested',$this->is_website_verification_requested);
		$criteria->compare('is_email_verification_requested',$this->is_email_verification_requested);
		$criteria->compare('is_wechat_verification_requested',$this->is_wechat_verification_requested);
		$criteria->compare('is_telegram_verification_requested',$this->is_telegram_verification_requested);
		$criteria->compare('is_whatsapp_verification_requested',$this->is_whatsapp_verification_requested);
		$criteria->compare('is_facebook_verification_requested',$this->is_facebook_verification_requested);
		$criteria->compare('is_tweeter_verification_requested',$this->is_tweeter_verification_requested);
		$criteria->compare('is_youtube_verification_requested',$this->is_youtube_verification_requested);
		$criteria->compare('is_picture_verification_requested',$this->is_picture_verification_requested);
		$criteria->compare('is_mobile_number_verification_requested',$this->is_mobile_number_verification_requested);
		$criteria->compare('is_name_verified',$this->is_name_verified);
		$criteria->compare('is_address_verified',$this->is_address_verified);
		$criteria->compare('is_bvn_verified',$this->is_bvn_verified);
		$criteria->compare('is_nin_verified',$this->is_nin_verified);
		$criteria->compare('is_pvc_verified',$this->is_pvc_verified);
		$criteria->compare('is_pension_pin_verified',$this->is_pension_pin_verified);
		$criteria->compare('is_international_passport_number_verified',$this->is_international_passport_number_verified);
		$criteria->compare('is_drivers_licence_number_verified',$this->is_drivers_licence_number_verified);
		$criteria->compare('is_website_verified',$this->is_website_verified);
		$criteria->compare('is_email_verified',$this->is_email_verified);
		$criteria->compare('is_wechat_verified',$this->is_wechat_verified);
		$criteria->compare('is_telegram_verified',$this->is_telegram_verified);
		$criteria->compare('is_whatsapp_verified',$this->is_whatsapp_verified);
		$criteria->compare('is_facebook_verified',$this->is_facebook_verified);
		$criteria->compare('is_tweeter_verified',$this->is_tweeter_verified);
		$criteria->compare('is_youtube_verified',$this->is_youtube_verified);
		$criteria->compare('is_picture_verified',$this->is_picture_verified);
		$criteria->compare('is_mobile_number_verified',$this->is_mobile_number_verified);
		$criteria->compare('date_name_was_verified',$this->date_name_was_verified,true);
		$criteria->compare('name_was_verified_by',$this->name_was_verified_by);
		$criteria->compare('date_address_was_verified',$this->date_address_was_verified,true);
		$criteria->compare('address_was_verified_by',$this->address_was_verified_by);
		$criteria->compare('date_website_was_verified',$this->date_website_was_verified,true);
		$criteria->compare('website_was_verified_by',$this->website_was_verified_by);
		$criteria->compare('date_email_was_verified',$this->date_email_was_verified,true);
		$criteria->compare('email_was_verified_by',$this->email_was_verified_by);
		$criteria->compare('date_wechat_was_verified',$this->date_wechat_was_verified,true);
		$criteria->compare('wechat_was_verified_by',$this->wechat_was_verified_by);
		$criteria->compare('date_telegram_was_verified',$this->date_telegram_was_verified,true);
		$criteria->compare('telegram_was_verified_by',$this->telegram_was_verified_by);
		$criteria->compare('date_whatsapp_was_verified',$this->date_whatsapp_was_verified,true);
		$criteria->compare('whatsapp_was_verified_by',$this->whatsapp_was_verified_by);
		$criteria->compare('date_facebook_was_verified',$this->date_facebook_was_verified,true);
		$criteria->compare('facebook_was_verified_by',$this->facebook_was_verified_by);
		$criteria->compare('date_tweeter_was_verified',$this->date_tweeter_was_verified,true);
		$criteria->compare('tweeter_was_verified_by',$this->tweeter_was_verified_by);
		$criteria->compare('date_youtube_was_verified',$this->date_youtube_was_verified,true);
		$criteria->compare('youtube_was_verified_by',$this->youtube_was_verified_by);
		$criteria->compare('date_picture_was_verified',$this->date_picture_was_verified,true);
		$criteria->compare('picture_was_verified_by',$this->picture_was_verified_by);
		$criteria->compare('date_bvn_was_verified',$this->date_bvn_was_verified,true);
		$criteria->compare('bvn_was_verified_by',$this->bvn_was_verified_by);
		$criteria->compare('date_nin_was_verified',$this->date_nin_was_verified,true);
		$criteria->compare('nin_was_verified_by',$this->nin_was_verified_by);
		$criteria->compare('date_pvc_was_verified',$this->date_pvc_was_verified,true);
		$criteria->compare('pvc_was_verified_by',$this->pvc_was_verified_by);
		$criteria->compare('date_pension_pin_was_verified',$this->date_pension_pin_was_verified,true);
		$criteria->compare('pension_pin_was_verified_by',$this->pension_pin_was_verified_by);
		$criteria->compare('date_international_passport_number_was_verified',$this->date_international_passport_number_was_verified,true);
		$criteria->compare('international_passport_number_was_verified_by',$this->international_passport_number_was_verified_by);
		$criteria->compare('date_driver_licence_number_was_verified',$this->date_driver_licence_number_was_verified,true);
		$criteria->compare('driver_licence_number_was_verified_by',$this->driver_licence_number_was_verified_by);
		$criteria->compare('date_mobile_number_was_verified',$this->date_mobile_number_was_verified,true);
		$criteria->compare('mobile_number_was_verified_by',$this->mobile_number_was_verified_by);
		$criteria->compare('date_name_verification_was_requested',$this->date_name_verification_was_requested,true);
		$criteria->compare('name_was_verification_was_requested_by',$this->name_was_verification_was_requested_by);
		$criteria->compare('date_address_verification_was_requested',$this->date_address_verification_was_requested,true);
		$criteria->compare('address_verification_request_was_requested_by',$this->address_verification_request_was_requested_by);
		$criteria->compare('date_website_verification_was_request',$this->date_website_verification_was_request,true);
		$criteria->compare('website_verification_was_requested_by',$this->website_verification_was_requested_by);
		$criteria->compare('date_email_verification_was_requested',$this->date_email_verification_was_requested,true);
		$criteria->compare('email_verification_was_requested_by',$this->email_verification_was_requested_by);
		$criteria->compare('date_wechat_verification_was_requested',$this->date_wechat_verification_was_requested,true);
		$criteria->compare('wechat_verification_was_requested_by',$this->wechat_verification_was_requested_by);
		$criteria->compare('date_telegram_verification_was_requested',$this->date_telegram_verification_was_requested,true);
		$criteria->compare('telegram_verification_was_requested_by',$this->telegram_verification_was_requested_by);
		$criteria->compare('date_whatsapp_verification_was_requested',$this->date_whatsapp_verification_was_requested,true);
		$criteria->compare('whatsapp_verification_was_requested_by',$this->whatsapp_verification_was_requested_by);
		$criteria->compare('date_facebook_verification_was_requested',$this->date_facebook_verification_was_requested,true);
		$criteria->compare('facebook_verification_was_requested_by',$this->facebook_verification_was_requested_by);
		$criteria->compare('date_tweeter_verification_was_requested',$this->date_tweeter_verification_was_requested,true);
		$criteria->compare('tweeter_verification_was_requested_by',$this->tweeter_verification_was_requested_by);
		$criteria->compare('date_youtube_verification_was_requested',$this->date_youtube_verification_was_requested,true);
		$criteria->compare('youtube_verification_was_requested_by',$this->youtube_verification_was_requested_by);
		$criteria->compare('date_picture_verification_was_requested',$this->date_picture_verification_was_requested,true);
		$criteria->compare('picture_verification_was_requested_by',$this->picture_verification_was_requested_by);
		$criteria->compare('date_bvn_verification_was_requested',$this->date_bvn_verification_was_requested,true);
		$criteria->compare('bvn_verification_was_requested_by',$this->bvn_verification_was_requested_by);
		$criteria->compare('date_nin_verification_was_requested',$this->date_nin_verification_was_requested,true);
		$criteria->compare('nin_verification_was_requested_by',$this->nin_verification_was_requested_by);
		$criteria->compare('date_pvc_verification_was_requested',$this->date_pvc_verification_was_requested,true);
		$criteria->compare('pvc_verification_was_requested_by',$this->pvc_verification_was_requested_by);
		$criteria->compare('date_pension_pin_verification_was_requested',$this->date_pension_pin_verification_was_requested,true);
		$criteria->compare('pension_pin_verification_was_requested_by',$this->pension_pin_verification_was_requested_by);
		$criteria->compare('date_international_passport_number_verification_was_requested',$this->date_international_passport_number_verification_was_requested,true);
		$criteria->compare('international_passport_number_verification_was_requested_by',$this->international_passport_number_verification_was_requested_by);
		$criteria->compare('date_driver_licence_number_verification_was_requested',$this->date_driver_licence_number_verification_was_requested,true);
		$criteria->compare('driver_licence_number_verification_was_requested_by',$this->driver_licence_number_verification_was_requested_by);
		$criteria->compare('date_mobile_number_verification_was_requested',$this->date_mobile_number_verification_was_requested,true);
		$criteria->compare('mobile_number_verification_was_requested_by',$this->mobile_number_verification_was_requested_by);
		$criteria->compare('is_linkedin_verification_requested',$this->is_linkedin_verification_requested);
		$criteria->compare('is_linkedin_verified',$this->is_linkedin_verified);
		$criteria->compare('date_linkedin_was_verified',$this->date_linkedin_was_verified,true);
		$criteria->compare('linkedin_was_verified_by',$this->linkedin_was_verified_by);
		$criteria->compare('date_linkedin_verification_was_requested',$this->date_linkedin_verification_was_requested,true);
		$criteria->compare('linkedin_verification_was_requested_by',$this->linkedin_verification_was_requested_by);
		$criteria->compare('is_instagram_verification_requested',$this->is_instagram_verification_requested);
		$criteria->compare('is_instagram_verified',$this->is_instagram_verified);
		$criteria->compare('date_instagram_was_verified',$this->date_instagram_was_verified,true);
		$criteria->compare('instagram_was_verified_by',$this->instagram_was_verified_by);
		$criteria->compare('date_instagram_verification_was_requested',$this->date_instagram_verification_was_requested,true);
		$criteria->compare('instagram_verification_was_requested_by',$this->instagram_verification_was_requested_by);
		$criteria->compare('is_driver_licence_expiry_verification_requested',$this->is_driver_licence_expiry_verification_requested);
		$criteria->compare('is_residency_expiry_date_verified',$this->is_residency_expiry_date_verified);
		$criteria->compare('is_international_passport_expiry_verified',$this->is_international_passport_expiry_verified);
		$criteria->compare('is_drivers_licence_expiry_verified',$this->is_drivers_licence_expiry_verified);
		$criteria->compare('is_website_expiry_verified',$this->is_website_expiry_verified);
		$criteria->compare('is_residency_expiry_verification_requested',$this->is_residency_expiry_verification_requested);
		$criteria->compare('date_residency_expiry_verification_was_request',$this->date_residency_expiry_verification_was_request,true);
		$criteria->compare('residency_expiry_verification_was_requested_by',$this->residency_expiry_verification_was_requested_by);
		$criteria->compare('is_international_passport_number_verification_requested',$this->is_international_passport_number_verification_requested);
		$criteria->compare('is_international_passport_expiry_verification_requested',$this->is_international_passport_expiry_verification_requested);
		$criteria->compare('date_website_expiry_verification_was_request',$this->date_website_expiry_verification_was_request,true);
		$criteria->compare('website_expiry_verification_was_requested_by',$this->website_expiry_verification_was_requested_by);
		$criteria->compare('date_international_passport_expiry_verification_was_requested',$this->date_international_passport_expiry_verification_was_requested,true);
		$criteria->compare('international_passport_expiry_verification_was_requested_by',$this->international_passport_expiry_verification_was_requested_by);
		$criteria->compare('date_driver_licence_expiry_verification_was_requested',$this->date_driver_licence_expiry_verification_was_requested,true);
		$criteria->compare('driver_licence_expiry_verification_was_requested_by',$this->driver_licence_expiry_verification_was_requested_by);
		$criteria->compare('is_website_expiry_verification_requested',$this->is_website_expiry_verification_requested);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return UserVerificationOutcome the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * this is the function that confirms if a user messaging profile  is confirmed for that platform 
         */
        public function isUserVerifiedOnThisMessagePlatform($user_id,$type, $initiating_message_address){
            $model = new User;
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $outcome = UserVerificationOutcome::model()->find($criteria);
             
             if($type == 'email'){
                 if($outcome['is_email_verified'] == 1){
                     if($model->isThisTheVerifiedEmailAddress($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             if($type == 'facebook'){
                 if($outcome['is_facebook_verified'] == 1){
                     if($model->isThisTheVerifiedFacebookProfile($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
             if($type == 'call' or $type=='sms'){
                 if($outcome['is_mobile_number_verified'] == 1){
                     if($model->isThisTheVerifiedMobileNumber($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
             
             if($type == 'whatsapp'){
                 if($outcome['is_whatsapp_verified'] == 1){
                     if($model->isThisTheVerifiedWhatsAppProfile($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
             
              if($type == 'wechat'){
                 if($outcome['is_wechat_verified'] == 1){
                     if($model->isThisTheVerifiedWeChatProfile($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
              if($type == 'telegram'){
                 if($outcome['is_telegram_verified'] == 1){
                     if($model->isThisTheVerifiedTelegramProfile($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
              if($type == 'youtube'){
                 if($outcome['is_youtube_verified'] == 1){
                     if($model->isThisTheVerifiedYoutubeProfile($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
             
             if($type == 'letter' or $type=="residency"){
                 if($outcome['is_address_verified'] == 1){
                     if($model->isThisTheVerifiedAddess($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
             
             if($type == 'tweeter'){
                 if($outcome['is_tweeter_verified'] == 1){
                     if($model->isThisTheVerifiedTweeterHandle($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
             if($type == 'linkedin'){
                 if($outcome['is_linkedin_verified'] == 1){
                     if($model->isThisTheVerifiedLinkedInProfile($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
             if($type == 'website'){
                 if($outcome['is_website_verified'] == 1){
                     if($model->isThisTheVerifiedWebsiteDomain($user_id,$initiating_message_address)){
                         return true;
                     }else{
                         return false;
                     }
                 }else{
                     return false;
                 }
             }
             
         
        }
        
        /**
         * This is the function that confirms if a user bvn is verified
         */
        public function isUserBvnVerified($user_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $outcome = UserVerificationOutcome::model()->find($criteria);
             
             if($outcome['is_bvn_verified'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
        
         /**
         * This is the function that confirms if a user nin is verified
         */
        public function isUserNinVerified($user_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $outcome = UserVerificationOutcome::model()->find($criteria);
             
             if($outcome['is_nin_verified'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
           /**
         * This is the function that confirms if a user pvc is verified
         */
        public function isUserPvcVerified($user_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $outcome = UserVerificationOutcome::model()->find($criteria);
             
             if($outcome['is_pvc_verified'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
          /**
         * This is the function that confirms if a user passport is verified
         */
        public function isUserPassportVerified($user_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $outcome = UserVerificationOutcome::model()->find($criteria);
             
             if($outcome['is_international_passport_number_verified'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
          /**
         * This is the function that confirms if a user driver license is verified
         */
        public function isUserDriverLicenseVerified($user_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $outcome = UserVerificationOutcome::model()->find($criteria);
             
             if($outcome['is_drivers_licence_number_verified'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
        
          /**
         * This is the function that confirms if a user mobile number is verified
         */
        public function isUserMobileNumberVerified($user_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $outcome = UserVerificationOutcome::model()->find($criteria);
             
             if($outcome['is_mobile_number_verified'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
          /**
         * This is the function that confirms if a user pension pin is verified
         */
        public function isUserPensionPinVerified($user_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='user_id=:userid';   
             $criteria->params = array(':userid'=>$user_id);
             $outcome = UserVerificationOutcome::model()->find($criteria);
             
             if($outcome['is_pension_pin_verified'] == 1){
                 return true;
             }else{
                 return false;
             }
            
        }
}
