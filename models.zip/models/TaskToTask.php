<?php

/**
 * This is the model class for table "task_to_task".
 *
 * The followings are the available columns in table 'task_to_task':
 * @property string $id
 * @property integer $master_id
 * @property integer $slave_id
 * @property string $user_id
 * @property integer $master_tool_id
 * @property integer $slave_tool_id
 * @property string $slave_toolbox_id
 * @property string $description
 * @property string $create_time
 * @property integer $create_user_id
 *
 * The followings are the available model relations:
 * @property Resources $masterTool
 * @property Resources $slave
 * @property Resources $master
 * @property Resources $slaveTool
 * @property Resourcegroup $slaveToolbox
 * @property User $user
 */
class TaskToTask extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'task_to_task';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('master_id, slave_id, user_id, master_tool_id, slave_tool_id, slave_toolbox_id', 'required'),
			array('master_id, slave_id, master_tool_id, slave_tool_id, create_user_id', 'numerical', 'integerOnly'=>true),
			array('user_id, slave_toolbox_id', 'length', 'max'=>10),
			array('description', 'length', 'max'=>250),
			array('create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, master_id, slave_id, user_id, master_tool_id, slave_tool_id, slave_toolbox_id, description, create_time, create_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'masterTool' => array(self::BELONGS_TO, 'Resources', 'master_tool_id'),
			'slave' => array(self::BELONGS_TO, 'Resources', 'slave_id'),
			'master' => array(self::BELONGS_TO, 'Resources', 'master_id'),
			'slaveTool' => array(self::BELONGS_TO, 'Resources', 'slave_tool_id'),
			'slaveToolbox' => array(self::BELONGS_TO, 'Resourcegroup', 'slave_toolbox_id'),
			'user' => array(self::BELONGS_TO, 'User', 'user_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'master_id' => 'Master',
			'slave_id' => 'Slave',
			'user_id' => 'User',
			'master_tool_id' => 'Master Tool',
			'slave_tool_id' => 'Slave Tool',
			'slave_toolbox_id' => 'Slave Toolbox',
			'description' => 'Description',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('master_id',$this->master_id);
		$criteria->compare('slave_id',$this->slave_id);
		$criteria->compare('user_id',$this->user_id,true);
		$criteria->compare('master_tool_id',$this->master_tool_id);
		$criteria->compare('slave_tool_id',$this->slave_tool_id);
		$criteria->compare('slave_toolbox_id',$this->slave_toolbox_id,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return TaskToTask the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
