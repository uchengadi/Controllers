<?php

/**
 * This is the model class for table "virtual_box_request".
 *
 * The followings are the available columns in table 'virtual_box_request':
 * @property string $id
 * @property string $virtual_box_id
 * @property integer $virtual_requesting_domain_id
 * @property integer $virtual_requesting_user_id
 * @property integer $virtual_requesting_group_id
 * @property integer $virtual_requesting_subgroup_id
 * @property string $status
 * @property integer $virtual_is_requested
 * @property integer $virtual_maximum_requesting_period_in_days
 * @property string $virtual_request_initiation_date
 * @property integer $virtual_request_initiated_by
 * @property integer $virtual_is_request_initiated
 * @property integer $virtual_is_request_accepted
 * @property string $virtual_request_accepted_date
 * @property integer $virtual_request_accepted_by
 * @property integer $virtual_is_group_request
 * @property integer $virtual_is_subgroup_request
 * @property integer $virtual_is_single_user_request
 * @property integer $virtual_is_electronic_instrument_request_included
 */
class VirtualBoxRequest extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'virtual_box_request';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('virtual_box_id, virtual_requesting_domain_id, virtual_requesting_user_id', 'required'),
			array('virtual_requesting_domain_id, virtual_requesting_user_id, virtual_requesting_group_id, virtual_requesting_subgroup_id, virtual_is_requested, virtual_maximum_requesting_period_in_days, virtual_request_initiated_by, virtual_is_request_initiated, virtual_is_request_accepted, virtual_request_accepted_by, virtual_is_group_request, virtual_is_subgroup_request, virtual_is_single_user_request, virtual_is_electronic_instrument_request_included', 'numerical', 'integerOnly'=>true),
			array('virtual_box_id', 'length', 'max'=>10),
			array('status', 'length', 'max'=>8),
			array('virtual_request_initiation_date, virtual_request_accepted_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, virtual_box_id, virtual_requesting_domain_id, virtual_requesting_user_id, virtual_requesting_group_id, virtual_requesting_subgroup_id, status, virtual_is_requested, virtual_maximum_requesting_period_in_days, virtual_request_initiation_date, virtual_request_initiated_by, virtual_is_request_initiated, virtual_is_request_accepted, virtual_request_accepted_date, virtual_request_accepted_by, virtual_is_group_request, virtual_is_subgroup_request, virtual_is_single_user_request, virtual_is_electronic_instrument_request_included', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'virtual_box_id' => 'Virtual Box',
			'virtual_requesting_domain_id' => 'Virtual Requesting Domain',
			'virtual_requesting_user_id' => 'Virtual Requesting User',
			'virtual_requesting_group_id' => 'Virtual Requesting Group',
			'virtual_requesting_subgroup_id' => 'Virtual Requesting Subgroup',
			'status' => 'Status',
			'virtual_is_requested' => 'Virtual Is Requested',
			'virtual_maximum_requesting_period_in_days' => 'Virtual Maximum Requesting Period In Days',
			'virtual_request_initiation_date' => 'Virtual Request Initiation Date',
			'virtual_request_initiated_by' => 'Virtual Request Initiated By',
			'virtual_is_request_initiated' => 'Virtual Is Request Initiated',
			'virtual_is_request_accepted' => 'Virtual Is Request Accepted',
			'virtual_request_accepted_date' => 'Virtual Request Accepted Date',
			'virtual_request_accepted_by' => 'Virtual Request Accepted By',
			'virtual_is_group_request' => 'Virtual Is Group Request',
			'virtual_is_subgroup_request' => 'Virtual Is Subgroup Request',
			'virtual_is_single_user_request' => 'Virtual Is Single User Request',
			'virtual_is_electronic_instrument_request_included' => 'Virtual Is Electronic Instrument Request Included',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('virtual_box_id',$this->virtual_box_id,true);
		$criteria->compare('virtual_requesting_domain_id',$this->virtual_requesting_domain_id);
		$criteria->compare('virtual_requesting_user_id',$this->virtual_requesting_user_id);
		$criteria->compare('virtual_requesting_group_id',$this->virtual_requesting_group_id);
		$criteria->compare('virtual_requesting_subgroup_id',$this->virtual_requesting_subgroup_id);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('virtual_is_requested',$this->virtual_is_requested);
		$criteria->compare('virtual_maximum_requesting_period_in_days',$this->virtual_maximum_requesting_period_in_days);
		$criteria->compare('virtual_request_initiation_date',$this->virtual_request_initiation_date,true);
		$criteria->compare('virtual_request_initiated_by',$this->virtual_request_initiated_by);
		$criteria->compare('virtual_is_request_initiated',$this->virtual_is_request_initiated);
		$criteria->compare('virtual_is_request_accepted',$this->virtual_is_request_accepted);
		$criteria->compare('virtual_request_accepted_date',$this->virtual_request_accepted_date,true);
		$criteria->compare('virtual_request_accepted_by',$this->virtual_request_accepted_by);
		$criteria->compare('virtual_is_group_request',$this->virtual_is_group_request);
		$criteria->compare('virtual_is_subgroup_request',$this->virtual_is_subgroup_request);
		$criteria->compare('virtual_is_single_user_request',$this->virtual_is_single_user_request);
		$criteria->compare('virtual_is_electronic_instrument_request_included',$this->virtual_is_electronic_instrument_request_included);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return VirtualBoxRequest the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
