<?php

/**
 * This is the model class for table "domain_has_treaty".
 *
 * The followings are the available columns in table 'domain_has_treaty':
 * @property string $domain_id
 * @property string $related_domain_id
 * @property string $resourcegroup_id
 * @property integer $groups
 * @property integer $subgroups
 * @property integer $employees
 * @property string $description
 * @property string $status
 * @property string $treaty_start_date
 * @property string $treaty_end_date
 * @property integer $acceptable
 * @property integer $initiated_by
 * @property integer $accepted_by
 *
 * The followings are the available model relations:
 * @property Resourcegroupcategory $domain
 * @property Resourcegroupcategory $relatedDomain
 * @property Resourcegroup $resourcegroup
 */
class DomainHasTreaty extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_has_treaty';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('domain_id, related_domain_id, resourcegroup_id, status', 'required'),
			array('groups, subgroups, employees, acceptable, initiated_by, accepted_by', 'numerical', 'integerOnly'=>true),
			array('domain_id, related_domain_id, resourcegroup_id', 'length', 'max'=>10),
			array('description', 'length', 'max'=>250),
			array('status', 'length', 'max'=>8),
			array('treaty_start_date, treaty_end_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('domain_id, related_domain_id, resourcegroup_id, groups, subgroups, employees, description, status, treaty_start_date, treaty_end_date, acceptable, initiated_by, accepted_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'domain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'domain_id'),
			'relatedDomain' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'related_domain_id'),
			'resourcegroup' => array(self::BELONGS_TO, 'Resourcegroup', 'resourcegroup_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'domain_id' => 'Domain',
			'related_domain_id' => 'Related Domain',
			'resourcegroup_id' => 'Resourcegroup',
			'groups' => 'Groups',
			'subgroups' => 'Subgroups',
			'employees' => 'Employees',
			'description' => 'Description',
			'status' => 'Status',
			'treaty_start_date' => 'Treaty Start Date',
			'treaty_end_date' => 'Treaty End Date',
			'acceptable' => 'Acceptable',
			'initiated_by' => 'Initiated By',
			'accepted_by' => 'Accepted By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('related_domain_id',$this->related_domain_id,true);
		$criteria->compare('resourcegroup_id',$this->resourcegroup_id,true);
		$criteria->compare('groups',$this->groups);
		$criteria->compare('subgroups',$this->subgroups);
		$criteria->compare('employees',$this->employees);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('treaty_start_date',$this->treaty_start_date,true);
		$criteria->compare('treaty_end_date',$this->treaty_end_date,true);
		$criteria->compare('acceptable',$this->acceptable);
		$criteria->compare('initiated_by',$this->initiated_by);
		$criteria->compare('accepted_by',$this->accepted_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainHasTreaty the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
