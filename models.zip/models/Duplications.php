<?php

/**
 * This is the model class for table "resources".
 *
 * The followings are the available columns in table 'resources':
 * @property integer $id
 * @property string $resourcetype_id
 * @property string $product_id
 * @property string $name
 * @property string $description
 * @property string $text
 * @property integer $parent_id
 * @property integer $level
 * @property string $url
 * @property string $domain_id
 * @property integer $original_tool_id
 * @property integer $duplicate
 * @property string $icon
 * @property string $filename
 * @property string $poster
 * @property string $zipped_filename
 * @property string $index_html
 * @property integer $islocation_based
 * @property integer $isFirst_consumption
 * @property string $consumption_startime
 * @property string $consumption_endtime
 * @property string $consumer_id
 * @property integer $consumption_frequency
 * @property string $first_consumption_date
 * @property string $last_consumption_date
 * @property integer $number_of_consumption
 * @property double $price
 * @property double $discount_rate
 * @property integer $discount_proof
 * @property double $percentage_share
 * @property integer $respect_task_percentage_share
 * @property integer $respect_share_but_could_squeeze_in
 * @property integer $enforce_equal_share
 * @property integer $reconstruct_tool
 * @property integer $also_serve_as_preview
 * @property integer $is_duplicate
 * @property integer $price_preference
 * @property integer $cumulative_component_price
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 * @property integer $select_value
 *
 * The followings are the available model relations:
 * @property Announcements[] $announcements
 * @property Resourcegroup[] $resourcegroups
 * @property Duplications $parent
 * @property Duplications[] $resources
 * @property Resourcetype $resourcetype
 * @property TaskToTask[] $taskToTasks
 * @property TaskToTask[] $taskToTasks1
 * @property TaskToTask[] $taskToTasks2
 * @property TaskToTask[] $taskToTasks3
 * @property ToolHasTask[] $toolHasTasks
 * @property ToolHasTask[] $toolHasTasks1
 * @property User[] $users
 * @property UserHasNeed[] $userHasNeeds
 * @property UserHasNeed[] $userHasNeeds1
 * @property Wishes[] $wishes
 */
class Duplications extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'resources';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('resourcetype_id, product_id, name, domain_id', 'required'),
			array('parent_id, level, original_tool_id, duplicate, islocation_based, isFirst_consumption, consumption_frequency, number_of_consumption, discount_proof, respect_task_percentage_share, respect_share_but_could_squeeze_in, enforce_equal_share, reconstruct_tool, also_serve_as_preview, is_duplicate, price_preference, cumulative_component_price, create_user_id, update_user_id, select_value', 'numerical', 'integerOnly'=>true),
			array('price, discount_rate, percentage_share', 'numerical'),
			array('resourcetype_id, product_id, domain_id', 'length', 'max'=>10),
			array('name, url, icon', 'length', 'max'=>100),
			array('description', 'length', 'max'=>150),
			array('text', 'length', 'max'=>250),
			array('filename, poster', 'length', 'max'=>60),
			array('zipped_filename, index_html', 'length', 'max'=>255),
			array('consumption_startime, consumption_endtime, consumer_id, first_consumption_date, last_consumption_date, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, resourcetype_id, product_id, name, description, text, parent_id, level, url, domain_id, original_tool_id, duplicate, icon, filename, poster, zipped_filename, index_html, islocation_based, isFirst_consumption, consumption_startime, consumption_endtime, consumer_id, consumption_frequency, first_consumption_date, last_consumption_date, number_of_consumption, price, discount_rate, discount_proof, percentage_share, respect_task_percentage_share, respect_share_but_could_squeeze_in, enforce_equal_share, reconstruct_tool, also_serve_as_preview, is_duplicate, price_preference, cumulative_component_price, create_time, create_user_id, update_time, update_user_id, select_value', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'announcements' => array(self::HAS_MANY, 'Announcements', 'resource_id'),
			'resourcegroups' => array(self::MANY_MANY, 'Resourcegroup', 'resource_has_resourcegroups(resource_id, resourcegroup_id)'),
			'parent' => array(self::BELONGS_TO, 'Duplications', 'parent_id'),
			'resources' => array(self::HAS_MANY, 'Duplications', 'parent_id'),
			'resourcetype' => array(self::BELONGS_TO, 'Resourcetype', 'resourcetype_id'),
			'taskToTasks' => array(self::HAS_MANY, 'TaskToTask', 'master_tool_id'),
			'taskToTasks1' => array(self::HAS_MANY, 'TaskToTask', 'slave_id'),
			'taskToTasks2' => array(self::HAS_MANY, 'TaskToTask', 'master_id'),
			'taskToTasks3' => array(self::HAS_MANY, 'TaskToTask', 'slave_tool_id'),
			'toolHasTasks' => array(self::HAS_MANY, 'ToolHasTask', 'task_id'),
			'toolHasTasks1' => array(self::HAS_MANY, 'ToolHasTask', 'tool_id'),
			'users' => array(self::MANY_MANY, 'User', 'user_has_favourites(resource_id, user_id)'),
			'userHasNeeds' => array(self::HAS_MANY, 'UserHasNeed', 'tool_id'),
			'userHasNeeds1' => array(self::HAS_MANY, 'UserHasNeed', 'need_id'),
			'wishes' => array(self::HAS_MANY, 'Wishes', 'resource_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'resourcetype_id' => 'Resourcetype',
			'product_id' => 'Product',
			'name' => 'Name',
			'description' => 'Description',
			'text' => 'Text',
			'parent_id' => 'Parent',
			'level' => 'Level',
			'url' => 'Url',
			'domain_id' => 'Domain',
			'original_tool_id' => 'Original Tool',
			'duplicate' => 'Duplicate',
			'icon' => 'Icon',
			'filename' => 'Filename',
			'poster' => 'Poster',
			'zipped_filename' => 'Zipped Filename',
			'index_html' => 'Index Html',
			'islocation_based' => 'Islocation Based',
			'isFirst_consumption' => 'Is First Consumption',
			'consumption_startime' => 'Consumption Startime',
			'consumption_endtime' => 'Consumption Endtime',
			'consumer_id' => 'Consumer',
			'consumption_frequency' => 'Consumption Frequency',
			'first_consumption_date' => 'First Consumption Date',
			'last_consumption_date' => 'Last Consumption Date',
			'number_of_consumption' => 'Number Of Consumption',
			'price' => 'Price',
			'discount_rate' => 'Discount Rate',
			'discount_proof' => 'Discount Proof',
			'percentage_share' => 'Percentage Share',
			'respect_task_percentage_share' => 'Respect Task Percentage Share',
			'respect_share_but_could_squeeze_in' => 'Respect Share But Could Squeeze In',
			'enforce_equal_share' => 'Enforce Equal Share',
			'reconstruct_tool' => 'Reconstruct Tool',
			'also_serve_as_preview' => 'Also Serve As Preview',
			'is_duplicate' => 'Is Duplicate',
			'price_preference' => 'Price Preference',
			'cumulative_component_price' => 'Cumulative Component Price',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
			'select_value' => 'Select Value',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('resourcetype_id',$this->resourcetype_id,true);
		$criteria->compare('product_id',$this->product_id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('text',$this->text,true);
		$criteria->compare('parent_id',$this->parent_id);
		$criteria->compare('level',$this->level);
		$criteria->compare('url',$this->url,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('original_tool_id',$this->original_tool_id);
		$criteria->compare('duplicate',$this->duplicate);
		$criteria->compare('icon',$this->icon,true);
		$criteria->compare('filename',$this->filename,true);
		$criteria->compare('poster',$this->poster,true);
		$criteria->compare('zipped_filename',$this->zipped_filename,true);
		$criteria->compare('index_html',$this->index_html,true);
		$criteria->compare('islocation_based',$this->islocation_based);
		$criteria->compare('isFirst_consumption',$this->isFirst_consumption);
		$criteria->compare('consumption_startime',$this->consumption_startime,true);
		$criteria->compare('consumption_endtime',$this->consumption_endtime,true);
		$criteria->compare('consumer_id',$this->consumer_id,true);
		$criteria->compare('consumption_frequency',$this->consumption_frequency);
		$criteria->compare('first_consumption_date',$this->first_consumption_date,true);
		$criteria->compare('last_consumption_date',$this->last_consumption_date,true);
		$criteria->compare('number_of_consumption',$this->number_of_consumption);
		$criteria->compare('price',$this->price);
		$criteria->compare('discount_rate',$this->discount_rate);
		$criteria->compare('discount_proof',$this->discount_proof);
		$criteria->compare('percentage_share',$this->percentage_share);
		$criteria->compare('respect_task_percentage_share',$this->respect_task_percentage_share);
		$criteria->compare('respect_share_but_could_squeeze_in',$this->respect_share_but_could_squeeze_in);
		$criteria->compare('enforce_equal_share',$this->enforce_equal_share);
		$criteria->compare('reconstruct_tool',$this->reconstruct_tool);
		$criteria->compare('also_serve_as_preview',$this->also_serve_as_preview);
		$criteria->compare('is_duplicate',$this->is_duplicate);
		$criteria->compare('price_preference',$this->price_preference);
		$criteria->compare('cumulative_component_price',$this->cumulative_component_price);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);
		$criteria->compare('select_value',$this->select_value);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Duplications the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
