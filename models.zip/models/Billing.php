<?php

/**
 * This is the model class for table "billing".
 *
 * The followings are the available columns in table 'billing':
 * @property string $id
 * @property string $invoice_id
 * @property double $verification_request_amount
 * @property double $consumption_request_amount
 * @property string $date_prepard
 * @property integer $prepared_by
 */
class Billing extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'billing';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('invoice_id', 'required'),
			array('prepared_by', 'numerical', 'integerOnly'=>true),
			array('verification_request_amount, consumption_request_amount', 'numerical'),
			array('invoice_id', 'length', 'max'=>10),
			array('date_prepard', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, invoice_id, verification_request_amount, consumption_request_amount, date_prepard, prepared_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'invoice_id' => 'Invoice',
			'verification_request_amount' => 'Verification Request Amount',
			'consumption_request_amount' => 'Consumption Request Amount',
			'date_prepard' => 'Date Prepard',
			'prepared_by' => 'Prepared By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('invoice_id',$this->invoice_id,true);
		$criteria->compare('verification_request_amount',$this->verification_request_amount);
		$criteria->compare('consumption_request_amount',$this->consumption_request_amount);
		$criteria->compare('date_prepard',$this->date_prepard,true);
		$criteria->compare('prepared_by',$this->prepared_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Billing the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that zerorises the billings table
         */
        public function isTheZerorizationOfTheBillTableASuccess(){
            $model = new DomainTransactions;
            $error_count = 0;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $bills= Billing::model()->findAll($criteria1);
            
            foreach($bills as $bill){
                if($this->isThisBillDeleted($bill['id']) == false){
                    $error_count = $error_count + 1;
                }
            }
            if($error_count>0){
               return false;
            }else{
              return true;
            }
            
        }
        
        
        /**
         * This is the function that deletes a bill record from the billing table
         */
        public function isThisBillDeleted($bill_id){
             $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('billing', 'id=:id', array(':id'=>$bill_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
        }
}
