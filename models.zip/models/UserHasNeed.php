<?php

/**
 * This is the model class for table "user_has_need".
 *
 * The followings are the available columns in table 'user_has_need':
 * @property string $id
 * @property integer $need_id
 * @property string $resourcegroup_id
 * @property integer $tool_id
 * @property string $category_id
 * @property string $justification
 * @property string $create_time
 * @property integer $requester_id
 * @property string $update_time
 *
 * The followings are the available model relations:
 * @property Resourcegroupcategory $category
 * @property Resourcegroup $resourcegroup
 * @property Resources $tool
 * @property Resources $need
 */
class UserHasNeed extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'user_has_need';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('need_id, resourcegroup_id, tool_id, category_id', 'required'),
			array('need_id, tool_id, requester_id', 'numerical', 'integerOnly'=>true),
			array('resourcegroup_id, category_id', 'length', 'max'=>10),
			array('justification', 'length', 'max'=>250),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, need_id, resourcegroup_id, tool_id, category_id, justification, create_time, requester_id, update_time', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'category' => array(self::BELONGS_TO, 'Resourcegroupcategory', 'category_id'),
			'resourcegroup' => array(self::BELONGS_TO, 'Resourcegroup', 'resourcegroup_id'),
			'tool' => array(self::BELONGS_TO, 'Resources', 'tool_id'),
			'need' => array(self::BELONGS_TO, 'Resources', 'need_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'need_id' => 'Need',
			'resourcegroup_id' => 'Resourcegroup',
			'tool_id' => 'Tool',
			'category_id' => 'Category',
			'justification' => 'Justification',
			'create_time' => 'Create Time',
			'requester_id' => 'Requester',
			'update_time' => 'Update Time',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('need_id',$this->need_id);
		$criteria->compare('resourcegroup_id',$this->resourcegroup_id,true);
		$criteria->compare('tool_id',$this->tool_id);
		$criteria->compare('category_id',$this->category_id,true);
		$criteria->compare('justification',$this->justification,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('requester_id',$this->requester_id);
		$criteria->compare('update_time',$this->update_time,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return UserHasNeed the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
