<?php

/**
 * This is the model class for table "domain_payment".
 *
 * The followings are the available columns in table 'domain_payment':
 * @property string $id
 * @property string $invoice_number
 * @property double $total_verification_request_amount
 * @property double $total_consumption_request_amount
 * @property string $date_prepard
 * @property integer $prepared_by
 * @property string $status
 * @property string $owner_domain_id
 * @property integer $is_payment_confirmed
 * @property integer $confirmed_by
 * @property string $date_confirmed
 */
class DomainPayment extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_payment';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('status, owner_domain_id', 'required'),
			array('prepared_by, is_payment_confirmed, confirmed_by', 'numerical', 'integerOnly'=>true),
			array('total_verification_request_amount, total_consumption_request_amount', 'numerical'),
			array('invoice_number', 'length', 'max'=>250),
			array('status', 'length', 'max'=>14),
			array('owner_domain_id', 'length', 'max'=>10),
			array('date_prepard, date_confirmed', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, invoice_number, total_verification_request_amount, total_consumption_request_amount, date_prepard, prepared_by, status, owner_domain_id, is_payment_confirmed, confirmed_by, date_confirmed', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'invoice_number' => 'Invoice Number',
			'total_verification_request_amount' => 'Total Verification Request Amount',
			'total_consumption_request_amount' => 'Total Consumption Request Amount',
			'date_prepard' => 'Date Prepard',
			'prepared_by' => 'Prepared By',
			'status' => 'Status',
			'owner_domain_id' => 'Owner Domain',
			'is_payment_confirmed' => 'Is Payment Confirmed',
			'confirmed_by' => 'Confirmed By',
			'date_confirmed' => 'Date Confirmed',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('invoice_number',$this->invoice_number,true);
		$criteria->compare('total_verification_request_amount',$this->total_verification_request_amount);
		$criteria->compare('total_consumption_request_amount',$this->total_consumption_request_amount);
		$criteria->compare('date_prepard',$this->date_prepard,true);
		$criteria->compare('prepared_by',$this->prepared_by);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('owner_domain_id',$this->owner_domain_id,true);
		$criteria->compare('is_payment_confirmed',$this->is_payment_confirmed);
		$criteria->compare('confirmed_by',$this->confirmed_by);
		$criteria->compare('date_confirmed',$this->date_confirmed,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainPayment the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that generates payment advice for a domain
         */
        public function isTheGenerationOfThisDomainPaymentAdviceASuccess($domain){
            $model = new Invoice;
            $total_verification_request_amount = 0;
            $total_consumption_request_amount = 0;
            $trans_counter = 0;
            //spool on billing information
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $bills= Billing::model()->findAll($criteria1);
            
            foreach($bills as $bill){
                if($model->isThisBillForThisDomain($bill['invoice_id'],$domain)){
                    $total_verification_request_amount = $total_verification_request_amount + $bill['verification_request_amount'];
                    $total_consumption_request_amount = $total_consumption_request_amount + $bill['consumption_request_amount'];
                    $trans_counter = $trans_counter + 1;
                    $domain_trans_id = $bill['domain_transaction_id'];
                }
            }
            
            if($trans_counter === 0){
                return true;
            }else{
                //prepare a payment advice for this domain
                $this->invoice_number = $this->generatePaymentInvoiceNumber($domain);
                $this->total_verification_request_amount = $total_verification_request_amount;
                $this->total_consumption_request_amount = $total_consumption_request_amount;
                $this->domain_transaction_id = $domain_trans_id;
                $this->date_prepard = new CDbExpression('NOW()');
                $this->prepared_by = Yii::app()->user->id;
                $this->status = "pending";
                $this->owner_domain_id =$domain;
                
                if($this->save()){
                    return true;
                }else{
                    return false;
                }
                
            }
        }
        
        
        /**
         * This is the function that generates payment invoice number
}      */
        public function generatePaymentInvoiceNumber($domain_id){
            //get the first 3 letters of the domain name
                $domain_first_four_letters = strtoupper($this->getThePurchasingDomainNameFirstFourLetters($domain_id)); 
           
            //get a random number from 1 to 10
                $random_number = $this->generateTheRandomNumber();
                //get todays date
                $today= mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                
                $invoice_number = "$domain_id$domain_first_four_letters-$random_number";
                
                return $invoice_number; 
        }
        
        
         /**
             * This is the function that retrieves the first four letters  of the domain name for invoice number construction
             */
            public function getThePurchasingDomainNameFirstFourLetters($domain_id){
                
                $model = new Resourcegroupcategory;    
                //get the domain name
                $domainname = $model->getThisDomainName($domain_id);
                //obtain the first four letters
                $substring = substr($domainname,0,4);
                
                return $substring;
            }
        
        
         /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
        
            /**
             * This is the function that confirms payment
             */
            public function isPaymentConfirmationASuccess($id,$status,$total_amount_confirmed){
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('domain_payment',
                                  array(
                                    'status'=>$status,
                                    'is_payment_confirmed'=>1,  
                                    'total_amount_confirmed'=>$total_amount_confirmed, 
                                    'confirmed_by'=>Yii::app()->user->id,
                                    'date_confirmed'=>new CDbExpression('NOW()')  
                                   
                               
		
                            ),
                     ("id=$id"));
            
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
             /**
             * This is the function that confirms payment
             */
            public function isThisPartialPaymentConfirmationASuccess($id,$status,$total_amount_confirmed){
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('domain_payment',
                                  array(
                                    'status'=>$status,
                                    'is_payment_confirmed'=>1,  
                                    'total_amount_confirmed'=>$total_amount_confirmed, 
                                    'confirmed_by'=>Yii::app()->user->id,
                                    'date_confirmed'=>new CDbExpression('NOW()')  
                                   
                               
		
                            ),
                     ("id=$id"));
            
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
             /**
             * This is the function that confirms payment
             */
            public function isThisDisputedPaymentNewStatusEffected($id,$status){
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('domain_payment',
                                  array(
                                    'status'=>$status,
                                   'confirmed_by'=>Yii::app()->user->id,
                                    'date_confirmed'=>new CDbExpression('NOW()')  
            
                            ),
                     ("id=$id"));
            
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
            /**
             * This is the function that initiates payment confirmation request
             */
            public function isTheInitiationOfThisPaymentConfirmationASuccess($id,$bank_id){
                $cmd =Yii::app()->db->createCommand();
                $result = $cmd->update('domain_payment',
                                  array(
                                    'is_payment_confirmation_requested_by_customer'=>1,
                                    'bank_id'=>$bank_id,  
                                   'payment_confirmation_requested_by'=>Yii::app()->user->id,
                                    'date_payment_confirmation_requested_initiated'=>new CDbExpression('NOW()')  
            
                            ),
                     ("id=$id"));
            
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            }
            
            
            /**
             * This is the function that ends domain transaction tree
             */
            public function isTheEndingOfdomainTransactionTreeASuccess($domain){
                $model = new DomainTransactions;
                return $model->isTheEndingOfdomainTransactionTreeASuccess($domain);
            }
        
}
        
