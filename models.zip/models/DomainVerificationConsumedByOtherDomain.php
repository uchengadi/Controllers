<?php

/**
 * This is the model class for table "domain_verification_consumed_by_other_domain".
 *
 * The followings are the available columns in table 'domain_verification_consumed_by_other_domain':
 * @property string $id
 * @property string $verification_id
 * @property string $domain_id
 * @property string $date_accepted
 */
class DomainVerificationConsumedByOtherDomain extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'domain_verification_consumed_by_other_domain';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('verification_id, domain_id', 'required'),
			array('verification_id, domain_id', 'length', 'max'=>10),
			array('date_accepted', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, verification_id, domain_id, date_accepted', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'verification_id' => 'Verification',
			'domain_id' => 'Domain',
			'date_accepted' => 'Date Accepted',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('verification_id',$this->verification_id,true);
		$criteria->compare('domain_id',$this->domain_id,true);
		$criteria->compare('date_accepted',$this->date_accepted,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return DomainVerificationConsumedByOtherDomain the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
          /**
         * This is the function that list all conaummable domains by a user's domain
         */
        public function retrieveAllConsummableDomainsByThisUserDomain($user_domain_id){
            
            $model = new DomainVerification;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='domain_id=:domainid and is_consumption_paid_for=:paidfor';
            $criteria1->params = array(':domainid'=>$user_domain_id,':paidfor'=>1);
            $consummables= DomainVerificationConsumedByOtherDomain::model()->findAll($criteria1);
            
            $all_consummable_domains = [];
            foreach($consummables as $con){
                $all_consummable_domains[] = $model->getTheDomainForThisVerification($con['verification_id']);
            }
            return $all_consummable_domains;
        }
        
        
          /**
         * This is the function that list all conaummable domains by a user's domain
         */
        public function retrieveAllConsummableVerificationsBelongingToSubjectDomainDomainsForThisUserDomain($user_domain_id){
            
            $model = new DomainVerification;
            $criteria1 = new CDbCriteria();
            $criteria1->select = '*';
            $criteria1->condition='domain_id=:domainid and is_consumption_paid_for=:paidfor';
            $criteria1->params = array(':domainid'=>$user_domain_id,':paidfor'=>1);
            $consummables= DomainVerificationConsumedByOtherDomain::model()->findAll($criteria1);
            
            $all_consummable_verifications = [];
            foreach($consummables as $con){
                $all_consummable_verifications[] = $con['verification_id'];
            }
            return $all_consummable_verifications;
        }
        
        
       
        
      
}
